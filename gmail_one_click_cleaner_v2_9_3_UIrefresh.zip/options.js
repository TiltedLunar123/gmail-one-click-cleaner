(async () => {
  const $ = (id) => document.getElementById(id);
  const defaults = {
    light: [
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "category:promotions older_than:1y",
      "category:social older_than:1y",
      "\"unsubscribe\" older_than:2y"
    ],
    normal: [
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "has:attachment larger:5M older_than:2y",
      "category:promotions older_than:3m",
      "category:promotions older_than:1y",
      "category:social older_than:6m",
      "category:updates older_than:6m",
      "category:forums older_than:6m",
      "has:newsletter older_than:6m",
      "\"unsubscribe\" older_than:1y",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:6m"
    ],
    deep: [
      "larger:20M",
      "has:attachment larger:10M older_than:3m",
      "has:attachment larger:5M older_than:1y",
      "category:promotions older_than:2m",
      "category:promotions older_than:6m",
      "category:social older_than:3m",
      "category:social older_than:6m",
      "category:updates older_than:3m",
      "category:forums older_than:3m",
      "has:newsletter older_than:3m",
      "\"unsubscribe\" older_than:6m",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:3m"
    ]
  };

  const load = async () => {
    const { rules } = await chrome.storage.sync.get("rules");
    const data = rules || defaults;
    $("light").value = data.light.join("\n");
    $("normal").value = data.normal.join("\n");
    $("deep").value = data.deep.join("\n");
  };

  const save = async () => {
    const rules = {
      light: $("light").value.split("\n").map(s => s.trim()).filter(Boolean),
      normal: $("normal").value.split("\n").map(s => s.trim()).filter(Boolean),
      deep: $("deep").value.split("\n").map(s => s.trim()).filter(Boolean)
    };
    await chrome.storage.sync.set({ rules });
    alert("Saved.");
  };

  document.getElementById("save").addEventListener("click", save);
  load();
})();
