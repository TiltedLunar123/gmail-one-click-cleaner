document.addEventListener("DOMContentLoaded", () => {
  const $ = (id) => document.getElementById(id);
  const runBtn = $("runCleanup");
  const status = $("status");
  const intensity = $("intensity");
  const dryRun = $("dryRun");
  const safeMode = $("safeMode");
  $("openOptions").addEventListener("click", async (e) => {
    e.preventDefault();
    const url = chrome.runtime.getURL("options.html");
    await chrome.tabs.create({ url });
  });

  runBtn.addEventListener("click", async () => {
    runBtn.disabled = true;
    const original = runBtn.textContent;
    runBtn.textContent = "Starting…";
    status.textContent = "Locating a Gmail tab…";

    try {
      const gmailTabs = await chrome.tabs.query({ url: "https://mail.google.com/*" });
      const gmailTab = gmailTabs.find(t => t.active && t.highlighted) || gmailTabs[0];
      if (!gmailTab) {
        status.textContent = "Open Gmail first, then try again.";
        const openBtn = document.createElement('button');
        openBtn.textContent = "Open Gmail";
        openBtn.style.marginTop = "8px";
        openBtn.onclick = async () => {
          await chrome.tabs.create({ url: "https://mail.google.com/mail/u/0/#inbox" });
        };
        status.appendChild(openBtn);
        runBtn.disabled = false; runBtn.textContent = original;
        return;
      }

      // Open progress page with Gmail tab id
      const progressUrl = chrome.runtime.getURL(`progress.html?gmailTabId=${gmailTab.id}`);
      await chrome.tabs.create({ url: progressUrl, active: true });

      // Persist last config for progress page reinject
      try { await chrome.storage.session.set({ lastConfig: { intensity: intensity.value, dryRun: !!dryRun.checked, safeMode: !!safeMode.checked } }); } catch { try { await chrome.storage.local.set({ lastConfig: { intensity: intensity.value, dryRun: !!dryRun.checked, safeMode: !!safeMode.checked } }); } catch {} }

      // Inject config
      await chrome.scripting.executeScript({
        target: { tabId: gmailTab.id },
        func: (cfg) => { window.GMAIL_CLEANER_CONFIG = cfg; },
        args: [{
          intensity: intensity.value,
          dryRun: !!dryRun.checked,
          safeMode: !!safeMode.checked
        }]
      });

      // Run content script
      await chrome.scripting.executeScript({
        target: { tabId: gmailTab.id },
        files: ["contentScript.js"]
      });

      window.close();
    } catch (e) {
      console.error(e);
      status.textContent = `Error: ${e?.message || e}`;
      runBtn.disabled = false; runBtn.textContent = original;
    }
  });
});

// Tip buttons: ethical prompt with suggested amounts
(function(){
  const TIP_URL = "https://cash.app/$judeh1l";
  const wrap = document.getElementById("tipButtons");
  if (!wrap) return;
  wrap.addEventListener("click", async (e) => {
    const btn = e.target.closest("button.tip"); if (!btn) return;
    const amt = btn.getAttribute("data-amt");
    const url = TIP_URL; // Avoid fragile amount URLs; user can adjust on page
    try {
      await chrome.tabs.create({ url });
      try {
        const when = Date.now();
        await chrome.storage.local.set({ lastTipIntentAt: when, lastTipIntentAmount: amt });
      } catch {}
    } catch {}
  });
})();
