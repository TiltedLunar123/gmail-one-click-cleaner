# Gmail One-Click Cleaner (v2)
MV3 extension to bulk-clean Gmail with one click. Adds Dry-Run, Cancel, Options-based rules, resilient selectors, and a progress window.

## Install (Developer Mode)
1. Unzip or use the `.zip` provided.
2. Open `chrome://extensions`, enable **Developer mode**.
3. **Load unpacked** -> select the folder, or **Load** the `.zip` by extracting first.
4. Pin the extension. Open Gmail, click **Run cleanup**.

## Notes
- Dry-Run reports counts without deleting.
- You can cancel mid-run; it stops within a few seconds.
- Edit queries in the Options page; they persist via `chrome.storage.sync`.
