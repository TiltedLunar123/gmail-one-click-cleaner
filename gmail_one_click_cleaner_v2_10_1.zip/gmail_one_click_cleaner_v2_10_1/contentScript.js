(() => {
  // =========================
  // Boot & basic utilities
  // =========================

  /**
   * Simple sleep helper for async flows.
   * @param {number} ms
   * @returns {Promise<void>}
   */
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  /**
   * Safely send progress/status messages to the background script.
   * Never throws if Chrome messaging isn't available.
   * @param {object} msg
   */
  const safeSend = (msg) => {
    try {
      if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage(
          Object.assign({ type: "gmailCleanerProgress" }, msg)
        );
      }
    } catch {
      // Swallow errors to avoid breaking the cleaner if messaging fails.
    }
  };

  // Guard against duplicate injection (can happen with SPA-style reloads).
  if (window.__GCC_ATTACHED__) {
    safeSend({
      phase: "boot",
      status: "Already attached",
      detail: "Duplicate inject ignored.",
      percent: 0
    });
    return;
  }
  window.__GCC_ATTACHED__ = true;

  safeSend({
    phase: "boot",
    status: "Content script attached",
    detail: "Initializing...",
    percent: 0
  });

  // =========================
  // Config / runtime flags
  // =========================

  let CANCELLED = false;
  let RUNNING = false;

  /**
   * @typedef {"light" | "normal" | "deep"} Intensity
   */

  /**
   * @typedef {Object} CleanerConfig
   * @property {Intensity} intensity
   * @property {boolean} dryRun
   * @property {boolean} safeMode
   * @property {boolean} tagBeforeDelete
   * @property {string} tagLabelPrefix
   * @property {boolean} guardSkipStarred
   * @property {boolean} guardSkipImportant
   * @property {string|null} minAge
   * @property {boolean} archiveInsteadOfDelete
   */

  /** @type {CleanerConfig} */
  const CONFIG = Object.assign(
    {
      intensity: "normal",    // light | normal | deep
      dryRun: false,          // if true, no deletions; just counts
      safeMode: false,        // if true, skips riskier categories
      tagBeforeDelete: true,  // if true, label messages before deleting/archiving
      tagLabelPrefix: "GmailCleaner", // label prefix used when tagging

      // New 2.2-style guardrails
      guardSkipStarred: true,       // if true, add -is:starred
      guardSkipImportant: true,     // if true, add -is:important
      // e.g. "3m", "6m", "12m", "24m" – appended only if query has no older_than:
      minAge: null,
      // If true, use Archive instead of Delete (safer mode)
      archiveInsteadOfDelete: false
    },
    window.GMAIL_CLEANER_CONFIG || {}
  );

  // Maximum passes per query to avoid infinite loops on weird searches.
  const PASS_CAP = 30;

  // Common delete/trash labels in multiple languages.
  const DELETE_LABEL_TOKENS = [
    "Delete",
    "Trash",
    "Bin",
    "Move to trash",
    "Eliminar",
    "Papelera",
    "Supprimer",
    "Corbeille",
    "Löschen",
    "Papierkorb",
    "Excluir",
    "Lixeira",
    "Elimina",
    "Cestino",
    "Verwijderen",
    "Prullenbak",
    "Ta bort",
    "Slet",
    "Slett",
    "Usuń",
    "Kosz",
    "Sil",
    "Удалить",
    "حذف",
    "削除",
    "삭제",
    "删除"
  ];

  // Common archive labels in multiple languages.
  const ARCHIVE_LABEL_TOKENS = [
    "Archive",
    "Archived",
    "Archiver",
    "Archivar",
    "Archivé",
    "Archivieren",
    "Arquivar",
    "Archivia",
    "Archivio"
  ];

  // Common label tokens in multiple languages.
  const LABEL_BUTTON_TOKENS = [
    "Labels",
    "Label",
    "Label as",
    "Libellés",
    "Etiquetas",
    "Etiquette",
    "Etichette",
    "Märken"
  ];

  const isGmailTab = () => location.host === "mail.google.com";

  // =========================
  // Messaging from popup/progress UI
  // =========================

  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg) return;

      if (msg.type === "gmailCleanerCancel") {
        CANCELLED = true;
      }

      if (msg.type === "gmailCleanerPing") {
        sendResponse({ ok: true, phase: RUNNING ? "running" : "idle" });
      }

      if (msg.type === "gmailCleanerStart") {
        startMain();
      }
    });
  }

  // =========================
  // DOM selectors
  // =========================

  const SELECTORS = {
    main: "div[role='main']",
    grid: "table[role='grid']",
    listContainer: "div[gh='tl']",
    masterCheckbox: [
      "div[aria-label='Select'] div[role='checkbox']",
      "div[aria-label^='Select'] div[role='checkbox']",
      "div[gh='tl'] div[role='checkbox']",
      "div[gh='mtb'] div[role='checkbox']",
      "div[role='checkbox']"
    ],
    deleteButton: [
      "div[gh='mtb'] div[aria-label='Delete']",
      "div[gh='mtb'] [aria-label^='Delete']",
      "[aria-label='Delete']"
    ]
  };

  function getMainRoot() {
    return document.querySelector(SELECTORS.main) || document;
  }

  // =========================
  // Generic DOM wait helper
  // =========================

  /**
   * Repeatedly calls fn until it returns a truthy value or times out.
   * Cancels if the run is marked CANCELLED.
   * @param {() => any | Promise<any>} fn
   * @param {{timeout?: number, interval?: number}} opts
   * @returns {Promise<any|null>}
   */
  async function waitFor(fn, { timeout = 15000, interval = 200 } = {}) {
    const start = Date.now();

    while (Date.now() - start < timeout) {
      if (CANCELLED) throw new Error("Cancelled");

      try {
        const value = await fn();
        if (value) return value;
      } catch {
        // Ignore fn errors, keep polling.
      }

      await sleep(interval);
    }

    return null;
  }

  // =========================
  // Rules: build query list
  // =========================

  const DEFAULT_RULES = {
    light: [
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "category:promotions older_than:1y",
      "category:social older_than:1y",
      "\"unsubscribe\" older_than:2y"
    ],
    normal: [
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "has:attachment larger:5M older_than:2y",
      "category:promotions older_than:3m",
      "category:promotions older_than:1y",
      "category:social older_than:6m",
      "category:updates older_than:6m",
      "category:forums older_than:6m",
      "has:newsletter older_than:6m",
      "\"unsubscribe\" older_than:1y",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:6m"
    ],
    deep: [
      "larger:20M",
      "has:attachment larger:10M older_than:3m",
      "has:attachment larger:5M older_than:1y",
      "category:promotions older_than:2m",
      "category:promotions older_than:6m",
      "category:social older_than:3m",
      "category:social older_than:6m",
      "category:updates older_than:3m",
      "category:forums older_than:3m",
      "has:newsletter older_than:3m",
      "\"unsubscribe\" older_than:6m",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:3m"
    ]
  };

  /**
   * Load rules from storage (if present), otherwise use defaults.
   * Applies safeMode filtering to avoid Updates/Forums if requested.
   * @param {"light"|"normal"|"deep"} intensity
   * @returns {Promise<string[]>}
   */
  async function getRules(intensity) {
    const stripRisky = (rules) =>
      CONFIG.safeMode
        ? rules.filter(
            (q) =>
              !q.includes("category:updates") && !q.includes("category:forums")
          )
        : rules;

    try {
      if (
        typeof chrome !== "undefined" &&
        chrome.storage &&
        chrome.storage.sync &&
        chrome.storage.sync.get
      ) {
        const result = await chrome.storage.sync.get("rules");
        const allRules = result && result.rules ? result.rules : DEFAULT_RULES;
        const set = allRules[intensity] || allRules.normal;
        return stripRisky(set);
      }
    } catch {
      // ignore and fall back
    }

    const fallback = DEFAULT_RULES[intensity] || DEFAULT_RULES.normal;
    return stripRisky(fallback);
  }

  /**
   * Map a raw Gmail query string to a human-friendly label for the UI.
   * @param {string} q
   * @returns {string}
   */
  function labelQuery(q) {
    if (q.includes("larger:")) return "Big attachments";
    if (q.includes("category:promotions")) return "Promotions";
    if (q.includes("category:social")) return "Social";
    if (q.includes("category:updates")) return "Updates";
    if (q.includes("category:forums")) return "Forums";
    if (q.includes("newsletter") || q.includes("unsubscribe"))
      return "Newsletters";
    if (
      q.includes("no-reply") ||
      q.includes("donotreply") ||
      q.includes("do-not-reply")
    )
      return "No-reply";
    return "Other";
  }

  /**
   * Apply global guardrails (skip starred/important, minimum age) to a query.
   * Does NOT mutate the original string.
   * @param {string} raw
   * @returns {string}
   */
  function applyGlobalGuards(raw) {
    let q = (raw || "").trim();
    if (!q) return q;

    if (CONFIG.guardSkipStarred && !/is:starred/i.test(q)) {
      q += " -is:starred";
    }

    if (CONFIG.guardSkipImportant && !/is:important/i.test(q)) {
      q += " -is:important";
    }

    if (
      CONFIG.minAge &&
      typeof CONFIG.minAge === "string" &&
      !/older_than:\d+[dwmy]/i.test(q)
    ) {
      q += ` older_than:${CONFIG.minAge}`;
    }

    return q.trim();
  }

  // =========================
  // Navigation & actions
  // =========================

  /**
   * Open a Gmail search for the given query in the current account.
   * Waits until the message list/grid is present.
   * @param {string} query
   */
  async function openSearch(query) {
    const uMatch = location.pathname.match(/\/mail\/u\/(\d+)\//);
    const userIdx = uMatch ? uMatch[1] : "0";
    const base = `${location.origin}/mail/u/${userIdx}/`;
    const hash = `#search/${encodeURIComponent(query)}`;

    if (!location.href.startsWith(base)) {
      location.href = base + hash;
    } else {
      location.hash = hash;
    }

    const ok = await waitFor(() => {
      const main = document.querySelector(SELECTORS.main);
      return (
        main &&
        (main.querySelector(SELECTORS.grid) ||
          main.querySelector(SELECTORS.listContainer))
      );
    }, { timeout: 20000 });

    if (!ok) throw new Error("Results grid not found");

    // Give Gmail a bit of time to fully render rows.
    await sleep(300);
  }

  /**
   * Click the "Select all" master checkbox for the current message list.
   * @returns {boolean} true if a checkbox was found and clicked
   */
  function clickMasterCheckbox() {
    for (const selector of SELECTORS.masterCheckbox) {
      const el = document.querySelector(selector);
      if (el) {
        el.click();
        return true;
      }
    }
    return false;
  }

  /**
   * Try to find the Delete button in the toolbar using labels and language tokens.
   * @returns {HTMLElement|null}
   */
  function findDeleteButton() {
    const toolbar =
      document.querySelector("div[gh='mtb']") ||
      document.querySelector("div[role='toolbar']") ||
      document;

    const buttons = Array.from(
      toolbar.querySelectorAll("div[role='button'], button")
    );

    const scored = buttons
      .map((el) => {
        const label =
          (el.getAttribute("aria-label") ||
            el.getAttribute("data-tooltip") ||
            el.getAttribute("title") ||
            el.textContent ||
            "").trim();

        let score = 0;

        // Score based on matching known tokens.
        for (const token of DELETE_LABEL_TOKENS) {
          if (label.toLowerCase().includes(token.toLowerCase())) {
            score += 2;
          }
        }

        if (/delete|trash|bin/i.test(label)) score += 3;

        // Also inspect any child element label/tooltip.
        const child =
          el.querySelector("[aria-label],[data-tooltip],[title]") || null;
        const childLabel =
          (child &&
            (child.getAttribute("aria-label") ||
              child.getAttribute("data-tooltip") ||
              child.getAttribute("title"))) ||
          "";

        if (/delete|trash|bin/i.test(childLabel)) score += 1;

        return { el, score };
      })
      .filter((entry) => entry.score > 0)
      .sort((a, b) => b.score - a.score);

    return scored.length ? scored[0].el : null;
  }

  /**
   * Try to find the Archive button in the toolbar using labels and language tokens.
   * @returns {HTMLElement|null}
   */
  function findArchiveButton() {
    const toolbar =
      document.querySelector("div[gh='mtb']") ||
      document.querySelector("div[role='toolbar']") ||
      document;

    const buttons = Array.from(
      toolbar.querySelectorAll("div[role='button'], button")
    );

    const scored = buttons
      .map((el) => {
        const label =
          (el.getAttribute("aria-label") ||
            el.getAttribute("data-tooltip") ||
            el.getAttribute("title") ||
            el.textContent ||
            "").trim();

        let score = 0;

        for (const token of ARCHIVE_LABEL_TOKENS) {
          if (label.toLowerCase().includes(token.toLowerCase())) {
            score += 2;
          }
        }

        if (/archive/i.test(label)) score += 3;

        const child =
          el.querySelector("[aria-label],[data-tooltip],[title]") || null;
        const childLabel =
          (child &&
            (child.getAttribute("aria-label") ||
              child.getAttribute("data-tooltip") ||
              child.getAttribute("title"))) ||
          "";

        if (/archive/i.test(childLabel)) score += 1;

        return { el, score };
      })
      .filter((entry) => entry.score > 0)
      .sort((a, b) => b.score - a.score);

    return scored.length ? scored[0].el : null;
  }

  /**
   * Try to trigger a delete action via button or keyboard shortcuts.
   * @returns {Promise<boolean>} true if a delete attempt was made
   */
  async function tryDeleteAction() {
    const btn = findDeleteButton();
    if (btn) {
      btn.click();
      return true;
    }

    // Fallback: Gmail's Shift + # shortcut.
    try {
      const ev = new KeyboardEvent("keydown", {
        key: "#",
        code: "Digit3",
        shiftKey: true,
        bubbles: true
      });
      document.body.dispatchEvent(ev);
      await sleep(250);
      return true;
    } catch {
      // ignore
    }

    // Final fallback: generic Delete key.
    try {
      const ev2 = new KeyboardEvent("keydown", {
        key: "Delete",
        code: "Delete",
        bubbles: true
      });
      document.body.dispatchEvent(ev2);
      await sleep(250);
      return true;
    } catch {
      // ignore
    }

    return false;
  }

  /**
   * Try to trigger an archive action via button or keyboard shortcuts.
   * @returns {Promise<boolean>} true if an archive attempt was made
   */
  async function tryArchiveAction() {
    const btn = findArchiveButton();
    if (btn) {
      btn.click();
      return true;
    }

    // Common Gmail archive shortcuts: "e" or "y".
    try {
      const ev = new KeyboardEvent("keydown", {
        key: "e",
        code: "KeyE",
        bubbles: true
      });
      document.body.dispatchEvent(ev);
      await sleep(250);
      return true;
    } catch {
      // ignore
    }

    try {
      const ev2 = new KeyboardEvent("keydown", {
        key: "y",
        code: "KeyY",
        bubbles: true
      });
      document.body.dispatchEvent(ev2);
      await sleep(250);
      return true;
    } catch {
      // ignore
    }

    return false;
  }

  /**
   * Try to find the "Labels" button in the toolbar.
   * @returns {HTMLElement|null}
   */
  function findLabelButton() {
    const toolbar =
      document.querySelector("div[gh='mtb']") ||
      document.querySelector("div[role='toolbar']") ||
      document;

    const buttons = Array.from(
      toolbar.querySelectorAll("div[role='button'], button")
    );

    const scored = buttons
      .map((el) => {
        const label =
          (el.getAttribute("aria-label") ||
            el.getAttribute("data-tooltip") ||
            el.getAttribute("title") ||
            el.textContent ||
            "").trim();

        let score = 0;

        for (const token of LABEL_BUTTON_TOKENS) {
          if (label.toLowerCase().includes(token.toLowerCase())) {
            score += 2;
          }
        }

        if (/label/i.test(label)) score += 3;

        const child =
          el.querySelector("[aria-label],[data-tooltip],[title]") || null;
        const childLabel =
          (child &&
            (child.getAttribute("aria-label") ||
              child.getAttribute("data-tooltip") ||
              child.getAttribute("title"))) ||
          "";

        if (/label/i.test(childLabel)) score += 1;

        return { el, score };
      })
      .filter((entry) => entry.score > 0)
      .sort((a, b) => b.score - a.score);

    return scored.length ? scored[0].el : null;
  }

  /**
   * Apply a tag/label to the currently selected conversations.
   * If anything fails, it silently returns false so cleanup can continue.
   * @param {string} labelName
   * @returns {Promise<boolean>}
   */
  async function applyTagLabel(labelName) {
    if (!labelName) return false;

    const btn = findLabelButton();
    if (!btn) {
      safeSend({
        phase: "tag",
        status: "Label button not found; skipping tag.",
        detail: labelName
      });
      return false;
    }

    try {
      btn.click();
    } catch {
      return false;
    }

    // Wait for the label dialog / input to appear.
    const input = await waitFor(
      () =>
        document.querySelector("div[role='dialog'] input[aria-label*='Label as']") ||
        document.querySelector("div[role='dialog'] input[aria-label*='Apply one or more labels']") ||
        document.querySelector("div[role='dialog'] input[type='text']"),
      { timeout: 5000, interval: 200 }
    );

    if (!input) {
      safeSend({
        phase: "tag",
        status: "Label input not found; skipping tag.",
        detail: labelName
      });
      return false;
    }

    try {
      input.focus();
      input.value = "";
      input.dispatchEvent(new Event("input", { bubbles: true }));

      input.value = labelName;
      input.dispatchEvent(new Event("input", { bubbles: true }));

      // Press Enter to create/select the label and apply it.
      const down = new KeyboardEvent("keydown", {
        key: "Enter",
        code: "Enter",
        bubbles: true
      });
      const up = new KeyboardEvent("keyup", {
        key: "Enter",
        code: "Enter",
        bubbles: true
      });
      input.dispatchEvent(down);
      input.dispatchEvent(up);

      // Give Gmail a moment to apply labels and close dialog.
      await sleep(400);

      safeSend({
        phase: "tag",
        status: "Tagged selection before action.",
        detail: labelName
      });

      return true;
    } catch {
      return false;
    }
  }

  // =========================
  // Result detection helpers
  // =========================

  /**
   * Detect if the current search has no matching conversations.
   * @returns {boolean}
   */
  function hasNoResults() {
    const mainRoot = getMainRoot();
    const grid = mainRoot.querySelector(SELECTORS.grid);
    if (grid) {
      const rows = grid.querySelectorAll("tr[role='row']");
      if (rows && rows.length === 0) return true;
    }

    const spans = Array.from(mainRoot.querySelectorAll("span"));
    return spans.some((el) => {
      const text = el.innerText || "";
      return (
        text.includes("No messages matched your search") ||
        text.includes("Your search did not match any conversations")
      );
    });
  }

  /**
   * Parse a number from text like "1–50 of 2,345" or "About 5,432 results".
   * @param {string} text
   * @returns {number|null}
   */
  function parseCountFromText(text) {
    if (!text) return null;

    const ofMatch = text.match(/\bof\s+([\d,\.]+)/i);
    if (ofMatch) {
      const n = Number(ofMatch[1].replace(/[,\.\s]/g, ""));
      if (Number.isFinite(n) && n > 0) return n;
    }

    const aboutMatch = text.match(/\babout\s+([\d,\.]+)\s+results/i);
    if (aboutMatch) {
      const n = Number(aboutMatch[1].replace(/[,\.\s]/g, ""));
      if (Number.isFinite(n) && n > 0) return n;
    }

    return null;
  }

  /**
   * Try to estimate the total result count from Gmail's UI.
   * @returns {number|null}
   */
  function estimateTotalResults() {
    const mainRoot = getMainRoot();
    const nodes = Array.from(mainRoot.querySelectorAll("span, div"));

    for (const el of nodes) {
      const text = (el.innerText || "").trim();
      const n = parseCountFromText(text);
      if (n) return n;
    }

    return null;
  }

  /**
   * Extract the "X selected" count from Gmail's selection banner.
   * @returns {number|null}
   */
  function extractSelectedCount() {
    const spans = Array.from(document.querySelectorAll("span"));
    const banner = spans.find((el) =>
      /selected/i.test(el.innerText || "")
    );
    if (!banner) return null;

    const matches = (banner.innerText || "").match(/([\d,\.]+)/g);
    if (!matches) return null;

    const last = matches[matches.length - 1];
    const n = Number(last.replace(/[,\.\s]/g, ""));
    return Number.isFinite(n) ? n : null;
  }

  // =========================
  // Page action routine
  // =========================

  /**
   * Selects all messages on the current page and deletes/archives them (unless dryRun).
   * Returns stats about what happened.
   * @param {string|null} tagLabel
   * @returns {Promise<{deleted: boolean, count: number, reason?: string}>}
   */
  async function actOnCurrentPageIfAny(tagLabel) {
    if (hasNoResults()) {
      return { deleted: false, count: 0, reason: "No results" };
    }

    // Wait for the toolbar to appear.
    await waitFor(
      () =>
        document.querySelector("div[gh='mtb']") ||
        document.querySelector("div[role='toolbar']"),
      { timeout: 8000 }
    );

    if (!clickMasterCheckbox()) {
      return { deleted: false, count: 0, reason: "No master checkbox" };
    }

    await sleep(150);

    const selectedCount = extractSelectedCount();

    // Tag selection before action (live mode only), so users can audit.
    if (!CONFIG.dryRun && tagLabel && CONFIG.tagBeforeDelete) {
      try {
        await applyTagLabel(tagLabel);
      } catch (e) {
        safeSend({
          phase: "tag",
          status: "Error while tagging; continuing without tag.",
          detail: String(e)
        });
      }
    }

    // Dry-run only: don't actually delete/archive, just report.
    if (CONFIG.dryRun) {
      return {
        deleted: false,
        count: selectedCount ?? estimateTotalResults() ?? 0,
        reason: "dry-run"
      };
    }

    const estimatedTotal = selectedCount ?? estimateTotalResults();

    // Extra confirmation for extremely large destructive runs.
    if (
      !CONFIG.archiveInsteadOfDelete &&
      estimatedTotal &&
      estimatedTotal > 5000 &&
      !window.GCC_CONFIRMED_HUGE
    ) {
      const ok = confirm(
        `About to delete ~${estimatedTotal.toLocaleString()} conversations. Continue?`
      );
      if (!ok) {
        return { deleted: false, count: 0, reason: "user-cancelled" };
      }
      window.GCC_CONFIRMED_HUGE = true;
    }

    let okAction = false;
    if (CONFIG.archiveInsteadOfDelete) {
      okAction = await tryArchiveAction();
    } else {
      okAction = await tryDeleteAction();
    }

    if (!okAction) {
      return {
        deleted: false,
        count: 0,
        reason: CONFIG.archiveInsteadOfDelete ? "No archive button" : "No delete button"
      };
    }

    // Give Gmail time to process the action before the next pass.
    await sleep(500);

    return { deleted: true, count: selectedCount ?? 0 };
  }

  // =========================
  // Stats & per-query processing
  // =========================

  /**
   * @typedef {Object} QueryStats
   * @property {string} query
   * @property {string} label
   * @property {number} count
   * @property {"dry" | "live"} mode
   * @property {number} durationMs
   */

  /** @type {{ totalDeleted: number; totalWouldDelete: number; perQuery: QueryStats[] }} */
  const stats = {
    totalDeleted: 0,
    totalWouldDelete: 0,
    perQuery: []
  };

  /**
   * Run a single Gmail query through up to PASS_CAP passes until empty.
   * Handles both live and dry-run modes.
   * @param {string} query
   * @param {number} idx
   * @param {number} total
   */
  async function processQuery(query, idx, total) {
    const label = labelQuery(query);
    const tagLabel =
      !CONFIG.dryRun && CONFIG.tagBeforeDelete
        ? `${CONFIG.tagLabelPrefix || "GmailCleaner"} - ${label}`
        : null;
    const guardedQuery = applyGlobalGuards(query);
    const start = Date.now();
    let pass = 0;
    let queryDeletedCount = 0;

    while (pass < PASS_CAP) {
      if (CANCELLED) throw new Error("Cancelled");

      const percent = Math.round((idx / total) * 100);
      safeSend({
        phase: "query",
        status: `Cleaning ${label} (${idx + 1}/${total})`,
        detail: `Pass ${pass + 1}`,
        percent
      });

      await openSearch(guardedQuery);

      // If the search is already empty, record and exit.
      if (hasNoResults()) {
        const durationMs = Date.now() - start;
        const mode = CONFIG.dryRun ? "dry" : "live";

        safeSend({ detail: `No results for: ${guardedQuery}` });

        stats.perQuery.push({
          query,
          label,
          count: CONFIG.dryRun ? 0 : queryDeletedCount,
          mode,
          durationMs
        });

        safeSend({
          phase: "query-done",
          query,
          label,
          count: CONFIG.dryRun ? 0 : queryDeletedCount,
          mode,
          durationMs
        });

        break;
      }

      const result = await actOnCurrentPageIfAny(tagLabel);

      // Dry run: just capture estimated counts, never loop multiple passes.
      if (CONFIG.dryRun) {
        const durationMs = Date.now() - start;
        const count = result.count ?? estimateTotalResults() ?? 0;

        stats.totalWouldDelete += count;
        stats.perQuery.push({
          query,
          label,
          count,
          mode: "dry",
          durationMs
        });

        safeSend({
          detail: `Dry-Run: would affect ${count} for: ${guardedQuery}`
        });

        safeSend({
          phase: "query-done",
          query,
          label,
          count,
          mode: "dry",
          durationMs
        });

        break;
      }

      // Live mode but nothing actually acted on (no checkbox, no button, etc.).
      if (!result.deleted) {
        const durationMs = Date.now() - start;

        stats.perQuery.push({
          query,
          label,
          count: queryDeletedCount,
          mode: "live",
          durationMs
        });

        safeSend({
          detail: `Nothing to act on for: ${guardedQuery} (${result.reason})`
        });

        safeSend({
          phase: "query-done",
          query,
          label,
          count: queryDeletedCount,
          mode: "live",
          durationMs
        });

        break;
      }

      // Successful action for this pass.
      const affectedThisPass = result.count || 0;
      queryDeletedCount += affectedThisPass;
      stats.totalDeleted += affectedThisPass;
      pass += 1;

      await sleep(650);

      // Stop if the query has become empty after this pass.
      if (hasNoResults()) {
        const durationMs = Date.now() - start;

        stats.perQuery.push({
          query,
          label,
          count: queryDeletedCount,
          mode: "live",
          durationMs
        });

        safeSend({
          phase: "query-done",
          query,
          label,
          count: queryDeletedCount,
          mode: "live",
          durationMs
        });

        break;
      }
    }
  }

  // =========================
  // Main driver
  // =========================

  /**
   * Main cleanup flow for all rules.
   */
  async function main() {
    if (RUNNING) return;
    RUNNING = true;

    // fresh run state
    CANCELLED = false;
    stats.totalDeleted = 0;
    stats.totalWouldDelete = 0;
    stats.perQuery.length = 0;

    try {
      if (!isGmailTab()) {
        alert("Gmail Cleaner: run this from a Gmail tab.");
        return;
      }

      const rawRules = await getRules(CONFIG.intensity);
      const rules = (rawRules || []).filter(
        (q) => typeof q === "string" && q.trim().length > 0
      );
      const total = rules.length;

      if (!total) {
        const mode = CONFIG.dryRun ? "dry" : "live";
        safeSend({
          phase: "done",
          status: "No rules to run.",
          detail: "Rule set is empty.",
          percent: 100,
          done: true,
          stats: {
            mode,
            totalDeleted: 0,
            totalWouldDelete: 0,
            totalQueries: 0
          }
        });
        return;
      }

      safeSend({
        phase: "starting",
        status: "Starting Gmail cleanup...",
        detail: `Level: ${CONFIG.intensity}. ${total} queries. ` +
          (CONFIG.archiveInsteadOfDelete ? "Mode: Archive." : "Mode: Delete.") +
          (CONFIG.minAge ? ` Min age: ${CONFIG.minAge}.` : ""),
        percent: 0
      });

      for (let i = 0; i < rules.length; i++) {
        if (CANCELLED) throw new Error("Cancelled");
        await processQuery(rules[i], i, total);
      }

      const mode = CONFIG.dryRun ? "dry" : "live";
      const doneStats = {
        mode,
        totalDeleted: stats.totalDeleted,
        totalWouldDelete: stats.totalWouldDelete,
        totalQueries: total
      };

      // Enrich stats so the UI can decide when to show a tip prompt.
      const runCountForThisRun =
        doneStats.mode === "dry"
          ? doneStats.totalWouldDelete || 0
          : doneStats.totalDeleted || 0;

      let sizeBucket = "tiny";
      if (runCountForThisRun >= 500 && runCountForThisRun < 2500) {
        sizeBucket = "small";
      } else if (runCountForThisRun >= 2500 && runCountForThisRun < 10000) {
        sizeBucket = "medium";
      } else if (runCountForThisRun >= 10000) {
        sizeBucket = "huge";
      }

      doneStats.runCount = runCountForThisRun;
      doneStats.sizeBucket = sizeBucket;
      doneStats.isHugeRun = runCountForThisRun >= 5000;

      safeSend({
        phase: "done",
        status: "Cleanup finished.",
        detail: "All queries processed.",
        percent: 100,
        done: true,
        stats: doneStats
      });

      // If Pro is active, update lifetime stats in sync storage.
      try {
        if (
          typeof chrome !== "undefined" &&
          chrome.storage &&
          chrome.storage.sync
        ) {
          chrome.storage.sync.get(
            ["proStatus", "proLifetimeStats"],
            (res = {}) => {
              try {
                const proStatus = res.proStatus;
                if (!proStatus || !proStatus.isPro) return;

                const prev = res.proLifetimeStats || {};
                const runCount =
                  doneStats.mode === "dry"
                    ? doneStats.totalWouldDelete || 0
                    : doneStats.totalDeleted || 0;

                const next = {
                  totalRuns: (prev.totalRuns || 0) + 1,
                  totalDeleted:
                    (prev.totalDeleted || 0) +
                    (doneStats.totalDeleted || 0),
                  totalWouldDelete:
                    (prev.totalWouldDelete || 0) +
                    (doneStats.totalWouldDelete || 0),
                  totalQueries:
                    (prev.totalQueries || 0) + (doneStats.totalQueries || 0),
                  biggestRun: Math.max(prev.biggestRun || 0, runCount)
                };

                chrome.storage.sync.set({ proLifetimeStats: next }, () => {
                  // ignore errors
                });
              } catch {
                // ignore errors updating stats
              }
            }
          );
        }
      } catch {
        // ignore errors updating stats
      }

      if (!CONFIG.dryRun) {
        const actionWord = CONFIG.archiveInsteadOfDelete ? "archived/cleaned" : "deleted";
        alert(`Gmail Cleaner finished. Check ${CONFIG.archiveInsteadOfDelete ? "All Mail" : "Trash"} to restore if needed.\n\nConversations ${actionWord}: ${stats.totalDeleted.toLocaleString()}`);
      }
    } catch (e) {
      const message = String(e);

      if (message.includes("Cancelled")) {
        safeSend({
          phase: "cancelled",
          status: "Run cancelled.",
          detail: "Stopped by user.",
          done: true,
          percent: 100
        });
      } else {
        console.error(e);
        safeSend({
          phase: "error",
          status: "Error occurred.",
          detail: message
        });
      }
    } finally {
      RUNNING = false;
    }
  }

  /**
   * Public entry to start the main run (used by messages and auto-start).
   */
  function startMain() {
    if (!RUNNING) main();
  }

  // Auto-start once on injection so the progress page can just attach and go.
  startMain();
})();
