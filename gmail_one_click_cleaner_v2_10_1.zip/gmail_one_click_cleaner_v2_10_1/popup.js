document.addEventListener("DOMContentLoaded", () => {
  "use strict";

  const $ = (id) => document.getElementById(id);

  const runBtn = $("runCleanup");
  const statusEl = $("status");
  const intensityEl = $("intensity");
  const dryRunEl = $("dryRun");
  const safeModeEl = $("safeMode");
  const openOptionsBtn = $("openOptions");

  if (!runBtn || !statusEl || !intensityEl || !dryRunEl || !safeModeEl) {
    console.error("[Gmail Cleaner] Popup DOM not found as expected.");
    return;
  }

  const runLabelSpan = runBtn.querySelector(".label");
  const runSubSpan = runBtn.querySelector(".sub");
  const originalLabel =
    (runLabelSpan && runLabelSpan.textContent) || runBtn.textContent || "Run";
  const originalSub = (runSubSpan && runSubSpan.textContent) || "";

  /**
   * Set run button state (disabled + label/sub text) safely.
   */
  function setRunButtonState({ disabled, label, sub }) {
    runBtn.disabled = !!disabled;

    if (runLabelSpan && typeof label === "string") {
      runLabelSpan.textContent = label;
    } else if (typeof label === "string") {
      runBtn.textContent = label;
    }

    if (runSubSpan && typeof sub === "string") {
      runSubSpan.textContent = sub;
    }
  }

  /**
   * Update status text (clears previous content).
   */
  function setStatus(message) {
    if (!statusEl) return;
    statusEl.textContent = message || "";
  }

  /**
   * Try to restore last used settings into the popup controls.
   * Uses session storage first, then falls back to local if needed.
   */
  async function restoreLastConfig() {
    try {
      let lastConfig = null;

      // session storage first
      try {
        const sessionResult = await chrome.storage.session.get("lastConfig");
        lastConfig = sessionResult.lastConfig || null;
      } catch {
        // session storage might not be available, fall through to local
      }

      if (!lastConfig) {
        const localResult = await chrome.storage.local.get("lastConfig");
        lastConfig = localResult.lastConfig || null;
      }

      if (!lastConfig || typeof lastConfig !== "object") return;

      if (
        lastConfig.intensity &&
        intensityEl.querySelector(`option[value="${lastConfig.intensity}"]`)
      ) {
        intensityEl.value = lastConfig.intensity;
      }

      if (typeof lastConfig.dryRun === "boolean") {
        dryRunEl.checked = lastConfig.dryRun;
      }

      if (typeof lastConfig.safeMode === "boolean") {
        safeModeEl.checked = lastConfig.safeMode;
      }
    } catch (err) {
      console.warn("[Gmail Cleaner] Failed to restore last config.", err);
    }
  }

  /**
   * Persist the current config for reuse by the progress page / next opens.
   */
  async function persistLastConfig(config) {
    try {
      await chrome.storage.session.set({ lastConfig: config });
    } catch {
      try {
        await chrome.storage.local.set({ lastConfig: config });
      } catch {
        // Not critical; ignore.
      }
    }
  }

  /**
   * Open the options page in a new tab.
   */
  if (openOptionsBtn) {
    openOptionsBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      try {
        const url = chrome.runtime.getURL("options.html");
        await chrome.tabs.create({ url });
      } catch (err) {
        console.error("[Gmail Cleaner] Failed to open options.", err);
      }
    });
  }

  /**
   * Find an appropriate Gmail tab in the current window.
   * Prefer the active tab the user clicked the extension from.
   */
  async function findGmailTab() {
    try {
      // First, prefer the tab where the popup was opened (active tab).
      const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true
      });

      if (
        activeTab &&
        typeof activeTab.id === "number" &&
        typeof activeTab.url === "string" &&
        activeTab.url.startsWith("https://mail.google.com/")
      ) {
        return activeTab;
      }

      // Fallback: any Gmail tab in the current window.
      const tabs = await chrome.tabs.query({
        url: "https://mail.google.com/*",
        currentWindow: true
      });

      if (!tabs || !tabs.length) return null;

      const active = tabs.find(
        (t) =>
          t.active &&
          typeof t.url === "string" &&
          t.url.startsWith("https://mail.google.com/")
      );
      return active || tabs[0];
    } catch (err) {
      console.error("[Gmail Cleaner] Error while finding Gmail tab:", err);
      return null;
    }
  }

  /**
   * Show a small "Open Gmail" helper if no Gmail tab is found.
   */
  function showOpenGmailHelper() {
    if (!statusEl) return;

    setStatus("Open Gmail first, then try again.");

    const existing = statusEl.querySelector("button.open-gmail-helper");
    if (existing) return;

    const openBtn = document.createElement("button");
    openBtn.type = "button";
    openBtn.className = "open-gmail-helper";
    openBtn.textContent = "Open Gmail";
    openBtn.style.marginTop = "8px";
    openBtn.style.padding = "4px 10px";
    openBtn.style.borderRadius = "999px";
    openBtn.style.border = "1px solid rgba(148,163,184,0.7)";
    openBtn.style.background = "rgba(15,23,42,0.9)";
    openBtn.style.color = "#e5e7eb";
    openBtn.style.fontSize = "11px";
    openBtn.style.cursor = "pointer";

    openBtn.onclick = async () => {
      try {
        await chrome.tabs.create({
          url: "https://mail.google.com/mail/u/0/#inbox"
        });
      } catch (err) {
        console.error("[Gmail Cleaner] Failed to open Gmail.", err);
      }
    };

    statusEl.appendChild(openBtn);
  }

  /**
   * Main click handler for "Run one-click cleanup".
   */
  runBtn.addEventListener("click", async () => {
    setRunButtonState({
      disabled: true,
      label: "Starting...",
      sub: "Locating Gmail & attaching cleaner"
    });
    setStatus("Locating a Gmail tab...");

    try {
      const gmailTab = await findGmailTab();

      if (!gmailTab || typeof gmailTab.id !== "number") {
        showOpenGmailHelper();
        setRunButtonState({
          disabled: false,
          label: originalLabel,
          sub: originalSub
        });
        return;
      }

      const config = {
        intensity: intensityEl.value,
        dryRun: !!dryRunEl.checked,
        safeMode: !!safeModeEl.checked
      };

      await persistLastConfig(config);

      // Update button copy based on mode before we launch everything.
      setRunButtonState({
        disabled: true,
        label: config.dryRun ? "Starting dry-run..." : "Starting cleanup...",
        sub: config.dryRun
          ? "No mail will be moved to Trash"
          : "Tagging, then moving old mail to Trash"
      });
      setStatus(
        config.dryRun
          ? "Dry-run mode: counting matches without deleting."
          : "Live mode: messages will be tagged, then moved to Trash."
      );

      // Open progress page with Gmail tab id.
      const progressUrl = chrome.runtime.getURL(
        `progress.html?gmailTabId=${gmailTab.id}`
      );
      await chrome.tabs.create({ url: progressUrl, active: true });

      // Inject config into Gmail tab so the content script reads it.
      await chrome.scripting.executeScript({
        target: { tabId: gmailTab.id },
        func: (cfg) => {
          // This code runs in the Gmail page context.
          window.GMAIL_CLEANER_CONFIG = cfg;
        },
        args: [config]
      });

      // Inject / run the content script that performs the cleanup.
      await chrome.scripting.executeScript({
        target: { tabId: gmailTab.id },
        files: ["contentScript.js"]
      });

      // Close popup once everything has kicked off.
      window.close();
    } catch (err) {
      console.error("[Gmail Cleaner] Error starting cleanup:", err);
      setStatus(`Error: ${err?.message || String(err)}`);
      setRunButtonState({
        disabled: false,
        label: originalLabel,
        sub: originalSub
      });
    }
  });

  // Tip link/buttons: click handler for older UI versions with tip buttons.
  (function attachTipHandler() {
    const TIP_URL = "https://cash.app/$judeh1l";
    const wrap = document.getElementById("tipButtons");
    if (!wrap) return;

    wrap.addEventListener("click", async (e) => {
      const btn = e.target.closest("button.tip");
      if (!btn) return;

      const amt = btn.getAttribute("data-amt") || null;
      const url = TIP_URL; // Let user adjust amount on the Cash App page.

      try {
        await chrome.tabs.create({ url });
        try {
          const when = Date.now();
          await chrome.storage.local.set({
            lastTipIntentAt: when,
            lastTipIntentAmount: amt,
            lastTipIntentSource: "cashapp-legacy"
          });
        } catch {
          // Not critical if logging fails.
        }
      } catch {
        // Ignore navigation errors.
      }
    });
  })();

  // Tip handler for the footer support links (Buy Me a Coffee + Cash App).
  (function attachFooterTipLinkHandler() {
    const BMC_URL = "https://www.buymeacoffee.com/judeh1l";
    const CASH_URL = "https://cash.app/$judeh1l";

    const links = document.querySelectorAll(
      `a[href="${BMC_URL}"], a[href="${CASH_URL}"]`
    );
    if (!links.length) return;

    links.forEach((footerTipLink) => {
      footerTipLink.addEventListener("click", async (e) => {
        e.preventDefault();

        const url = footerTipLink.href || BMC_URL;
        const source = url.includes("buymeacoffee.com")
          ? "buymeacoffee"
          : "cashapp";

        try {
          await chrome.tabs.create({ url });

          try {
            const when = Date.now();
            await chrome.storage.local.set({
              lastTipIntentAt: when,
              lastTipIntentSource: source
            });
          } catch {
            // Logging isn't critical.
          }
        } catch {
          // Ignore navigation errors.
        }

        // Close popup so the user is left with Gmail + tip tab.
        window.close();
      });
    });
  })();

  // Allow Enter (outside inputs) to trigger the run button for speed.
  document.addEventListener("keydown", (evt) => {
    if (evt.key !== "Enter") return;
    const target = evt.target;
    if (!target) return;

    const tag = target.tagName;
    // Don't hijack Enter inside form controls.
    if (tag === "INPUT" || tag === "SELECT" || tag === "BUTTON" || tag === "TEXTAREA") {
      return;
    }

    if (!runBtn.disabled) {
      runBtn.click();
    }
  });

  // Initialize popup with last used settings (if available).
  restoreLastConfig().catch(() => {});
});
