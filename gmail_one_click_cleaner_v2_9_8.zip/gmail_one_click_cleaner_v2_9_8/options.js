(async () => {
  "use strict";

  // Simple helper to grab elements by ID.
  const $ = (id) => document.getElementById(id);

  // Safe clone helper for rules.
  const clone = (obj) => {
    if (typeof structuredClone === "function") return structuredClone(obj);
    try {
      return JSON.parse(JSON.stringify(obj));
    } catch {
      return obj;
    }
  };

  const RULE_KEYS = ["light", "normal", "deep"];

  // Default rule sets, mirrored with the content script.
  const DEFAULT_RULES = {
    light: [
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "category:promotions older_than:1y",
      "category:social older_than:1y",
      "\"unsubscribe\" older_than:2y"
    ],
    normal: [
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "has:attachment larger:5M older_than:2y",
      "category:promotions older_than:3m",
      "category:promotions older_than:1y",
      "category:social older_than:6m",
      "category:updates older_than:6m",
      "category:forums older_than:6m",
      "has:newsletter older_than:6m",
      "\"unsubscribe\" older_than:1y",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:6m"
    ],
    deep: [
      "larger:20M",
      "has:attachment larger:10M older_than:3m",
      "has:attachment larger:5M older_than:1y",
      "category:promotions older_than:2m",
      "category:promotions older_than:6m",
      "category:social older_than:3m",
      "category:social older_than:6m",
      "category:updates older_than:3m",
      "category:forums older_than:3m",
      "has:newsletter older_than:3m",
      "\"unsubscribe\" older_than:6m",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:3m"
    ]
  };

  const state = {
    saving: false
  };

  const hasSyncStorage = () =>
    typeof chrome !== "undefined" &&
    chrome.storage &&
    chrome.storage.sync &&
    typeof chrome.storage.sync.get === "function" &&
    typeof chrome.storage.sync.set === "function";

  /**
   * Ensure we have a rules object with the right shape.
   * Falls back to defaults if anything looks off.
   * @param {any} rules
   * @returns {{light:string[],normal:string[],deep:string[]}}
   */
  function normalizeRules(rules) {
    if (!rules || typeof rules !== "object") return clone(DEFAULT_RULES);

    const out = { light: [], normal: [], deep: [] };

    for (const key of RULE_KEYS) {
      const source = Array.isArray(rules[key]) ? rules[key] : DEFAULT_RULES[key];
      out[key] = (source || []).filter(
        (line) => typeof line === "string" && line.trim().length
      );
    }

    return out;
  }

  /**
   * Populate textareas from a rules object.
   * @param {{light:string[],normal:string[],deep:string[]}} rules
   */
  function renderRules(rules) {
    if ($("light")) $("light").value = (rules.light || []).join("\n");
    if ($("normal")) $("normal").value = (rules.normal || []).join("\n");
    if ($("deep")) $("deep").value = (rules.deep || []).join("\n");
  }

  /**
   * Parse textarea contents into clean rule arrays.
   * @param {string} id
   * @returns {string[]}
   */
  function readLines(id) {
    const el = $(id);
    if (!el) return [];
    return el.value
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
  }

  /**
   * Load rules from sync storage (or defaults) and render into the UI.
   */
  const load = async () => {
    try {
      if (!hasSyncStorage()) {
        renderRules(clone(DEFAULT_RULES));
        return;
      }

      const { rules } = await chrome.storage.sync.get("rules");
      const normalized = normalizeRules(rules);
      renderRules(normalized);
    } catch (err) {
      console.error("[Gmail Cleaner] Failed to load rules, using defaults.", err);
      renderRules(clone(DEFAULT_RULES));
    }
  };

  /**
   * Save current textarea values into sync storage.
   */
  const save = async (evt) => {
    evt?.preventDefault?.();

    if (state.saving) return;
    state.saving = true;

    const btn = $("save");
    const originalLabel = btn ? btn.textContent : null;
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Saving...";
    }

    try {
      const rules = {
        light: readLines("light"),
        normal: readLines("normal"),
        deep: readLines("deep")
      };

      if (!hasSyncStorage()) {
        throw new Error("chrome.storage.sync is not available");
      }

      await chrome.storage.sync.set({ rules });
      alert("Rules saved.");
    } catch (err) {
      console.error("[Gmail Cleaner] Failed to save rules.", err);
      alert("Could not save rules. Please try again.");
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = originalLabel;
      }
      state.saving = false;
    }
  };

  function init() {
    const saveBtn = $("save");
    if (saveBtn) {
      saveBtn.addEventListener("click", save);
    }
    load();
  }

  if (document.readyState === "loading") {
    window.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
