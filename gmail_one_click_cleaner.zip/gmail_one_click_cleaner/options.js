(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);

  const RULE_KEYS = ["light", "normal", "deep"];

  // Keep these in sync with the content script defaults.
  const DEFAULT_RULES = {
    light: [
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "category:promotions older_than:1y",
      "category:social older_than:1y",
      "\"unsubscribe\" older_than:2y"
    ],
    normal: [
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "has:attachment larger:5M older_than:2y",
      "category:promotions older_than:3m",
      "category:promotions older_than:1y",
      "category:social older_than:6m",
      "category:updates older_than:6m",
      "category:forums older_than:6m",
      "has:newsletter older_than:6m",
      "\"unsubscribe\" older_than:1y",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:6m"
    ],
    deep: [
      "larger:20M",
      "has:attachment larger:10M older_than:3m",
      "has:attachment larger:5M older_than:1y",
      "category:promotions older_than:2m",
      "category:promotions older_than:6m",
      "category:social older_than:3m",
      "category:social older_than:6m",
      "category:updates older_than:3m",
      "category:forums older_than:3m",
      "has:newsletter older_than:3m",
      "\"unsubscribe\" older_than:6m",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:3m"
    ]
  };

  const state = {
    saving: false
  };

  const clone = (obj) => {
    if (typeof structuredClone === "function") return structuredClone(obj);
    try {
      return JSON.parse(JSON.stringify(obj));
    } catch {
      return obj;
    }
  };

  const hasSyncStorage = () => {
    try {
      return (
        typeof chrome !== "undefined" &&
        chrome.storage &&
        chrome.storage.sync &&
        typeof chrome.storage.sync.get === "function" &&
        typeof chrome.storage.sync.set === "function"
      );
    } catch {
      return false;
    }
  };

  // ---- Rules & Settings ----

  function normalizeRules(rules) {
    if (!rules || typeof rules !== "object") return clone(DEFAULT_RULES);

    const out = { light: [], normal: [], deep: [] };

    for (const key of RULE_KEYS) {
      const source = Array.isArray(rules[key]) ? rules[key] : DEFAULT_RULES[key];
      out[key] = (source || []).filter(
        (line) => typeof line === "string" && line.trim().length
      );
    }

    return out;
  }

  function renderRules(rules) {
    const light = $("light");
    const normal = $("normal");
    const deep = $("deep");

    if (light) light.value = (rules.light || []).join("\n");
    if (normal) normal.value = (rules.normal || []).join("\n");
    if (deep) deep.value = (rules.deep || []).join("\n");
  }
  
  function renderSettings(settings) {
    const debugEl = $("debugMode");
    if (debugEl) {
      debugEl.checked = !!settings.debugMode;
    }
    
    // v3.0: Render Whitelist
    const whitelistEl = $("whitelist");
    if (whitelistEl) {
        whitelistEl.value = Array.isArray(settings.whitelist) 
            ? settings.whitelist.join("\n") 
            : "";
    }
  }

  function readLines(id) {
    const el = $(id);
    if (!el) return [];
    return el.value
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
  }

  /**
   * Load rules and settings from storage.
   */
  async function loadData() {
    try {
      if (!hasSyncStorage()) {
        renderRules(clone(DEFAULT_RULES));
        return;
      }

      // Fetch 'rules', 'debugMode', and 'whitelist'
      const data = await chrome.storage.sync.get(["rules", "debugMode", "whitelist"]);
      
      const normalizedRules = normalizeRules(data.rules);
      renderRules(normalizedRules);
      
      renderSettings({ 
          debugMode: data.debugMode,
          whitelist: data.whitelist || []
      });
    } catch (err) {
      console.error("[Gmail Cleaner] Failed to load settings.", err);
      renderRules(clone(DEFAULT_RULES));
    }
  }

  /**
   * Main Save Function
   */
  async function saveData(evt) {
    evt?.preventDefault?.();

    if (state.saving) return;
    state.saving = true;

    const btn = $("save");
    const originalLabel = btn ? btn.textContent : null;

    if (btn) {
      btn.disabled = true;
      btn.textContent = "Saving...";
    }

    try {
      // 1. Collect rules
      const rules = {
        light: readLines("light"),
        normal: readLines("normal"),
        deep: readLines("deep")
      };

      // 2. Collect advanced settings
      const debugEl = $("debugMode");
      const debugMode = debugEl ? debugEl.checked : false;

      // 3. Collect whitelist (v3.0)
      const whitelist = readLines("whitelist");

      if (!hasSyncStorage()) {
        throw new Error("chrome.storage.sync is not available");
      }

      // 4. Save everything
      await chrome.storage.sync.set({ rules, debugMode, whitelist });
      
      alert("Settings and rules saved.");
    } catch (err) {
      console.error("[Gmail Cleaner] Failed to save.", err);
      alert("Could not save. Please try again.");
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = originalLabel;
      }
      state.saving = false;
    }
  }

  /**
   * Restore defaults for all fields
   */
  async function restoreDefaults() {
      if(!confirm("Are you sure you want to reset all rules and settings to default? This cannot be undone.")) return;

      renderRules(clone(DEFAULT_RULES));
      if($("whitelist")) $("whitelist").value = "";
      if($("debugMode")) $("debugMode").checked = false;
      
      // Auto-save the reset state
      await saveData();
  }

  // ---- Import / Export (v3.0) ----

  async function exportConfig() {
    if (!hasSyncStorage()) return alert("Storage not available");
    
    try {
        const data = await chrome.storage.sync.get(["rules", "debugMode", "whitelist"]);
        const exportObj = {
            rules: data.rules || DEFAULT_RULES,
            debugMode: !!data.debugMode,
            whitelist: data.whitelist || [],
            exportedAt: new Date().toISOString(),
            version: "3.0.0"
        };
        
        const blob = new Blob([JSON.stringify(exportObj, null, 2)], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement("a");
        a.href = url;
        a.download = `gmail-cleaner-config-${new Date().toISOString().slice(0,10)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    } catch (e) {
        console.error("Export failed", e);
        alert("Export failed: " + e.message);
    }
  }

  function triggerImport() {
      const fileInput = $("importFile");
      if(fileInput) fileInput.click();
  }

  function handleImportFile(evt) {
      const file = evt.target.files[0];
      if(!file) return;

      const reader = new FileReader();
      reader.onload = async (e) => {
          try {
              const json = JSON.parse(e.target.result);
              
              // Basic validation
              if (!json.rules || !json.rules.normal) {
                  throw new Error("Invalid configuration file format.");
              }

              const confirmMsg = `Load config from file?\nIncludes ${json.whitelist ? json.whitelist.length : 0} whitelist items and ${json.rules.normal.length} normal rules.`;
              if(!confirm(confirmMsg)) {
                  $("importFile").value = ""; // reset
                  return;
              }

              // Update Storage
              await chrome.storage.sync.set({
                  rules: json.rules,
                  debugMode: !!json.debugMode,
                  whitelist: json.whitelist || []
              });

              // Refresh UI
              await loadData();
              alert("Configuration imported successfully!");

          } catch (err) {
              console.error("Import error", err);
              alert("Failed to import: " + err.message);
          } finally {
              $("importFile").value = ""; // reset so same file can be selected again
          }
      };
      reader.readAsText(file);
  }

  function init() {
    const saveBtn = $("save");
    if (saveBtn) {
      saveBtn.addEventListener("click", saveData);
    }
    
    const restoreBtn = $("restoreDefaultsBtn");
    if (restoreBtn) {
        restoreBtn.addEventListener("click", restoreDefaults);
    }

    const exportBtn = $("exportBtn");
    if(exportBtn) {
        exportBtn.addEventListener("click", exportConfig);
    }

    const importBtn = $("importBtn");
    if(importBtn) {
        importBtn.addEventListener("click", triggerImport);
    }

    const fileInput = $("importFile");
    if(fileInput) {
        fileInput.addEventListener("change", handleImportFile);
    }
    
    loadData();
  }

  if (document.readyState === "loading") {
    window.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();