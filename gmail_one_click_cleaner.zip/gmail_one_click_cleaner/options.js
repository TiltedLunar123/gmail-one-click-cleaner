(() => {
  "use strict";

  // =========================
  // Constants & Configuration
  // =========================

  const OPTIONS_VERSION = "3.1.0";

  const CONFIG = Object.freeze({
    TOAST_DURATION_MS: 3000,
    DEBOUNCE_DELAY_MS: 300,
    SAVE_SUCCESS_DURATION_MS: 2000,
    MAX_WHITELIST_ENTRIES: 100,
    MAX_RULES_PER_CATEGORY: 50
  });

  const STORAGE_KEYS = Object.freeze({
    RULES: "rules",
    DEBUG_MODE: "debugMode",
    WHITELIST: "whitelist"
  });

  const RULE_KEYS = Object.freeze(["light", "normal", "deep"]);

  // Keep these in sync with the content script defaults.
  const DEFAULT_RULES = Object.freeze({
    light: Object.freeze([
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "category:promotions older_than:1y",
      "category:social older_than:1y",
      "\"unsubscribe\" older_than:2y"
    ]),
    normal: Object.freeze([
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "has:attachment larger:5M older_than:2y",
      "category:promotions older_than:3m",
      "category:promotions older_than:1y",
      "category:social older_than:6m",
      "category:updates older_than:6m",
      "category:forums older_than:6m",
      "has:newsletter older_than:6m",
      "\"unsubscribe\" older_than:1y",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:6m"
    ]),
    deep: Object.freeze([
      "larger:20M",
      "has:attachment larger:10M older_than:3m",
      "has:attachment larger:5M older_than:1y",
      "category:promotions older_than:2m",
      "category:promotions older_than:6m",
      "category:social older_than:3m",
      "category:social older_than:6m",
      "category:updates older_than:3m",
      "category:forums older_than:3m",
      "has:newsletter older_than:3m",
      "\"unsubscribe\" older_than:6m",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:3m"
    ])
  });

  // =========================
  // State Management
  // =========================

  const state = {
    saving: false,
    hasUnsavedChanges: false,
    initialData: null,
    toastQueue: []
  };

  // =========================
  // Utility Functions
  // =========================

  /**
   * Safely get element by ID.
   * @param {string} id
   * @returns {HTMLElement | null}
   */
  const $ = (id) => document.getElementById(id);

  /**
   * Safely query for an element.
   * @param {string} selector
   * @returns {Element | null}
   */
  const qs = (selector) => {
    try {
      return document.querySelector(selector);
    } catch {
      return null;
    }
  };

  /**
   * Deep clone an object.
   * @template T
   * @param {T} obj
   * @returns {T}
   */
  const clone = (obj) => {
    if (typeof structuredClone === "function") {
      try {
        return structuredClone(obj);
      } catch {
        // Fall through to JSON method
      }
    }
    try {
      return JSON.parse(JSON.stringify(obj));
    } catch {
      return obj;
    }
  };

  /**
   * Debounce a function.
   * @template {(...args: any[]) => any} T
   * @param {T} fn
   * @param {number} delay
   * @returns {T}
   */
  const debounce = (fn, delay) => {
    let timeoutId = null;
    return /** @type {T} */ ((...args) => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => fn(...args), delay);
    });
  };

  /**
   * Check if Chrome sync storage is available.
   * @returns {boolean}
   */
  const hasSyncStorage = () => {
    try {
      return (
        typeof chrome !== "undefined" &&
        chrome?.storage?.sync &&
        typeof chrome.storage.sync.get === "function" &&
        typeof chrome.storage.sync.set === "function"
      );
    } catch {
      return false;
    }
  };

  /**
   * Get current timestamp for export filename.
   * @returns {string}
   */
  const getDateStamp = () => {
    return new Date().toISOString().slice(0, 10);
  };

  /**
   * Escape HTML to prevent XSS.
   * @param {string} str
   * @returns {string}
   */
  const escapeHtml = (str) => {
    if (typeof str !== "string") return "";
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  };

  // =========================
  // Toast Notifications
  // =========================

  /**
   * @typedef {"success" | "error" | "warning" | "info"} ToastType
   */

  const TOAST_ICONS = Object.freeze({
    success: "✅",
    error: "❌",
    warning: "⚠️",
    info: "ℹ️"
  });

  /**
   * Show a toast notification.
   * @param {string} message
   * @param {ToastType} [type="info"]
   * @param {number} [duration]
   */
  const showToast = (message, type = "info", duration = CONFIG.TOAST_DURATION_MS) => {
    const container = qs(".toast-container");
    if (!container) {
      // Fallback to console if toast container doesn't exist
      console.log(`[Toast ${type}] ${message}`);
      return;
    }

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.setAttribute("role", "alert");
    
    const icon = document.createElement("span");
    icon.className = "toast-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = TOAST_ICONS[type] || TOAST_ICONS.info;
    
    const text = document.createElement("span");
    text.textContent = message;
    
    toast.appendChild(icon);
    toast.appendChild(text);
    container.appendChild(toast);

    // Trigger animation
    requestAnimationFrame(() => {
      toast.classList.add("show");
    });

    // Remove after duration
    setTimeout(() => {
      toast.classList.remove("show");
      setTimeout(() => {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, duration);
  };

  // =========================
  // Button State Management
  // =========================

  /**
   * Set button loading state.
   * @param {HTMLButtonElement | null} btn
   * @param {boolean} loading
   * @param {string} [loadingText]
   */
  const setButtonLoading = (btn, loading, loadingText) => {
    if (!btn) return;

    btn.disabled = loading;

    if (loading) {
      btn.classList.add("loading");
      btn.setAttribute("aria-busy", "true");
      if (loadingText) {
        btn.dataset.originalText = btn.textContent || "";
        const textSpan = btn.querySelector(".save-text");
        if (textSpan) {
          textSpan.textContent = loadingText;
        } else {
          btn.textContent = loadingText;
        }
      }
    } else {
      btn.classList.remove("loading");
      btn.removeAttribute("aria-busy");
      if (btn.dataset.originalText) {
        const textSpan = btn.querySelector(".save-text");
        if (textSpan) {
          textSpan.textContent = btn.dataset.originalText;
        } else {
          btn.textContent = btn.dataset.originalText;
        }
        delete btn.dataset.originalText;
      }
    }
  };

  /**
   * Show success state on save button.
   * @param {HTMLButtonElement | null} btn
   */
  const showButtonSuccess = (btn) => {
    if (!btn) return;

    btn.classList.add("success");
    const textSpan = btn.querySelector(".save-text");
    const originalText = textSpan?.textContent || btn.textContent;

    if (textSpan) {
      textSpan.textContent = "Saved!";
    } else {
      btn.textContent = "Saved!";
    }

    setTimeout(() => {
      btn.classList.remove("success");
      if (textSpan) {
        textSpan.textContent = originalText || "Save rules";
      } else {
        btn.textContent = originalText || "Save rules";
      }
    }, CONFIG.SAVE_SUCCESS_DURATION_MS);
  };

  // =========================
  // Unsaved Changes Tracking
  // =========================

  /**
   * Update the unsaved changes indicator.
   */
  const updateUnsavedIndicator = () => {
    const indicator = $("unsavedIndicator");
    if (!indicator) return;

    if (state.hasUnsavedChanges) {
      indicator.classList.add("show");
    } else {
      indicator.classList.remove("show");
    }

    // Update page title
    document.title = state.hasUnsavedChanges
      ? "• Gmail One-Click Cleaner – Rules & Settings"
      : "Gmail One-Click Cleaner – Rules & Settings";
  };

  /**
   * Mark as having unsaved changes.
   */
  const markUnsaved = () => {
    state.hasUnsavedChanges = true;
    updateUnsavedIndicator();
  };

  /**
   * Clear unsaved changes flag.
   */
  const clearUnsaved = () => {
    state.hasUnsavedChanges = false;
    updateUnsavedIndicator();
  };

  /**
   * Check if current data differs from initial data.
   * @returns {boolean}
   */
  const hasDataChanged = () => {
    if (!state.initialData) return false;

    const currentData = collectAllData();
    return JSON.stringify(currentData) !== JSON.stringify(state.initialData);
  };

  /**
   * Set up change listeners on form elements.
   */
  const setupChangeListeners = () => {
    const textareas = ["light", "normal", "deep", "whitelist"];
    const checkboxes = ["debugMode"];

    textareas.forEach((id) => {
      const el = $(id);
      if (el) {
        el.addEventListener("input", debounce(() => {
          if (hasDataChanged()) {
            markUnsaved();
          } else {
            clearUnsaved();
          }
        }, CONFIG.DEBOUNCE_DELAY_MS));
      }
    });

    checkboxes.forEach((id) => {
      const el = $(id);
      if (el) {
        el.addEventListener("change", () => {
          if (hasDataChanged()) {
            markUnsaved();
          } else {
            clearUnsaved();
          }
        });
      }
    });

    // Warn before leaving with unsaved changes
    window.addEventListener("beforeunload", (e) => {
      if (state.hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = "";
        return "";
      }
    });
  };

  // =========================
  // Rules & Settings
  // =========================

  /**
   * Normalize and validate rules object.
   * @param {any} rules
   * @returns {{ light: string[]; normal: string[]; deep: string[] }}
   */
  const normalizeRules = (rules) => {
    if (!rules || typeof rules !== "object") {
      return clone(DEFAULT_RULES);
    }

    const out = { light: [], normal: [], deep: [] };

    for (const key of RULE_KEYS) {
      const source = Array.isArray(rules[key]) ? rules[key] : DEFAULT_RULES[key];
      out[key] = (source || [])
        .filter((line) => typeof line === "string" && line.trim().length > 0)
        .slice(0, CONFIG.MAX_RULES_PER_CATEGORY);
    }

    return out;
  };

  /**
   * Validate whitelist entries.
   * @param {any} whitelist
   * @returns {string[]}
   */
  const normalizeWhitelist = (whitelist) => {
    if (!Array.isArray(whitelist)) return [];

    return whitelist
      .filter((entry) => typeof entry === "string" && entry.trim().length > 0)
      .map((entry) => entry.trim())
      .slice(0, CONFIG.MAX_WHITELIST_ENTRIES);
  };

  /**
   * Render rules to textareas.
   * @param {{ light?: string[]; normal?: string[]; deep?: string[] }} rules
   */
  const renderRules = (rules) => {
    RULE_KEYS.forEach((key) => {
      const el = $(key);
      if (el) {
        el.value = (rules[key] || []).join("\n");
      }
    });
  };

  /**
   * Render settings to form elements.
   * @param {{ debugMode?: boolean; whitelist?: string[] }} settings
   */
  const renderSettings = (settings) => {
    const debugEl = $("debugMode");
    if (debugEl) {
      debugEl.checked = Boolean(settings.debugMode);
    }

    const whitelistEl = $("whitelist");
    if (whitelistEl) {
      const normalizedWhitelist = normalizeWhitelist(settings.whitelist);
      whitelistEl.value = normalizedWhitelist.join("\n");
    }
  };

  /**
   * Read lines from a textarea.
   * @param {string} id
   * @returns {string[]}
   */
  const readLines = (id) => {
    const el = $(id);
    if (!el || !el.value) return [];

    return el.value
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
  };

  /**
   * Collect all current form data.
   * @returns {{ rules: object; debugMode: boolean; whitelist: string[] }}
   */
  const collectAllData = () => {
    const rules = {};
    RULE_KEYS.forEach((key) => {
      rules[key] = readLines(key);
    });

    const debugEl = $("debugMode");
    const debugMode = debugEl ? debugEl.checked : false;

    const whitelist = readLines("whitelist");

    return { rules, debugMode, whitelist };
  };

  /**
   * Load rules and settings from storage.
   */
  const loadData = async () => {
    try {
      if (!hasSyncStorage()) {
        console.warn("[Gmail Cleaner] Sync storage not available, using defaults.");
        renderRules(clone(DEFAULT_RULES));
        renderSettings({ debugMode: false, whitelist: [] });
        state.initialData = collectAllData();
        return;
      }

      const data = await new Promise((resolve) => {
        chrome.storage.sync.get(
          [STORAGE_KEYS.RULES, STORAGE_KEYS.DEBUG_MODE, STORAGE_KEYS.WHITELIST],
          resolve
        );
      });

      const normalizedRules = normalizeRules(data[STORAGE_KEYS.RULES]);
      renderRules(normalizedRules);

      renderSettings({
        debugMode: Boolean(data[STORAGE_KEYS.DEBUG_MODE]),
        whitelist: data[STORAGE_KEYS.WHITELIST] || []
      });

      // Store initial data for change detection
      state.initialData = collectAllData();
      clearUnsaved();

    } catch (err) {
      console.error("[Gmail Cleaner] Failed to load settings:", err);
      showToast("Failed to load settings", "error");
      renderRules(clone(DEFAULT_RULES));
      renderSettings({ debugMode: false, whitelist: [] });
      state.initialData = collectAllData();
    }
  };

  /**
   * Validate rules before saving.
   * @param {{ rules: object; whitelist: string[] }} data
   * @returns {{ valid: boolean; errors: string[] }}
   */
  const validateData = (data) => {
    const errors = [];

    // Check for empty required rules
    if (data.rules.normal.length === 0) {
      errors.push("Normal rules cannot be empty");
    }

    // Check for obviously invalid queries
    const invalidPatterns = [
      /^-/, // Starting with minus (would match everything)
      /^\s*$/ // Empty or whitespace only
    ];

    RULE_KEYS.forEach((key) => {
      data.rules[key].forEach((rule, index) => {
        if (invalidPatterns.some((p) => p.test(rule))) {
          errors.push(`Invalid rule in ${key} at line ${index + 1}: "${rule}"`);
        }
      });
    });

    // Validate whitelist entries
    data.whitelist.forEach((entry, index) => {
      if (!/^[\w.@*+-]+$/.test(entry) && !entry.includes("@")) {
        errors.push(`Invalid whitelist entry at line ${index + 1}: "${entry}"`);
      }
    });

    return {
      valid: errors.length === 0,
      errors
    };
  };

  /**
   * Main save function.
   * @param {Event} [evt]
   */
  const saveData = async (evt) => {
    evt?.preventDefault?.();

    if (state.saving) return;
    state.saving = true;

    const btn = $("save");
    setButtonLoading(btn, true, "Saving...");

    try {
      const data = collectAllData();

      // Validate
      const validation = validateData(data);
      if (!validation.valid) {
        showToast(validation.errors[0], "warning");
        console.warn("[Gmail Cleaner] Validation errors:", validation.errors);
        // Continue saving anyway, just warn
      }

      if (!hasSyncStorage()) {
        throw new Error("Chrome sync storage is not available");
      }

      await new Promise((resolve, reject) => {
        chrome.storage.sync.set(
          {
            [STORAGE_KEYS.RULES]: data.rules,
            [STORAGE_KEYS.DEBUG_MODE]: data.debugMode,
            [STORAGE_KEYS.WHITELIST]: data.whitelist
          },
          () => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve();
            }
          }
        );
      });

      // Update initial data for change detection
      state.initialData = data;
      clearUnsaved();

      showToast("Settings saved successfully!", "success");
      showButtonSuccess(btn);

    } catch (err) {
      console.error("[Gmail Cleaner] Failed to save:", err);
      showToast(`Failed to save: ${err.message}`, "error");
    } finally {
      setButtonLoading(btn, false);
      state.saving = false;
    }
  };

  // =========================
  // Restore Defaults
  // =========================

  /**
   * Show confirmation dialog.
   * @returns {Promise<boolean>}
   */
  const showConfirmDialog = () => {
    return new Promise((resolve) => {
      const dialog = $("confirmDialog");

      if (!dialog || typeof dialog.showModal !== "function") {
        // Fallback to native confirm
        resolve(confirm(
          "Are you sure you want to reset all rules and settings to default?\n\n" +
          "This action cannot be undone unless you have a backup."
        ));
        return;
      }

      const cancelBtn = $("dialogCancelBtn");
      const confirmBtn = $("dialogConfirmBtn");

      const cleanup = () => {
        cancelBtn?.removeEventListener("click", handleCancel);
        confirmBtn?.removeEventListener("click", handleConfirm);
        dialog.removeEventListener("close", handleClose);
      };

      const handleCancel = () => {
        dialog.close();
        cleanup();
        resolve(false);
      };

      const handleConfirm = () => {
        dialog.close();
        cleanup();
        resolve(true);
      };

      const handleClose = () => {
        cleanup();
        resolve(false);
      };

      cancelBtn?.addEventListener("click", handleCancel);
      confirmBtn?.addEventListener("click", handleConfirm);
      dialog.addEventListener("close", handleClose);

      dialog.showModal();
    });
  };

  /**
   * Restore all settings to defaults.
   */
  const restoreDefaults = async () => {
    const confirmed = await showConfirmDialog();
    if (!confirmed) return;

    // Reset UI
    renderRules(clone(DEFAULT_RULES));

    const whitelistEl = $("whitelist");
    if (whitelistEl) whitelistEl.value = "";

    const debugEl = $("debugMode");
    if (debugEl) debugEl.checked = false;

    // Save the reset state
    await saveData();

    showToast("Settings restored to defaults", "success");
  };

  // =========================
  // Import / Export
  // =========================

  /**
   * Export current configuration to JSON file.
   */
  const exportConfig = async () => {
    const btn = $("exportBtn");
    setButtonLoading(btn, true);

    try {
      if (!hasSyncStorage()) {
        throw new Error("Storage not available");
      }

      const data = await new Promise((resolve) => {
        chrome.storage.sync.get(
          [STORAGE_KEYS.RULES, STORAGE_KEYS.DEBUG_MODE, STORAGE_KEYS.WHITELIST],
          resolve
        );
      });

      const exportObj = {
        rules: data[STORAGE_KEYS.RULES] || clone(DEFAULT_RULES),
        debugMode: Boolean(data[STORAGE_KEYS.DEBUG_MODE]),
        whitelist: data[STORAGE_KEYS.WHITELIST] || [],
        exportedAt: new Date().toISOString(),
        version: OPTIONS_VERSION,
        extensionName: "Gmail One-Click Cleaner"
      };

      const blob = new Blob(
        [JSON.stringify(exportObj, null, 2)],
        { type: "application/json" }
      );
      const url = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = `gmail-cleaner-config-${getDateStamp()}.json`;
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();

      // Cleanup
      setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }, 100);

      showToast("Configuration exported successfully", "success");

    } catch (err) {
      console.error("[Gmail Cleaner] Export failed:", err);
      showToast(`Export failed: ${err.message}`, "error");
    } finally {
      setButtonLoading(btn, false);
    }
  };

  /**
   * Trigger file input for import.
   */
  const triggerImport = () => {
    const fileInput = $("importFile");
    if (fileInput) {
      fileInput.value = ""; // Reset so same file can be selected again
      fileInput.click();
    }
  };

  /**
   * Validate imported configuration.
   * @param {any} json
   * @returns {{ valid: boolean; errors: string[] }}
   */
  const validateImport = (json) => {
    const errors = [];

    if (!json || typeof json !== "object") {
      errors.push("Invalid JSON format");
      return { valid: false, errors };
    }

    if (!json.rules || typeof json.rules !== "object") {
      errors.push("Missing or invalid 'rules' property");
    } else {
      // Check for at least one rule category
      const hasRules = RULE_KEYS.some(
        (key) => Array.isArray(json.rules[key]) && json.rules[key].length > 0
      );
      if (!hasRules) {
        errors.push("Configuration has no valid rules");
      }
    }

    if (json.whitelist && !Array.isArray(json.whitelist)) {
      errors.push("'whitelist' must be an array");
    }

    return {
      valid: errors.length === 0,
      errors
    };
  };

  /**
   * Handle import file selection.
   * @param {Event} evt
   */
  const handleImportFile = async (evt) => {
    const fileInput = /** @type {HTMLInputElement} */ (evt.target);
    const file = fileInput.files?.[0];

    if (!file) return;

    const btn = $("importBtn");
    setButtonLoading(btn, true);

    try {
      const text = await file.text();
      const json = JSON.parse(text);

      // Validate
      const validation = validateImport(json);
      if (!validation.valid) {
        throw new Error(validation.errors.join("; "));
      }

      // Count items for confirmation
      const ruleCount = RULE_KEYS.reduce(
        (sum, key) => sum + (json.rules[key]?.length || 0),
        0
      );
      const whitelistCount = json.whitelist?.length || 0;

      const confirmMsg =
        `Import configuration from "${escapeHtml(file.name)}"?\n\n` +
        `• ${ruleCount} total rules\n` +
        `• ${whitelistCount} whitelist entries\n` +
        `• Debug mode: ${json.debugMode ? "On" : "Off"}\n\n` +
        `This will replace your current settings.`;

      if (!confirm(confirmMsg)) {
        fileInput.value = "";
        return;
      }

      // Save to storage
      await new Promise((resolve, reject) => {
        chrome.storage.sync.set(
          {
            [STORAGE_KEYS.RULES]: normalizeRules(json.rules),
            [STORAGE_KEYS.DEBUG_MODE]: Boolean(json.debugMode),
            [STORAGE_KEYS.WHITELIST]: normalizeWhitelist(json.whitelist)
          },
          () => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve();
            }
          }
        );
      });

      // Refresh UI
      await loadData();
      clearUnsaved();

      showToast("Configuration imported successfully!", "success");

    } catch (err) {
      console.error("[Gmail Cleaner] Import error:", err);

      if (err instanceof SyntaxError) {
        showToast("Invalid JSON file format", "error");
      } else {
        showToast(`Import failed: ${err.message}`, "error");
      }
    } finally {
      fileInput.value = ""; // Reset
      setButtonLoading(btn, false);
    }
  };

  // =========================
  // Keyboard Shortcuts
  // =========================

  /**
   * Set up keyboard shortcuts.
   */
  const setupKeyboardShortcuts = () => {
    document.addEventListener("keydown", (e) => {
      // Ctrl/Cmd + S to save
      if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault();
        saveData();
      }

      // Escape to close dialog
      if (e.key === "Escape") {
        const dialog = $("confirmDialog");
        if (dialog && dialog.open) {
          dialog.close();
        }
      }
    });
  };

  // =========================
  // Initialization
  // =========================

  /**
   * Set up all event listeners.
   */
  const setupEventListeners = () => {
    // Save button
    const saveBtn = $("save");
    if (saveBtn) {
      saveBtn.addEventListener("click", saveData);
    }

    // Restore defaults button
    const restoreBtn = $("restoreDefaultsBtn");
    if (restoreBtn) {
      restoreBtn.addEventListener("click", restoreDefaults);
    }

    // Export button
    const exportBtn = $("exportBtn");
    if (exportBtn) {
      exportBtn.addEventListener("click", exportConfig);
    }

    // Import button
    const importBtn = $("importBtn");
    if (importBtn) {
      importBtn.addEventListener("click", triggerImport);
    }

    // File input for import
    const fileInput = $("importFile");
    if (fileInput) {
      fileInput.addEventListener("change", handleImportFile);
    }

    // Set up change tracking
    setupChangeListeners();

    // Set up keyboard shortcuts
    setupKeyboardShortcuts();
  };

  /**
   * Initialize the options page.
   */
  const init = async () => {
    console.log(`[Gmail Cleaner] Options page v${OPTIONS_VERSION} initializing...`);

    // Set up event listeners first
    setupEventListeners();

    // Load data
    await loadData();

    console.log("[Gmail Cleaner] Options page ready.");
  };

  // Run initialization when DOM is ready
  if (document.readyState === "loading") {
    window.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

})();