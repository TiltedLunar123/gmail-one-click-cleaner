(() => {
  "use strict";

  // =========================
  // Constants & Configuration
  // =========================

  const DIAGNOSTICS_VERSION = "3.2.0";

  const CONFIG = Object.freeze({
    MAX_URL_LENGTH: 120,
    MAX_LOG_ENTRIES: 100,
    TOAST_DURATION_MS: 3000,
    DEBOUNCE_DELAY_MS: 300,
    LOADING_CLASS: "loading",
    BUTTON_LOADING_CLASS: "loading"
  });

  const SELECTORS = Object.freeze({
    envBrowser: "envBrowser",
    envPlatform: "envPlatform",
    envExtension: "envExtension",
    envPerms: "envPerms",
    tabCount: "gmailTabCount",
    tabTableBody: "gmailTabTableBody",
    chosenTabText: "chosenTabText",
    scanTabsBtn: "scanTabsBtn",
    testInjectBtn: "testInjectBtn",
    log: "log",
    diagVersionBadge: "diagVersionBadge",
    lastRunSummary: "lastRunSummary",
    lastRunMeta: "lastRunMeta",
    lastRunBucketTag: "lastRunBucketTag",
    lastRunButtons: "lastRunButtons",
    runHistoryTableBody: "runHistoryTableBody",
    copyLogBtn: "copyLogBtn",
    clearLogBtn: "clearLogBtn",
    toastContainer: ".toast-container"
  });

  const TAG_CLASSES = Object.freeze({
    dry: "tag tag-info",
    archive: "tag tag-success",
    delete: "tag tag-danger",
    default: "tag tag-primary"
  });

  // =========================
  // Utility Functions
  // =========================

  /**
   * Safely get an element by ID with optional type assertion.
   * @param {string} id - Element ID
   * @returns {HTMLElement | null}
   */
  const getEl = (id) => document.getElementById(id);

  /**
   * Safely query for an element.
   * @param {string} selector - CSS selector
   * @returns {Element | null}
   */
  const qs = (selector) => {
    try {
      return document.querySelector(selector);
    } catch {
      return null;
    }
  };

  /**
   * Truncate a string to a maximum length with ellipsis.
   * @param {string} str - String to truncate
   * @param {number} [maxLength=120] - Maximum length
   * @returns {string}
   */
  const truncate = (str, maxLength = CONFIG.MAX_URL_LENGTH) => {
    if (typeof str !== "string") return "";
    return str.length > maxLength ? str.slice(0, maxLength - 3) + "..." : str;
  };

  /**
   * Safely escape HTML to prevent XSS.
   * @param {string} str - String to escape
   * @returns {string}
   */
  const escapeHtml = (str) => {
    if (typeof str !== "string") return "";
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  };

  /**
   * Format a number with locale-specific separators.
   * @param {number} num - Number to format
   * @returns {string}
   */
  const formatNumber = (num) => {
    if (typeof num !== "number" || !Number.isFinite(num)) return "0";
    return num.toLocaleString();
  };

  /**
   * Format a date for display.
   * @param {number | null} timestamp - Unix timestamp in milliseconds
   * @returns {string}
   */
  const formatDate = (timestamp) => {
    if (typeof timestamp !== "number" || !Number.isFinite(timestamp)) {
      return "(time not recorded)";
    }
    try {
      return new Date(timestamp).toLocaleString();
    } catch {
      return "(invalid date)";
    }
  };

  /**
   * Create a debounced version of a function.
   * @template {(...args: any[]) => any} T
   * @param {T} fn - Function to debounce
   * @param {number} delay - Delay in milliseconds
   * @returns {T}
   */
  const debounce = (fn, delay) => {
    let timeoutId = null;
    return /** @type {T} */ ((...args) => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => fn(...args), delay);
    });
  };

  /**
   * Check if Chrome runtime APIs are available.
   * @returns {boolean}
   */
  const hasChromeRuntime = () => {
    try {
      return typeof chrome !== "undefined" && !!chrome.runtime;
    } catch {
      return false;
    }
  };

  /**
   * Check if Chrome tabs API is available.
   * @returns {boolean}
   */
  const hasChromeTabs = () => {
    try {
      return typeof chrome !== "undefined" && !!chrome.tabs;
    } catch {
      return false;
    }
  };

  /**
   * Check if Chrome storage API is available.
   * @param {"sync" | "local"} type - Storage type
   * @returns {boolean}
   */
  const hasChromeStorage = (type = "sync") => {
    try {
      return (
        typeof chrome !== "undefined" &&
        chrome?.storage?.[type] &&
        typeof chrome.storage[type].get === "function"
      );
    } catch {
      return false;
    }
  };

  /**
   * Check if Chrome scripting API is available.
   * @returns {boolean}
   */
  const hasChromeScripting = () => {
    try {
      return typeof chrome !== "undefined" && !!chrome.scripting;
    } catch {
      return false;
    }
  };

  // =========================
  // DOM Element Cache
  // =========================

  /** @type {Object} */
  const elements = {
    envBrowser: getEl(SELECTORS.envBrowser),
    envPlatform: getEl(SELECTORS.envPlatform),
    envExtension: getEl(SELECTORS.envExtension),
    envPerms: getEl(SELECTORS.envPerms),
    tabCount: getEl(SELECTORS.tabCount),
    tabTableBody: getEl(SELECTORS.tabTableBody),
    chosenTabText: getEl(SELECTORS.chosenTabText),
    scanTabsBtn: getEl(SELECTORS.scanTabsBtn),
    testInjectBtn: getEl(SELECTORS.testInjectBtn),
    log: getEl(SELECTORS.log),
    diagVersionBadge: getEl(SELECTORS.diagVersionBadge),
    lastRunSummary: getEl(SELECTORS.lastRunSummary),
    lastRunMeta: getEl(SELECTORS.lastRunMeta),
    lastRunBucketTag: getEl(SELECTORS.lastRunBucketTag),
    lastRunButtons: getEl(SELECTORS.lastRunButtons),
    runHistoryTableBody: getEl(SELECTORS.runHistoryTableBody),
    copyLogBtn: getEl(SELECTORS.copyLogBtn),
    clearLogBtn: getEl(SELECTORS.clearLogBtn),
    toastContainer: qs(SELECTORS.toastContainer)
  };

  // =========================
  // Toast Notifications
  // =========================

  /**
   * Show a toast notification.
   * @param {string} message - Message to display
   * @param {string} [type="info"] - Toast type
   * @param {number} [duration] - Duration in milliseconds
   */
  const showToast = (message, type = "info", duration = CONFIG.TOAST_DURATION_MS) => {
    const container = elements.toastContainer;
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    toast.setAttribute("role", "alert");

    container.appendChild(toast);

    // Trigger animation
    requestAnimationFrame(() => {
      toast.classList.add("show");
    });

    // Remove after duration
    setTimeout(() => {
      toast.classList.remove("show");
      setTimeout(() => {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, duration);
  };

  // =========================
  // Logging System
  // =========================

  /** @type {string[]} */
  const logHistory = [];

  /**
   * Get current timestamp string.
   * @returns {string}
   */
  const getTimestamp = () => {
    const now = new Date();
    return now.toLocaleTimeString("en-US", {
      hour12: false,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
  };

  /**
   * Add a log entry with timestamp and level.
   * @param {string} text - Log message
   * @param {string} [level="info"] - Log level
   */
  const addLog = (text, level = "info") => {
    if (!elements.log) return;

    const timestamp = getTimestamp();
    const entry = `[${timestamp}] ${text}`;
    
    // Store in history
    logHistory.push(entry);
    if (logHistory.length > CONFIG.MAX_LOG_ENTRIES) {
      logHistory.shift();
    }

    // Create log entry element
    const entryEl = document.createElement("div");
    entryEl.className = `log-entry log-${level}`;
    
    const timestampSpan = document.createElement("span");
    timestampSpan.className = "log-timestamp";
    timestampSpan.textContent = `[${timestamp}]`;
    
    entryEl.appendChild(timestampSpan);
    entryEl.appendChild(document.createTextNode(` ${text}`));

    // Clear empty state if present
    const emptyState = elements.log.querySelector(".empty-state");
    if (emptyState) {
      emptyState.remove();
    }

    elements.log.appendChild(entryEl);

    // Auto-scroll to bottom
    elements.log.scrollTop = elements.log.scrollHeight;
  };

  /**
   * Set the entire log content (replaces existing).
   * @param {string} text - Log content
   * @param {string} [level="info"] - Log level
   */
  const setLog = (text, level = "info") => {
    if (!elements.log) return;
    
    // Clear existing content
    elements.log.innerHTML = "";
    logHistory.length = 0;
    
    if (text) {
      addLog(text, level);
    }
  };

  /**
   * Clear all log entries.
   */
  const clearLog = () => {
    if (!elements.log) return;
    elements.log.innerHTML = "";
    logHistory.length = 0;
    
    // Add empty state back
    const emptyState = document.createElement("div");
    emptyState.className = "empty-state";
    emptyState.textContent = "// Waiting for logs...";
    elements.log.appendChild(emptyState);
    
    showToast("Log cleared", "info");
  };

  /**
   * Copy log content to clipboard.
   */
  const copyLog = async () => {
    if (logHistory.length === 0) {
      showToast("No logs to copy", "warning");
      return;
    }

    const content = logHistory.join("\n");

    try {
      await navigator.clipboard.writeText(content);
      showToast("Log copied to clipboard", "success");
    } catch (err) {
      // Fallback for older browsers
      const textarea = document.createElement("textarea");
      textarea.value = content;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      
      try {
        document.execCommand("copy");
        showToast("Log copied to clipboard", "success");
      } catch {
        showToast("Failed to copy log", "error");
      }
      
      document.body.removeChild(textarea);
    }
  };

  // =========================
  // Button State Management
  // =========================

  /**
   * Set button loading state.
   * @param {HTMLButtonElement | null} btn - Button element
   * @param {boolean} loading - Loading state
   */
  const setButtonLoading = (btn, loading) => {
    if (!btn) return;
    
    btn.disabled = loading;
    
    if (loading) {
      btn.classList.add(CONFIG.BUTTON_LOADING_CLASS);
      btn.setAttribute("aria-busy", "true");
    } else {
      btn.classList.remove(CONFIG.BUTTON_LOADING_CLASS);
      btn.removeAttribute("aria-busy");
    }
  };

  /**
   * Remove loading skeleton class from element.
   * @param {HTMLElement | null} el - Element
   */
  const removeLoadingSkeleton = (el) => {
    if (!el) return;
    el.classList.remove(CONFIG.LOADING_CLASS);
  };

  // =========================
  // Environment Rendering
  // =========================

  const getBrowserInfo = () => {
    const ua = navigator.userAgent || "";
    if (ua.includes("Chrome")) {
      const match = ua.match(/Chrome\/([\d.]+)/);
      return match ? `Chrome ${match[1]}` : "Chrome";
    }
    if (ua.includes("Firefox")) {
      const match = ua.match(/Firefox\/([\d.]+)/);
      return match ? `Firefox ${match[1]}` : "Firefox";
    }
    if (ua.includes("Safari") && !ua.includes("Chrome")) {
      const match = ua.match(/Version\/([\d.]+)/);
      return match ? `Safari ${match[1]}` : "Safari";
    }
    if (ua.includes("Edge")) {
      const match = ua.match(/Edge\/([\d.]+)/);
      return match ? `Edge ${match[1]}` : "Edge";
    }
    return ua || "(unknown)";
  };

  const getPlatformInfo = () => {
    if (navigator.userAgentData?.platform) {
      return navigator.userAgentData.platform;
    }
    return navigator.platform || "(unknown)";
  };

  const getManifestInfo = () => {
    try {
      if (!hasChromeRuntime()) return null;
      const manifest = chrome.runtime.getManifest();
      return {
        name: manifest.name || "Gmail One-Click Cleaner",
        version: manifest.version_name || manifest.version || "?"
      };
    } catch {
      return null;
    }
  };

  const getPermissions = () => {
    try {
      if (!hasChromeRuntime()) return [];
      const manifest = chrome.runtime.getManifest();
      const permissions = manifest.permissions || [];
      const hostPermissions = manifest.host_permissions || [];
      return [...permissions, ...hostPermissions];
    } catch {
      return [];
    }
  };

  const renderEnv = () => {
    // Browser
    if (elements.envBrowser) {
      elements.envBrowser.textContent = getBrowserInfo();
      removeLoadingSkeleton(elements.envBrowser);
    }

    // Platform
    if (elements.envPlatform) {
      elements.envPlatform.textContent = getPlatformInfo();
      removeLoadingSkeleton(elements.envPlatform);
    }

    // Extension info
    const manifestInfo = getManifestInfo();
    if (elements.envExtension) {
      if (manifestInfo) {
        elements.envExtension.textContent = `${manifestInfo.name} – v${manifestInfo.version}`;
      } else {
        elements.envExtension.textContent = "Gmail One-Click Cleaner – (runtime unavailable)";
      }
      removeLoadingSkeleton(elements.envExtension);
    }

    // Version badge
    if (elements.diagVersionBadge) {
      if (manifestInfo) {
        elements.diagVersionBadge.textContent = `v${manifestInfo.version} snapshot`;
      } else {
        elements.diagVersionBadge.textContent = `v${DIAGNOSTICS_VERSION} snapshot`;
      }
    }

    // Permissions
    if (elements.envPerms) {
      const perms = getPermissions();
      elements.envPerms.textContent = perms.length > 0 
        ? perms.join(", ") 
        : "(none or unavailable)";
      removeLoadingSkeleton(elements.envPerms);
    }
  };

  // =========================
  // Last Run Stats
  // =========================

  const getRunCount = (stats) => {
    if (!stats) return 0;
    if (typeof stats.runCount === "number") return stats.runCount;
    return stats.mode === "dry" 
      ? (stats.totalWouldDelete || 0) 
      : (stats.totalDeleted || 0);
  };

  const getActionWord = (stats) => {
    if (!stats) return "affected";
    if (stats.mode === "dry") return "would affect";
    return stats.archiveInsteadOfDelete ? "archived" : "deleted";
  };

  const getModeLabel = (stats) => {
    if (!stats) return "Unknown";
    if (stats.mode === "dry") return "Dry Run";
    return stats.archiveInsteadOfDelete ? "Archive" : "Delete";
  };

  const getTagClass = (stats) => {
    if (!stats) return TAG_CLASSES.default;
    if (stats.mode === "dry") return TAG_CLASSES.dry;
    return stats.archiveInsteadOfDelete ? TAG_CLASSES.archive : TAG_CLASSES.delete;
  };

  const applyLastRunToDom = (stats) => {
    // Skip if no summary elements exist
    if (!elements.lastRunSummary && !elements.lastRunMeta && 
        !elements.lastRunBucketTag && !elements.lastRunButtons) {
      return;
    }

    // Handle empty state
    if (!stats) {
      if (elements.lastRunSummary) {
        elements.lastRunSummary.textContent = "No cleanup runs recorded yet in this browser.";
      }
      if (elements.lastRunMeta) {
        elements.lastRunMeta.textContent = "";
      }
      if (elements.lastRunBucketTag) {
        elements.lastRunBucketTag.textContent = "no runs";
        elements.lastRunBucketTag.className = "tag";
      }
      if (elements.lastRunButtons) {
        elements.lastRunButtons.innerHTML = "";
      }
      return;
    }

    const mode = stats.mode === "dry" ? "preview (dry run)" : "live cleanup";
    const runCount = getRunCount(stats);
    const sizeBucket = stats.sizeBucket || "tiny";
    const totalQueries = typeof stats.totalQueries === "number" ? stats.totalQueries : "?";
    const actionWord = getActionWord(stats);
    const finishedText = formatDate(stats.finishedAt ?? null);
    
    // Calculate Freed MB text
    let freedMbText = "";
    if (typeof stats.totalFreedMb === "number" && stats.mode !== "dry") {
       if (stats.totalFreedMb < 0.1 && stats.totalFreedMb > 0) {
         freedMbText = "< 0.1 MB";
       } else {
         freedMbText = `${stats.totalFreedMb.toFixed(1)} MB`;
       }
    } else {
       freedMbText = sizeBucket; // fallback
    }

    // Update summary
    if (elements.lastRunSummary) {
      elements.lastRunSummary.textContent = 
        `Last run: ${mode}, ${formatNumber(runCount)} conversations ${actionWord}.`;
    }

    // Update meta
    if (elements.lastRunMeta) {
      elements.lastRunMeta.textContent = 
        `Queries: ${totalQueries} • Freed: ${freedMbText} • Finished: ${finishedText}`;
    }

    // Update bucket tag
    if (elements.lastRunBucketTag) {
      elements.lastRunBucketTag.textContent = sizeBucket;
      elements.lastRunBucketTag.className = sizeBucket !== "tiny" ? "tag tag-primary" : "tag";
    }

    // Update action buttons
    if (elements.lastRunButtons) {
      elements.lastRunButtons.innerHTML = "";
      const links = stats.links || {};

      if (links.trash) {
        const trashBtn = document.createElement("a");
        trashBtn.href = links.trash;
        trashBtn.target = "_blank";
        trashBtn.rel = "noopener noreferrer";
        trashBtn.textContent = "🗑️ Open Trash";
        trashBtn.className = "button-link";
        trashBtn.setAttribute("aria-label", "Open Gmail Trash (opens in new tab)");
        elements.lastRunButtons.appendChild(trashBtn);
      }

      if (links.allMail) {
        const allMailBtn = document.createElement("a");
        allMailBtn.href = links.allMail;
        allMailBtn.target = "_blank";
        allMailBtn.rel = "noopener noreferrer";
        allMailBtn.textContent = "📬 Open All Mail";
        allMailBtn.className = "button-link btn-ghost";
        allMailBtn.setAttribute("aria-label", "Open Gmail All Mail (opens in new tab)");
        elements.lastRunButtons.appendChild(allMailBtn);
      }
    }
  };

  const renderLastRunFromStorage = async () => {
    if (!hasChromeStorage("sync")) return;
    try {
      const result = await new Promise((resolve) => {
        chrome.storage.sync.get(["lastRunStats"], resolve);
      });
      applyLastRunToDom(result?.lastRunStats ?? null);
    } catch (err) {
      console.warn("[Diagnostics] Failed to load last run stats:", err);
    }
  };

  // =========================
  // Run History
  // =========================

  const createHistoryRow = (run) => {
    const row = document.createElement("tr");
    const count = getRunCount(run);

    // Date cell
    const dateCell = document.createElement("td");
    dateCell.className = "mono small";
    dateCell.textContent = formatDate(run.finishedAt ?? null);
    
    // Mode cell
    const modeCell = document.createElement("td");
    const modeTag = document.createElement("span");
    modeTag.className = getTagClass(run);
    modeTag.textContent = getModeLabel(run);
    modeCell.appendChild(modeTag);
    
    // Count cell
    const countCell = document.createElement("td");
    countCell.className = "mono";
    countCell.textContent = formatNumber(count);
    
    // Queries cell
    const queriesCell = document.createElement("td");
    queriesCell.className = "mono";
    queriesCell.textContent = `${run.totalQueries ?? "?"} queries`;
    
    // Freed MB cell (replaces size bucket)
    const sizeCell = document.createElement("td");
    sizeCell.className = "small muted";
    
    let mbText = "-";
    if (typeof run.totalFreedMb === "number") {
      if (run.totalFreedMb < 0.1 && run.totalFreedMb > 0) {
        mbText = "<0.1 MB";
      } else {
        mbText = `${run.totalFreedMb.toFixed(1)} MB`;
      }
    } else if (run.sizeBucket) {
      mbText = run.sizeBucket; // fallback for old records
    }
    sizeCell.textContent = mbText;

    row.appendChild(dateCell);
    row.appendChild(modeCell);
    row.appendChild(countCell);
    row.appendChild(queriesCell);
    row.appendChild(sizeCell);

    return row;
  };

  const createEmptyHistoryRow = (message) => {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 5;
    cell.className = "table-empty";
    cell.innerHTML = `
      <div class="table-empty-icon" aria-hidden="true">📋</div>
      <div>${escapeHtml(message)}</div>
    `;
    row.appendChild(cell);
    return row;
  };

  const renderRunHistory = async () => {
    if (!elements.runHistoryTableBody) return;
    if (!hasChromeStorage("local")) {
      elements.runHistoryTableBody.innerHTML = "";
      elements.runHistoryTableBody.appendChild(
        createEmptyHistoryRow("Storage unavailable")
      );
      return;
    }

    try {
      const result = await new Promise((resolve) => {
        chrome.storage.local.get(["runHistory"], resolve);
      });
      
      const history = Array.isArray(result?.runHistory) ? result.runHistory : [];
      elements.runHistoryTableBody.innerHTML = "";

      if (history.length === 0) {
        elements.runHistoryTableBody.appendChild(
          createEmptyHistoryRow("No history recorded yet. Run a cleanup to see history here.")
        );
        return;
      }

      const sorted = [...history].sort((a, b) => {
        const aTime = a.finishedAt ?? 0;
        const bTime = b.finishedAt ?? 0;
        return bTime - aTime;
      });

      const fragment = document.createDocumentFragment();
      for (const run of sorted) {
        fragment.appendChild(createHistoryRow(run));
      }
      elements.runHistoryTableBody.appendChild(fragment);

    } catch (err) {
      console.error("[Diagnostics] Failed to render history:", err);
      elements.runHistoryTableBody.innerHTML = "";
      elements.runHistoryTableBody.appendChild(
        createEmptyHistoryRow("Failed to load history")
      );
    }
  };

  // =========================
  // Gmail Tab Detection
  // =========================

  const findGmailTab = async () => {
    if (!hasChromeTabs()) {
      addLog("chrome.tabs is not available in this context.", "error");
      return null;
    }
    try {
      const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true
      });
      if (
        activeTab?.id &&
        typeof activeTab.url === "string" &&
        activeTab.url.startsWith("https://mail.google.com/")
      ) {
        return activeTab;
      }
      const tabs = await chrome.tabs.query({
        url: "https://mail.google.com/*",
        currentWindow: true
      });
      if (!tabs?.length) {
        const allTabs = await chrome.tabs.query({
          url: "https://mail.google.com/*"
        });
        if (!allTabs?.length) return null;
        const activeInAll = allTabs.find((t) => t.active);
        return activeInAll || allTabs[0];
      }
      const active = tabs.find((t) => t.active);
      return active || tabs[0];
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      addLog(`Error finding Gmail tab: ${message}`, "error");
      return null;
    }
  };

  const createTabRow = (tab) => {
    const row = document.createElement("tr");

    const idCell = document.createElement("td");
    idCell.textContent = String(tab.id ?? "?");
    idCell.className = "mono";

    const winCell = document.createElement("td");
    winCell.textContent = String(tab.windowId ?? "?");
    winCell.className = "mono";

    const actCell = document.createElement("td");
    if (tab.active) {
      const activeBadge = document.createElement("span");
      activeBadge.className = "tag tag-success";
      activeBadge.textContent = "yes";
      actCell.appendChild(activeBadge);
    } else {
      actCell.textContent = "no";
      actCell.className = "muted";
    }

    const urlCell = document.createElement("td");
    urlCell.textContent = truncate(tab.url || "(unknown)");
    urlCell.className = "mono";
    urlCell.title = tab.url || "";

    row.appendChild(idCell);
    row.appendChild(winCell);
    row.appendChild(actCell);
    row.appendChild(urlCell);

    return row;
  };

  const createEmptyTabRow = (message) => {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 4;
    cell.className = "table-empty";
    cell.innerHTML = `
      <div class="table-empty-icon" aria-hidden="true">📧</div>
      <div>${escapeHtml(message)}</div>
    `;
    row.appendChild(cell);
    return row;
  };

  const scanTabs = async () => {
    if (!hasChromeTabs()) {
      setLog("chrome.tabs is not available in this context.", "error");
      showToast("Tab API unavailable", "error");
      return;
    }

    setButtonLoading(elements.scanTabsBtn, true);
    setButtonLoading(elements.testInjectBtn, true);
    addLog("Scanning for Gmail tabs...", "info");

    try {
      const tabs = await chrome.tabs.query({
        url: "https://mail.google.com/*"
      });

      if (elements.tabCount) {
        elements.tabCount.textContent = String(tabs.length);
      }

      if (elements.tabTableBody) {
        elements.tabTableBody.innerHTML = "";
        if (tabs.length === 0) {
          elements.tabTableBody.appendChild(
            createEmptyTabRow("No Gmail tabs found. Open Gmail and try again.")
          );
        } else {
          const fragment = document.createDocumentFragment();
          for (const tab of tabs) {
            fragment.appendChild(createTabRow(tab));
          }
          elements.tabTableBody.appendChild(fragment);
        }
      }

      if (tabs.length === 0) {
        if (elements.chosenTabText) {
          elements.chosenTabText.textContent = "None – no Gmail tabs detected.";
          elements.chosenTabText.className = "env-value mono text-warning";
        }
        addLog("No Gmail tabs found.", "warning");
        showToast("No Gmail tabs found", "warning");
        return;
      }

      const chosen = await findGmailTab();
      
      if (!chosen) {
        if (elements.chosenTabText) {
          elements.chosenTabText.textContent = "None – detection failed even though Gmail tabs exist.";
          elements.chosenTabText.className = "env-value mono text-danger";
        }
        addLog("Gmail tabs exist, but detection returned null.", "error");
        showToast("Tab detection failed", "error");
      } else {
        if (elements.chosenTabText) {
          elements.chosenTabText.textContent = 
            `Tab ${chosen.id} in window ${chosen.windowId} – ${truncate(chosen.url || "", 100)}`;
          elements.chosenTabText.className = "env-value mono text-success";
        }
        addLog(
          `Detection OK. The popup should use tab ${chosen.id} in window ${chosen.windowId}.`,
          "success"
        );
        showToast(`Found ${tabs.length} Gmail tab(s)`, "success");
        setButtonLoading(elements.testInjectBtn, false);
      }

    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      addLog(`Failed to query tabs: ${message}`, "error");
      showToast("Tab scan failed", "error");
    } finally {
      setButtonLoading(elements.scanTabsBtn, false);
    }
  };

  const testInject = async () => {
    if (!hasChromeScripting() || !hasChromeTabs()) {
      setLog("chrome.scripting is not available in this context.", "error");
      showToast("Scripting API unavailable", "error");
      return;
    }

    setButtonLoading(elements.testInjectBtn, true);
    addLog("Attempting to inject diagnostic script...", "info");

    try {
      const tab = await findGmailTab();
      
      if (!tab?.id) {
        addLog("No Gmail tab available for injection.", "warning");
        showToast("No Gmail tab available", "warning");
        return;
      }

      const [result] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const now = new Date().toISOString();
          console.log("[GmailCleaner][Diagnostics] Inject ping at", now, "URL:", location.href);
          return {
            title: document.title,
            href: location.href,
            time: now,
            attached: !!window.__GCC_ATTACHED__
          };
        }
      });

      const payload = result?.result ?? null;
      if (payload) {
        addLog(`Inject succeeded into tab ${tab.id}:`, "success");
        addLog(JSON.stringify(payload, null, 2), "info");
        if (payload.attached) {
          showToast("Content script already attached", "success");
        } else {
          showToast("Inject successful", "success");
        }
      } else {
        addLog(`Inject completed but returned no data for tab ${tab.id}`, "warning");
        showToast("Inject completed (no data)", "warning");
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      addLog(`Inject failed: ${message}`, "error");
      showToast("Inject failed", "error");
    } finally {
      setButtonLoading(elements.testInjectBtn, false);
    }
  };

  // =========================
  // Event Listeners
  // =========================

  const setupEventListeners = () => {
    elements.scanTabsBtn?.addEventListener("click", () => {
      scanTabs().catch(console.error);
    });

    elements.testInjectBtn?.addEventListener("click", () => {
      testInject().catch(console.error);
    });

    elements.copyLogBtn?.addEventListener("click", () => {
      copyLog().catch(console.error);
    });

    elements.clearLogBtn?.addEventListener("click", clearLog);

    if (hasChromeRuntime() && chrome.runtime?.onMessage) {
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg?.type !== "gmailCleanerProgress") return;
        if (msg.phase === "done" && msg.stats) {
          applyLastRunToDom(msg.stats);
          renderRunHistory().catch(console.error);
          addLog("Received completion stats from cleaner run", "success");
        }
      });
    }

    document.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        copyLog().catch(console.error);
      }
    });
  };

  // =========================
  // Initialization
  // =========================

  const init = async () => {
    renderEnv();
    setupEventListeners();
    await Promise.allSettled([
      renderLastRunFromStorage(),
      renderRunHistory()
    ]);
    addLog(`Diagnostics page initialized (v${DIAGNOSTICS_VERSION})`, "success");
  };

  init().catch(console.error);
})();