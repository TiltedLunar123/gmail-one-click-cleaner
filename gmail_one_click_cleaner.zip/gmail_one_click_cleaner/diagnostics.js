(() => {
  "use strict";

  const envBrowserEl = document.getElementById("envBrowser");
  const envPlatformEl = document.getElementById("envPlatform");
  const envExtensionEl = document.getElementById("envExtension");
  const envPermsEl = document.getElementById("envPerms");
  const tabCountEl = document.getElementById("gmailTabCount");
  const tbody = document.getElementById("gmailTabTableBody");
  const chosenTabText = document.getElementById("chosenTabText");
  const scanTabsBtn = document.getElementById("scanTabsBtn");
  const testInjectBtn = document.getElementById("testInjectBtn");
  const logEl = document.getElementById("log");
  const diagVersionBadgeEl = document.getElementById("diagVersionBadge");

  // Optional last-run summary elements
  const lastRunSummaryEl = document.getElementById("lastRunSummary");
  const lastRunMetaEl = document.getElementById("lastRunMeta");
  const lastRunBucketTagEl = document.getElementById("lastRunBucketTag");
  const lastRunButtonsEl = document.getElementById("lastRunButtons");

  // New History Element
  const runHistoryTableBody = document.getElementById("runHistoryTableBody");

  function setLog(text) {
    if (!logEl) return;
    logEl.textContent = text || "";
  }

  function safe(str) {
    if (typeof str !== "string") return "";
    return str.length > 120 ? str.slice(0, 117) + "..." : str;
  }

  function renderEnv() {
    if (envBrowserEl) {
      envBrowserEl.textContent = navigator.userAgent || "(unknown)";
    }
    if (envPlatformEl) {
      envPlatformEl.textContent = navigator.platform || "(unknown)";
    }

    try {
      if (typeof chrome !== "undefined" && chrome.runtime) {
        const manifest = chrome.runtime.getManifest();
        const name = manifest.name || "Gmail One-Click Cleaner";
        const version = manifest.version_name || manifest.version || "?";

        if (envExtensionEl) {
          envExtensionEl.textContent = `${name} – v${version}`;
        }

        if (diagVersionBadgeEl) {
          diagVersionBadgeEl.textContent = `v${version} snapshot`;
        }
      } else {
        if (envExtensionEl) {
          envExtensionEl.textContent =
            "Gmail One-Click Cleaner – (runtime manifest unavailable)";
        }
        if (diagVersionBadgeEl) {
          diagVersionBadgeEl.textContent = "runtime snapshot";
        }
      }
    } catch {
      if (envExtensionEl) {
        envExtensionEl.textContent =
          "Gmail One-Click Cleaner – (manifest unavailable)";
      }
      if (diagVersionBadgeEl) {
        diagVersionBadgeEl.textContent = "runtime snapshot";
      }
    }

    try {
      if (typeof chrome !== "undefined" && chrome.runtime) {
        const m = chrome.runtime.getManifest();
        const perms = (m.permissions || []).concat(m.host_permissions || []);
        if (envPermsEl) {
          envPermsEl.textContent = perms.join(", ") || "(none)";
        }
      } else if (envPermsEl) {
        envPermsEl.textContent = "(permissions unavailable)";
      }
    } catch {
      if (envPermsEl) {
        envPermsEl.textContent = "(unable to read)";
      }
    }
  }

  /**
   * Apply a last-run stats object to the DOM summary elements, if they exist.
   * @param {any} rawStats
   */
  function applyLastRunToDom(rawStats) {
    if (
      !lastRunSummaryEl &&
      !lastRunMetaEl &&
      !lastRunBucketTagEl &&
      !lastRunButtonsEl
    ) {
      return; // diagnostics.html doesn't define the summary UI, nothing to do
    }

    const stats = rawStats || null;

    if (!stats) {
      if (lastRunSummaryEl) {
        lastRunSummaryEl.textContent =
          "No cleanup runs recorded yet in this browser.";
      }
      if (lastRunMetaEl) {
        lastRunMetaEl.textContent = "";
      }
      if (lastRunBucketTagEl) {
        lastRunBucketTagEl.textContent = "no runs";
        lastRunBucketTagEl.className = "tag";
      }
      if (lastRunButtonsEl) {
        lastRunButtonsEl.innerHTML = "";
      }
      return;
    }

    const mode = stats.mode === "dry" ? "preview (dry run)" : "live cleanup";
    const runCount =
      typeof stats.runCount === "number"
        ? stats.runCount
        : stats.mode === "dry"
        ? stats.totalWouldDelete || 0
        : stats.totalDeleted || 0;

    const sizeBucket = stats.sizeBucket || "tiny";
    const totalQueries =
      typeof stats.totalQueries === "number" ? stats.totalQueries : "?";

    const actionWord =
      stats.mode === "dry"
        ? "would affect"
        : stats.archiveInsteadOfDelete
        ? "archived"
        : "deleted";

    const finishedAtMs =
      typeof stats.finishedAt === "number" ? stats.finishedAt : null;
    const finishedText = finishedAtMs
      ? new Date(finishedAtMs).toLocaleString()
      : "(time not recorded)";

    if (lastRunSummaryEl) {
      lastRunSummaryEl.textContent =
        `Last run: ${mode}, ` +
        `${runCount.toLocaleString()} conversations ${actionWord}.`;
    }

    if (lastRunMetaEl) {
      lastRunMetaEl.textContent =
        `Queries: ${totalQueries} • ` +
        `Size: ${sizeBucket} • ` +
        `Finished: ${finishedText}`;
    }

    if (lastRunBucketTagEl) {
      lastRunBucketTagEl.textContent = sizeBucket;
      lastRunBucketTagEl.className =
        "tag" + (sizeBucket !== "tiny" ? " tag-primary" : "");
    }

    if (lastRunButtonsEl) {
      lastRunButtonsEl.innerHTML = "";
      const links = stats.links || {};

      if (links.trash) {
        const trashBtn = document.createElement("a");
        trashBtn.href = links.trash;
        trashBtn.target = "_blank";
        trashBtn.rel = "noopener noreferrer";
        trashBtn.textContent = "Open Trash";
        trashBtn.className = "button-link";
        lastRunButtonsEl.appendChild(trashBtn);
      }

      if (links.allMail) {
        const allMailBtn = document.createElement("a");
        allMailBtn.href = links.allMail;
        allMailBtn.target = "_blank";
        allMailBtn.rel = "noopener noreferrer";
        allMailBtn.textContent = "Open All Mail";
        allMailBtn.className = "button-link btn-ghost";
        lastRunButtonsEl.appendChild(allMailBtn);
      }
    }
  }

  /**
   * Load last-run stats from storage, if present, and render them.
   */
  async function renderLastRunFromStorage() {
    if (
      typeof chrome === "undefined" ||
      !chrome.storage ||
      !chrome.storage.sync ||
      typeof chrome.storage.sync.get !== "function"
    ) {
      return;
    }

    try {
      const res = await chrome.storage.sync.get(["lastRunStats"]);
      applyLastRunToDom(res && res.lastRunStats ? res.lastRunStats : null);
    } catch {
      // best-effort only; silently ignore
    }
  }

  /**
   * Render the history table from local storage.
   */
  async function renderRunHistory() {
    if (!runHistoryTableBody) return;
    if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) return;

    try {
      const res = await chrome.storage.local.get(["runHistory"]);
      const history = res.runHistory || [];
      
      // clear existing
      runHistoryTableBody.innerHTML = "";

      if (history.length === 0) {
        const row = document.createElement("tr");
        row.innerHTML = `<td colspan="5" class="muted">No history recorded yet.</td>`;
        runHistoryTableBody.appendChild(row);
        return;
      }

      // Show newest first
      const sorted = history.slice().reverse();

      sorted.forEach(run => {
        const row = document.createElement("tr");
        
        const dateStr = run.finishedAt 
          ? new Date(run.finishedAt).toLocaleString() 
          : "Unknown";

        const count = typeof run.runCount === 'number' ? run.runCount : 0;
        
        let typeLabel = "Delete";
        if(run.mode === "dry") typeLabel = "Dry Run";
        else if(run.archiveInsteadOfDelete) typeLabel = "Archive";

        let typeClass = "tag";
        if(run.mode === "dry") typeClass += " tag-info"; // e.g. blue
        else if(run.archiveInsteadOfDelete) typeClass += " tag-success"; // e.g. green
        else typeClass += " tag-danger"; // e.g. red

        row.innerHTML = `
          <td class="mono small">${dateStr}</td>
          <td><span class="${typeClass}">${typeLabel}</span></td>
          <td class="mono">${count.toLocaleString()}</td>
          <td class="mono">${run.totalQueries || "?"} queries</td>
          <td class="small muted">${run.sizeBucket || "-"}</td>
        `;
        runHistoryTableBody.appendChild(row);
      });

    } catch (e) {
      console.error("Failed to render history", e);
    }
  }

  async function findGmailTab() {
    if (typeof chrome === "undefined" || !chrome.tabs) {
      setLog("chrome.tabs is not available in this context.");
      return null;
    }

    try {
      const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true
      });

      if (
        activeTab &&
        typeof activeTab.id === "number" &&
        typeof activeTab.url === "string" &&
        activeTab.url.startsWith("https://mail.google.com/")
      ) {
        return activeTab;
      }

      const tabs = await chrome.tabs.query({
        url: "https://mail.google.com/*",
        currentWindow: true
      });

      if (!tabs || !tabs.length) return null;

      const active = tabs.find(
        (t) =>
          t.active &&
          typeof t.url === "string" &&
          t.url.startsWith("https://mail.google.com/")
      );

      return active || tabs[0];
    } catch (err) {
      setLog(
        "Error while finding Gmail tab: " +
          (err && err.message ? err.message : String(err))
      );
      return null;
    }
  }

  async function scanTabs() {
    if (!scanTabsBtn || !testInjectBtn) return;
    if (typeof chrome === "undefined" || !chrome.tabs) {
      setLog("chrome.tabs is not available in this context.");
      return;
    }

    scanTabsBtn.disabled = true;
    testInjectBtn.disabled = true;
    setLog("Scanning for Gmail tabs...");

    try {
      const tabs = await chrome.tabs.query({
        url: "https://mail.google.com/*"
      });

      if (tabCountEl) {
        tabCountEl.textContent = String(tabs.length);
      }

      if (tbody) {
        while (tbody.firstChild) {
          tbody.removeChild(tbody.firstChild);
        }
      }

      if (!tabs.length) {
        if (tbody) {
          const row = document.createElement("tr");
          const cell = document.createElement("td");
          cell.colSpan = 4;
          cell.textContent = "No Gmail tabs found. Open Gmail and try again.";
          cell.className = "muted";
          row.appendChild(cell);
          tbody.appendChild(row);
        }

        if (chosenTabText) {
          chosenTabText.textContent = "None – no Gmail tabs detected.";
        }

        setLog("No Gmail tabs found.");
        return;
      }

      if (tbody) {
        tabs.forEach((tab) => {
          const row = document.createElement("tr");

          const idCell = document.createElement("td");
          idCell.textContent = String(tab.id);
          idCell.className = "mono";

          const winCell = document.createElement("td");
          winCell.textContent = String(tab.windowId);
          winCell.className = "mono";

          const actCell = document.createElement("td");
          actCell.textContent = tab.active ? "yes" : "no";
          actCell.className = tab.active ? "tag tag-primary" : "muted";

          const urlCell = document.createElement("td");
          urlCell.textContent = safe(tab.url || "");
          urlCell.className = "mono";

          row.appendChild(idCell);
          row.appendChild(winCell);
          row.appendChild(actCell);
          row.appendChild(urlCell);

          tbody.appendChild(row);
        });
      }

      const chosen = await findGmailTab();
      if (!chosen) {
        if (chosenTabText) {
          chosenTabText.textContent =
            "None – detection failed even though Gmail tabs exist.";
          chosenTabText.className = "env-value mono tag-danger";
        }
        setLog(
          "Gmail tabs exist, but detection returned null. This is useful to report."
        );
      } else {
        if (chosenTabText) {
          chosenTabText.textContent =
            `Tab ${chosen.id} in window ${chosen.windowId} – ` +
            (chosen.url || "").slice(0, 140);
          chosenTabText.className = "env-value mono";
        }
        setLog(
          "Detection OK. The popup should use tab " +
            chosen.id +
            " in window " +
            chosen.windowId +
            "."
        );
        testInjectBtn.disabled = false;
      }
    } catch (err) {
      setLog(
        "Failed to query tabs: " +
          (err && err.message ? err.message : String(err))
      );
    } finally {
      scanTabsBtn.disabled = false;
    }
  }

  async function testInject() {
    if (!testInjectBtn) return;
    if (
      typeof chrome === "undefined" ||
      !chrome.scripting ||
      !chrome.tabs
    ) {
      setLog("chrome.scripting is not available in this context.");
      return;
    }

    testInjectBtn.disabled = true;
    setLog(
      "Attempting to inject a tiny diagnostic script into the chosen Gmail tab..."
    );

    try {
      const tab = await findGmailTab();
      if (!tab || typeof tab.id !== "number") {
        setLog("No Gmail tab available for injection. Try Scan Tabs again.");
        return;
      }

      const [result] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const now = new Date().toISOString();
          console.log(
            "[GmailCleaner][Diagnostics] Inject ping at",
            now,
            "URL:",
            location.href
          );
          return {
            title: document.title,
            href: location.href,
            time: now
          };
        }
      });

      const payload = result && result.result ? result.result : null;
      setLog(
        "Inject succeeded into tab " +
          tab.id +
          ":\n" +
          JSON.stringify(payload, null, 2)
      );
    } catch (err) {
      setLog(
        "Inject failed: " +
          (err && err.message ? err.message : String(err)) +
          "\nThis is useful information to include in a bug report."
      );
    } finally {
      testInjectBtn.disabled = false;
    }
  }

  // Wire buttons
  if (scanTabsBtn) {
    scanTabsBtn.addEventListener("click", () => {
      scanTabs().catch(() => {});
    });
  }

  if (testInjectBtn) {
    testInjectBtn.addEventListener("click", () => {
      testInject().catch(() => {});
    });
  }

  // Listen for live stats from the cleaner (when a run finishes).
  if (
    typeof chrome !== "undefined" &&
    chrome.runtime &&
    chrome.runtime.onMessage
  ) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg || msg.type !== "gmailCleanerProgress") return;
      if (msg.phase === "done" && msg.stats) {
        applyLastRunToDom(msg.stats);
        renderRunHistory().catch(()=>{}); // Refresh history table if a run just finished
      }
    });
  }

  renderEnv();
  renderLastRunFromStorage().catch(() => {});
  renderRunHistory().catch(() => {});
  // Don’t auto-scan so users can open Gmail first.
})();