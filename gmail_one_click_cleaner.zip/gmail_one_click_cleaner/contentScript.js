(() => {
  "use strict";

  const GCC_CONTENT_VERSION = "3.3.0"; // Version bump for True Bulk Delete

  // =========================
  // Timing & behavior constants
  // =========================

  const TIMING = Object.freeze({
    PASS_CAP: 150,
    WAIT_DEFAULT_TIMEOUT: 15000,
    WAIT_DEFAULT_INTERVAL: 200,
    WAIT_TOOLBAR_TIMEOUT: 8000,
    WAIT_SEARCH_TIMEOUT: 20000,
    POST_ACTION_DELAY_MS: 500,
    BETWEEN_PASS_SLEEP_MS: 650,
    LABEL_DIALOG_TIMEOUT: 5000,
    KEYBOARD_ACTION_DELAY: 250,
    DOM_SETTLE_DELAY: 300,
    CHECKBOX_SETTLE_DELAY: 150,
    LABEL_APPLY_DELAY: 400,
    REVIEW_POLL_INTERVAL: 200,
    BULK_CONFIRM_TIMEOUT: 3000,
    SELECT_ALL_SETTLE_DELAY: 400
  });

  // Run-level guardrails
  const GUARDRAILS = Object.freeze({
    RUN_SOFT_CAP: 10000,
    HUGE_RUN_CONFIRM_THRESHOLD: 20000,
    MAX_HISTORY_ENTRIES: 10
  });

  // =========================
  // Boot & basic utilities
  // =========================

  /**
   * Simple sleep helper for async flows.
   * @param {number} ms - Milliseconds to sleep
   * @returns {Promise<void>}
   */
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, Math.max(0, ms)));

  /**
   * Creates a cancellable sleep that rejects if cancelled.
   * @param {number} ms - Milliseconds to sleep
   * @param {() => boolean} isCancelled - Function to check cancellation
   * @returns {Promise<void>}
   */
  const cancellableSleep = async (ms, isCancelled) => {
    const start = Date.now();
    const interval = Math.min(100, ms);

    while (Date.now() - start < ms) {
      if (isCancelled()) {
        throw new CancellationError("Operation cancelled during sleep");
      }
      await sleep(interval);
    }
  };

  /**
   * Custom error class for cancellation.
   */
  class CancellationError extends Error {
    constructor(message = "Cancelled") {
      super(message);
      this.name = "CancellationError";
    }
  }

  /**
   * Custom error class for timeout.
   */
  class TimeoutError extends Error {
    constructor(message = "Operation timed out") {
      super(message);
      this.name = "TimeoutError";
    }
  }

  /**
   * Lightweight check for Chrome runtime messaging availability.
   * @returns {boolean}
   */
  const hasChromeRuntime = (() => {
    let cached = null;
    return () => {
      if (cached !== null) return cached;
      try {
        cached = (
          typeof chrome !== "undefined" &&
          chrome?.runtime &&
          typeof chrome.runtime.sendMessage === "function"
        );
      } catch {
        cached = false;
      }
      return cached;
    };
  })();

  /**
   * Check if Chrome storage is available.
   * @param {"sync" | "local"} type
   * @returns {boolean}
   */
  function hasChromeStorage(type = "sync") {
    try {
      return (
        typeof chrome !== "undefined" &&
        chrome?.storage?.[type] &&
        typeof chrome.storage[type].get === "function"
      );
    } catch {
      return false;
    }
  }

  /**
   * Convenience query selector with optional root.
   * @param {string} selector
   * @param {ParentNode} [root=document]
   * @returns {Element | null}
   */
  const qs = (selector, root = document) => {
    try {
      return root.querySelector(selector);
    } catch {
      return null;
    }
  };

  /**
   * Convenience querySelectorAll -> Array helper.
   * @param {string} selector
   * @param {ParentNode} [root=document]
   * @returns {Element[]}
   */
  const qsa = (selector, root = document) => {
    try {
      return Array.from(root.querySelectorAll(selector));
    } catch {
      return [];
    }
  };

  /**
   * Try multiple selectors and return the first match.
   * @param {string[]} selectors
   * @param {ParentNode} [root=document]
   * @returns {Element | null}
   */
  const qsFirst = (selectors, root = document) => {
    for (const selector of selectors) {
      const el = qs(selector, root);
      if (el) return el;
    }
    return null;
  };

  /**
   * Safely get text content from an element.
   * @param {Element | null} el
   * @returns {string}
   */
  const getTextContent = (el) => {
    if (!el) return "";
    return (el.textContent || el.innerText || "").trim();
  };

  /**
   * Safely get attribute from an element.
   * @param {Element | null} el
   * @param {string} attr
   * @returns {string}
   */
  const getAttr = (el, attr) => {
    if (!el) return "";
    return (el.getAttribute(attr) || "").trim();
  };

  /**
   * Get label text from element (checks multiple attributes).
   * @param {Element} el
   * @returns {string}
   */
  const getElementLabel = (el) => {
    return (
      getAttr(el, "aria-label") ||
      getAttr(el, "data-tooltip") ||
      getAttr(el, "title") ||
      getTextContent(el)
    );
  };

  /**
   * Small error logger wrapper (safe if console is unavailable).
   * @param {unknown} err
   * @param {string} [context]
   */
  const logError = (err, context = "") => {
    try {
      console.error("[GmailCleaner Error]", context, err);
    } catch {
      // Ignore logging failures.
    }
  };

  /**
   * Debounce function for rate-limiting.
   * @template {(...args: any[]) => any} T
   * @param {T} fn
   * @param {number} delay
   * @returns {T}
   */
  const debounce = (fn, delay) => {
    let timeoutId = null;
    return /** @type {T} */ ((...args) => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => fn(...args), delay);
    });
  };

  /**
   * Safely send progress/status messages to the background script.
   * Never throws if Chrome messaging isn't available.
   * @param {Record<string, unknown>} msg
   */
  const safeSend = debounce((msg) => {
    try {
      if (hasChromeRuntime()) {
        chrome.runtime.sendMessage({
          type: "gmailCleanerProgress",
          timestamp: Date.now(),
          version: GCC_CONTENT_VERSION,
          ...msg
        });
      }
    } catch (e) {
      // Swallow errors to avoid breaking the cleaner if messaging fails.
      logError(e, "safeSend");
    }
  }, 50);

  /**
   * Send message immediately without debounce (for critical messages).
   * @param {Record<string, unknown>} msg
   */
  const safeSendImmediate = (msg) => {
    try {
      if (hasChromeRuntime()) {
        chrome.runtime.sendMessage({
          type: "gmailCleanerProgress",
          timestamp: Date.now(),
          version: GCC_CONTENT_VERSION,
          ...msg
        });
      }
    } catch (e) {
      logError(e, "safeSendImmediate");
    }
  };

  // Guard against duplicate injection (can happen with SPA-style reloads).
  if (window.GCC_ATTACHED) {
    safeSendImmediate({
      phase: "boot",
      status: "Already attached",
      detail: "Duplicate inject ignored.",
      percent: 0
    });
    return;
  }
  window.GCC_ATTACHED = true;

  // Cleanup on unload
  const cleanup = () => {
    window.GCC_ATTACHED = false;
    CANCELLED = true;
  };

  window.addEventListener("beforeunload", cleanup, { once: true });
  window.addEventListener("unload", cleanup, { once: true });

  safeSendImmediate({
    phase: "boot",
    status: "Content script attached",
    detail: `Initializing (v${GCC_CONTENT_VERSION})...`,
    percent: 0
  });

  // =========================
  // Config / runtime flags
  // =========================

  /** @type {boolean} */
  let CANCELLED = false;

  /** @type {boolean} */
  let RUNNING = false;

  /** @type {null | "resume" | "skip" | "cancel"} */
  let REVIEW_SIGNAL = null;

  /** @type {number} */
  let liveRunProcessedSoFar = 0;

  /**
   * @typedef {"light" | "normal" | "deep"} Intensity
   */

  /**
   * @typedef {Object} CleanerConfig
   * @property {Intensity} intensity - Cleanup intensity level
   * @property {boolean} dryRun - If true, no deletions; just counts
   * @property {boolean} safeMode - If true, skips riskier categories
   * @property {boolean} tagBeforeDelete - If true, label messages before deleting/archiving
   * @property {string} tagLabelPrefix - Label prefix used when tagging
   * @property {boolean} guardSkipStarred - If true, add -is:starred
   * @property {boolean} guardSkipImportant - If true, add -is:important
   * @property {string | null} minAge - Minimum age filter (e.g., "3m", "6m")
   * @property {boolean} archiveInsteadOfDelete - If true, use Archive instead of Delete
   * @property {boolean} debugMode - If true, log debug info to console
   * @property {boolean} reviewMode - If true, pauses before action on every query
   * @property {string[]} whitelist - Array of email strings to always exclude
   */

  /**
   * Validate and sanitize config values.
   * @param {Partial<CleanerConfig>} config
   * @returns {CleanerConfig}
   */
  const sanitizeConfig = (config) => {
    const validIntensities = ["light", "normal", "deep"];
    const validAgePattern = /^\d+[dwmy]$/i;

    return {
      intensity: validIntensities.includes(config.intensity) 
        ? config.intensity 
        : "normal",
      dryRun: Boolean(config.dryRun),
      safeMode: Boolean(config.safeMode),
      tagBeforeDelete: config.tagBeforeDelete !== false,
      tagLabelPrefix: typeof config.tagLabelPrefix === "string" && config.tagLabelPrefix.trim()
        ? config.tagLabelPrefix.trim()
        : "GmailCleaner",
      guardSkipStarred: config.guardSkipStarred !== false,
      guardSkipImportant: config.guardSkipImportant !== false,
      minAge: typeof config.minAge === "string" && validAgePattern.test(config.minAge)
        ? config.minAge
        : null,
      archiveInsteadOfDelete: Boolean(config.archiveInsteadOfDelete),
      debugMode: Boolean(config.debugMode),
      reviewMode: Boolean(config.reviewMode),
      whitelist: Array.isArray(config.whitelist)
        ? config.whitelist.filter((s) => typeof s === "string" && s.trim())
        : []
    };
  };

  /** @type {CleanerConfig} */
  const CONFIG = sanitizeConfig(window.GMAIL_CLEANER_CONFIG || {});

  /**
   * Debug logger, controlled by CONFIG.debugMode
   * @param {string} message
   * @param {Record<string, unknown>} [data]
   */
  const debugLog = (message, data = {}) => {
    if (!CONFIG.debugMode) return;
    try {
      console.log(
        `[GmailCleaner ${new Date().toISOString()}]`,
        message,
        Object.keys(data).length > 0 ? data : ""
      );
    } catch {
      // Ignore logging failures.
    }
  };

  // =========================
  // Language tokens for i18n
  // =========================

  /** @type {Readonly<string[]>} */
  const DELETE_LABEL_TOKENS = Object.freeze([
    "Delete", "Trash", "Bin", "Move to trash",
    "Eliminar", "Papelera", "Supprimer", "Corbeille",
    "Löschen", "Papierkorb", "Excluir", "Lixeira",
    "Elimina", "Cestino", "Verwijderen", "Prullenbak",
    "Ta bort", "Slet", "Slett", "Usuń", "Kosz",
    "Sil", "Удалить", "حذف", "削除", "삭제", "删除"
  ]);

  /** @type {Readonly<string[]>} */
  const ARCHIVE_LABEL_TOKENS = Object.freeze([
    "Archive", "Archived", "Archiver", "Archivar",
    "Archivé", "Archivieren", "Arquivar", "Archivia", "Archivio"
  ]);

  /** @type {Readonly<string[]>} */
  const LABEL_BUTTON_TOKENS = Object.freeze([
    "Labels", "Label", "Label as", "Libellés",
    "Etiquetas", "Etiquette", "Etichette", "Märken"
  ]);

  /** @type {Readonly<string[]>} */
  const SELECT_ALL_TOKENS = Object.freeze([
    "Select all", "Seleccionar todo", "Tout sélectionner",
    "Alle auswählen", "Selecionar tudo", "Seleziona tutto",
    "Alles selecteren", "Välj alla", "Vælg alle",
    "Velg alle", "Zaznacz wszystko", "Tümünü seç",
    "Выбрать все", "تحديد الكل", "すべて選択", "모두 선택", "全选"
  ]);

  /** @type {Readonly<string[]>} */
  const CONFIRM_TOKENS = Object.freeze([
    "OK", "Confirm", "Yes", "Continue",
    "Aceptar", "Sí", "Confirmer", "Oui",
    "Bestätigen", "Ja", "Confirmar", "Sim",
    "Conferma", "Bevestigen", "Bekräfta",
    "Bekræft", "Bekreft", "Potwierdź", "Tak",
    "Onayla", "Evet", "Подтвердить", "Да",
    "موافق", "確認", "확인", "确认"
  ]);

  /**
   * Check if current page is Gmail.
   * @returns {boolean}
   */
  const isGmailTab = () => {
    try {
      return location.host === "mail.google.com";
    } catch {
      return false;
    }
  };

  /**
   * Get Gmail user index from URL.
   * @returns {string}
   */
  const getGmailUserIndex = () => {
    try {
      const match = location.pathname.match(/\/mail\/u\/(\d+)\//);
      return match?.[1] ?? "0";
    } catch {
      return "0";
    }
  };

  /**
   * Get Gmail base URL for current user.
   * @returns {string}
   */
  const getGmailBaseUrl = () => {
    const userIdx = getGmailUserIndex();
    return `${location.origin}/mail/u/${userIdx}/`;
  };

  // =========================
  // Messaging from popup/progress UI
  // =========================

  if (hasChromeRuntime() && chrome.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (!msg?.type) return;

      switch (msg.type) {
        case "gmailCleanerCancel":
          CANCELLED = true;
          REVIEW_SIGNAL = "cancel";
          debugLog("Received cancel message");
          sendResponse({ ok: true });
          break;

        case "gmailCleanerPing":
          sendResponse({ 
            ok: true, 
            phase: RUNNING ? "running" : "idle",
            version: GCC_CONTENT_VERSION
          });
          break;

        case "gmailCleanerStart":
          debugLog("Received start message");
          startMain();
          sendResponse({ ok: true });
          break;

        case "gmailCleanerResume":
          REVIEW_SIGNAL = "resume";
          sendResponse({ ok: true });
          break;

        case "gmailCleanerSkip":
          REVIEW_SIGNAL = "skip";
          sendResponse({ ok: true });
          break;

        default:
          // Unknown message type, ignore
          break;
      }
    });
  }

  // =========================
  // DOM selectors & helpers
  // =========================

  const SELECTORS = Object.freeze({
    main: "div[role='main']",
    grid: "table[role='grid']",
    listContainer: "div[gh='tl']",
    toolbar: ["div[gh='mtb']", "div[role='toolbar']"],
    masterCheckbox: [
      "div[aria-label='Select'] div[role='checkbox']",
      "div[aria-label^='Select'] div[role='checkbox']",
      "div[gh='tl'] div[role='checkbox']",
      "div[gh='mtb'] div[role='checkbox']",
      "div[role='checkbox']"
    ],
    labelInputs: [
      "div[role='dialog'] input[aria-label*='Label as']",
      "div[role='dialog'] input[aria-label*='Apply one or more labels']",
      "div[role='dialog'] input[type='text']"
    ],
    noResultsIndicators: [
      "No messages matched your search",
      "Your search did not match any conversations"
    ],
    // Selectors for True Bulk Delete feature
    selectAllBanner: [
      "span[role='link']",
      "span.bqY a", // Gmail's banner link class
      "div.ya span[role='link']"
    ],
    bulkConfirmDialog: [
      "div[role='alertdialog']",
      "div[role='dialog'][data-is-confirm]",
      "div.Kj-JD" // Gmail's dialog class
    ]
  });

  /**
   * Get the main Gmail content root.
   * @returns {Element}
   */
  const getMainRoot = () => qs(SELECTORS.main) || document;

  /**
   * Locate the primary Gmail toolbar if present.
   * @returns {HTMLElement | null}
   */
  const findToolbarRoot = () => qsFirst(SELECTORS.toolbar);

  // =========================
  // Generic DOM wait helper
  // =========================

  /**
   * Repeatedly calls fn until it returns a truthy value or times out.
   * Cancels if the run is marked CANCELLED.
   * @template T
   * @param {() => T | Promise<T>} fn
   * @param {Object} [opts]
   * @param {number} [opts.timeout]
   * @param {number} [opts.interval]
   * @param {string} [opts.description]
   * @returns {Promise<T | null>}
   */
  async function waitFor(
    fn,
    {
      timeout = TIMING.WAIT_DEFAULT_TIMEOUT,
      interval = TIMING.WAIT_DEFAULT_INTERVAL,
      description = "condition"
    } = {}
  ) {
    const start = Date.now();
    let lastError = null;

    while (Date.now() - start < timeout) {
      if (CANCELLED) {
        throw new CancellationError(`Cancelled while waiting for ${description}`);
      }

      try {
        const value = await fn();
        if (value) return value;
      } catch (e) {
        lastError = e;
        // Keep polling on error
      }

      await sleep(interval);
    }

    debugLog(`waitFor timed out: ${description}`, { 
      timeout, 
      lastError: lastError?.message 
    });

    return null;
  }

  /**
   * Wait for an element matching any of the given selectors.
   * @param {string[]} selectors
   * @param {Object} [opts]
   * @param {number} [opts.timeout]
   * @param {ParentNode} [opts.root]
   * @returns {Promise<Element | null>}
   */
  async function waitForElement(selectors, { timeout = TIMING.WAIT_DEFAULT_TIMEOUT, root = document } = {}) {
    return waitFor(
      () => qsFirst(selectors, root),
      { timeout, description: `element matching ${selectors.join(" | ")}` }
    );
  }

  // =========================
  // Button finder utilities
  // =========================

  /**
   * @typedef {Object} ButtonMatch
   * @property {Element} el
   * @property {number} score
   */

  /**
   * Generic button finder that scores buttons based on label tokens.
   * @param {string[]} tokens - Label tokens to match
   * @param {RegExp} primaryPattern - Primary regex pattern for higher scoring
   * @param {ParentNode} [root]
   * @returns {HTMLElement | null}
   */
  function findButtonByTokens(tokens, primaryPattern, root = findToolbarRoot() || document) {
    const buttons = qsa("div[role='button'], button", root);

    /** @type {ButtonMatch[]} */
    const scored = [];

    for (const el of buttons) {
      const label = getElementLabel(el).toLowerCase();
      let score = 0;

      // Score based on matching known tokens
      for (const token of tokens) {
        if (label.includes(token.toLowerCase())) {
          score += 2;
        }
      }

      // Higher score for primary pattern match
      if (primaryPattern.test(label)) {
        score += 3;
      }

      // Check child elements for additional matches
      const child = el.querySelector("[aria-label],[data-tooltip],[title]");
      if (child) {
        const childLabel = getElementLabel(child).toLowerCase();
        if (primaryPattern.test(childLabel)) {
          score += 1;
        }
      }

      if (score > 0) {
        scored.push({ el, score });
      }
    }

    // Sort by score descending and return highest
    scored.sort((a, b) => b.score - a.score);
    return scored.length > 0 ? /** @type {HTMLElement} */ (scored[0].el) : null;
  }

  /**
   * Find the Delete button in the toolbar.
   * @returns {HTMLElement | null}
   */
  const findDeleteButton = () =>
    findButtonByTokens(DELETE_LABEL_TOKENS, /delete|trash|bin/i);

  /**
   * Find the Archive button in the toolbar.
   * @returns {HTMLElement | null}
   */
  const findArchiveButton = () =>
    findButtonByTokens(ARCHIVE_LABEL_TOKENS, /archive/i);

  /**
   * Find the Labels button in the toolbar.
   * @returns {HTMLElement | null}
   */
  const findLabelButton = () =>
    findButtonByTokens(LABEL_BUTTON_TOKENS, /label/i);

  // =========================
  // True Bulk Delete Helpers
  // =========================

  /**
   * Look for and click the "Select all X conversations" link that appears
   * after clicking the master checkbox. This enables true bulk selection
   * beyond the visible page (50 items).
   * @returns {Promise<boolean>} True if the link was found and clicked
   */
  async function clickSelectAllConversations() {
    // Give Gmail time to render the banner after checkbox click
    await sleep(TIMING.CHECKBOX_SETTLE_DELAY);

    const mainRoot = getMainRoot();
    
    // Look for spans/links containing "Select all" + "conversations"
    const candidates = qsa("span, a", mainRoot);

    for (const el of candidates) {
      const text = getTextContent(el);
      const lowerText = text.toLowerCase();

      // Check if this element contains "select all" pattern with conversation count
      const hasSelectAll = SELECT_ALL_TOKENS.some(token => 
        lowerText.includes(token.toLowerCase())
      );
      const hasConversations = /conversation|message/i.test(lowerText);
      const hasCount = /\d+/.test(text);

      if (hasSelectAll && hasConversations && hasCount) {
        // Verify this looks clickable
        const role = getAttr(el, "role");
        const isClickable = role === "link" || 
                           el.tagName === "A" ||
                           el.closest("a") ||
                           window.getComputedStyle(el).cursor === "pointer";

        if (isClickable || hasSelectAll) {
          try {
            el.click();
            await sleep(TIMING.SELECT_ALL_SETTLE_DELAY);
            debugLog("Clicked 'Select all conversations' link", { 
              text: text.substring(0, 100) 
            });
            return true;
          } catch (e) {
            debugLog("Failed to click select all link", { error: e?.message });
          }
        }
      }
    }

    // Alternative: look for any link in the selection banner area
    const bannerLink = qsFirst(SELECTORS.selectAllBanner, mainRoot);
    if (bannerLink) {
      const text = getTextContent(bannerLink);
      if (/select.*all|all.*conversation/i.test(text)) {
        try {
          bannerLink.click();
          await sleep(TIMING.SELECT_ALL_SETTLE_DELAY);
          debugLog("Clicked banner select all link", { text: text.substring(0, 100) });
          return true;
        } catch (e) {
          debugLog("Failed to click banner link", { error: e?.message });
        }
      }
    }

    debugLog("No 'Select all conversations' link found");
    return false;
  }

  /**
   * Handle the bulk action confirmation dialog that Gmail shows when
   * attempting to delete/archive a large number of items.
   * @returns {Promise<boolean>} True if confirmation was handled
   */
  async function handleBulkConfirmation() {
    // Wait for potential dialog to appear
    const dialog = await waitFor(
      () => {
        const dialogs = qsa("div[role='alertdialog'], div[role='dialog']");
        for (const d of dialogs) {
          const text = getTextContent(d).toLowerCase();
          // Check for confirmation-related text
          if (
            text.includes("confirm") ||
            text.includes("are you sure") ||
            text.includes("bulk") ||
            text.includes("this action") ||
            text.includes("conversations will be")
          ) {
            return d;
          }
        }
        return null;
      },
      { 
        timeout: TIMING.BULK_CONFIRM_TIMEOUT, 
        interval: 100,
        description: "bulk confirmation dialog" 
      }
    );

    if (!dialog) {
      // No confirmation dialog appeared - that's normal for smaller selections
      debugLog("No bulk confirmation dialog appeared");
      return false;
    }

    debugLog("Bulk confirmation dialog detected", { 
      text: getTextContent(dialog).substring(0, 200) 
    });

    // Find and click the OK/Confirm button
    const buttons = qsa("button, div[role='button']", dialog);
    
    for (const btn of buttons) {
      const text = getTextContent(btn);
      const lowerText = text.toLowerCase();
      const name = getAttr(btn, "name").toLowerCase();

      // Check against confirm tokens
      const isConfirmButton = CONFIRM_TOKENS.some(token => 
        lowerText === token.toLowerCase() || 
        name === token.toLowerCase()
      );

      if (isConfirmButton) {
        try {
          btn.click();
          await sleep(TIMING.DOM_SETTLE_DELAY);
          debugLog("Clicked OK on bulk confirmation dialog", { buttonText: text });
          return true;
        } catch (e) {
          debugLog("Failed to click confirmation button", { error: e?.message });
        }
      }
    }

    // Fallback: try the first primary-looking button
    const primaryBtn = qs("button[name='ok'], button.J-at1-auR", dialog);
    if (primaryBtn) {
      try {
        primaryBtn.click();
        await sleep(TIMING.DOM_SETTLE_DELAY);
        debugLog("Clicked fallback primary button on dialog");
        return true;
      } catch (e) {
        debugLog("Failed to click fallback button", { error: e?.message });
      }
    }

    debugLog("Could not find confirmation button in dialog");
    return false;
  }

  // =========================
  // Rules: build query list
  // =========================

  /** @type {Readonly<Record<Intensity, readonly string[]>>} */
  const DEFAULT_RULES = Object.freeze({
    // "Light" is now optimized for the "Monthly Light Clean" preset
    light: Object.freeze([
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "category:promotions older_than:1y",
      "category:social older_than:1y",
      "\"unsubscribe\" older_than:2y"
    ]),
    normal: Object.freeze([
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "has:attachment larger:5M older_than:2y",
      "category:promotions older_than:3m",
      "category:promotions older_than:1y",
      "category:social older_than:6m",
      "category:updates older_than:6m",
      "category:forums older_than:6m",
      "has:newsletter older_than:6m",
      "\"unsubscribe\" older_than:1y",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:6m"
    ]),
    deep: Object.freeze([
      "larger:20M",
      "has:attachment larger:10M older_than:3m",
      "has:attachment larger:5M older_than:1y",
      "category:promotions older_than:2m",
      "category:promotions older_than:6m",
      "category:social older_than:3m",
      "category:social older_than:6m",
      "category:updates older_than:3m",
      "category:forums older_than:3m",
      "has:newsletter older_than:3m",
      "\"unsubscribe\" older_than:6m",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:3m"
    ])
  });

  /**
   * Load rules from storage (if present), otherwise use defaults.
   * Applies safeMode filtering to avoid Updates/Forums if requested.
   * @param {Intensity} intensity
   * @returns {Promise<string[]>}
   */
  async function getRules(intensity) {
    const riskyCategories = ["category:updates", "category:forums"];

    const stripRisky = (rules) => {
      if (!CONFIG.safeMode) return rules;
      return rules.filter((q) => 
        !riskyCategories.some((cat) => q.includes(cat))
      );
    };

    try {
      if (hasChromeStorage("sync")) {
        const result = await new Promise((resolve) => {
          chrome.storage.sync.get("rules", resolve);
        });
        
        const allRules = result?.rules ?? DEFAULT_RULES;
        const set = allRules[intensity] ?? allRules.normal ?? DEFAULT_RULES.normal;
        return stripRisky([...set]);
      }
    } catch (e) {
      debugLog("Failed to load rules from storage", { error: e?.message });
    }

    const fallback = DEFAULT_RULES[intensity] ?? DEFAULT_RULES.normal;
    return stripRisky([...fallback]);
  }

  /**
   * Query label mapping for human-friendly display.
   * @type {ReadonlyArray<[RegExp, string]>}
   */
  const QUERY_LABEL_MAP = Object.freeze([
    [/larger:/, "Big attachments"],
    [/category:promotions/, "Promotions"],
    [/category:social/, "Social"],
    [/category:updates/, "Updates"],
    [/category:forums/, "Forums"],
    [/newsletter|unsubscribe/, "Newsletters"],
    [/no-reply|donotreply|do-not-reply/, "No-reply"]
  ]);

  /**
   * Map a raw Gmail query string to a human-friendly label for the UI.
   * @param {string} query
   * @returns {string}
   */
  function labelQuery(query) {
    const lowerQuery = query.toLowerCase();

    for (const [pattern, label] of QUERY_LABEL_MAP) {
      if (pattern.test(lowerQuery)) {
        return label;
      }
    }

    return "Other";
  }

  /**
   * Apply global guardrails (skip starred/important, minimum age, whitelist) to a query.
   * Does NOT mutate the original string.
   * @param {string} raw
   * @returns {string}
   */
  function applyGlobalGuards(raw) {
    const parts = [(raw || "").trim()];

    if (!parts[0]) return "";

    if (CONFIG.guardSkipStarred && !/is:starred/i.test(parts[0])) {
      parts.push("-is:starred");
    }

    if (CONFIG.guardSkipImportant && !/is:important/i.test(parts[0])) {
      parts.push("-is:important");
    }

    if (CONFIG.minAge && !/older_than:\d+[dwmy]/i.test(parts[0])) {
      parts.push(`older_than:${CONFIG.minAge}`);
    }

    // Apply whitelist exclusions
    for (const sender of CONFIG.whitelist) {
      const trimmed = sender.trim();
      if (trimmed) {
        parts.push(`-from:${trimmed}`);
      }
    }

    return parts.join(" ").trim();
  }

  // =========================
  // MB / Size Helpers
  // =========================

  /**
   * Estimate the MB size of a single email based on the query string.
   * Looks for "larger:XM" or specific attachment flags.
   * @param {string} query
   * @returns {number} - Estimated MB per email
   */
  function estimateMbPerEmail(query) {
    const lower = query.toLowerCase();

    // 1. Check for explicit "larger:XM"
    const sizeMatch = lower.match(/larger:(\d+)(m|k|b)?/);
    if (sizeMatch) {
      let val = parseFloat(sizeMatch[1]);
      const unit = (sizeMatch[2] || "b");
      
      if (unit === "k") val = val / 1024;
      else if (unit === "b") val = val / (1024 * 1024);
      // if 'm', it's already MB

      return val;
    }

    // 2. Check for attachments (assume avg 2MB if no size specified but attachment present)
    if (lower.includes("has:attachment") || lower.includes("filename:")) {
      return 2.0; 
    }

    // 3. Fallback for text emails (negligible size, e.g. 0.05MB)
    return 0.05;
  }

  // =========================
  // Navigation & actions
  // =========================

  /**
   * Open a Gmail search for the given query in the current account.
   * Waits until the message list/grid is present.
   * @param {string} query
   * @throws {Error} If search results don't load in time
   */
  async function openSearch(query) {
    const base = getGmailBaseUrl();
    const hash = `#search/${encodeURIComponent(query)}`;

    if (!location.href.startsWith(base)) {
      location.href = base + hash;
    } else {
      location.hash = hash;
    }

    const ok = await waitFor(
      () => {
        const main = qs(SELECTORS.main);
        return main && (qs(SELECTORS.grid, main) || qs(SELECTORS.listContainer, main));
      },
      { 
        timeout: TIMING.WAIT_SEARCH_TIMEOUT,
        description: "Gmail search results"
      }
    );

    if (!ok) {
      throw new TimeoutError(
        "Timed out waiting for Gmail search results. Gmail might still be loading or the layout changed."
      );
    }

    // Give Gmail time to fully render rows
    await sleep(TIMING.DOM_SETTLE_DELAY);
  }

  /**
   * Click the "Select all" master checkbox for the current message list.
   * @returns {boolean} True if a checkbox was found and clicked
   */
  function clickMasterCheckbox() {
    const checkbox = qsFirst(SELECTORS.masterCheckbox);

    if (checkbox) {
      try {
        checkbox.click();
        return true;
      } catch (e) {
        debugLog("Failed to click master checkbox", { error: e?.message });
      }
    }

    return false;
  }

  /**
   * Dispatch a keyboard event safely.
   * @param {string} key
   * @param {string} code
   * @param {Object} [options]
   * @returns {boolean}
   */
  function dispatchKeyEvent(key, code, options = {}) {
    try {
      const event = new KeyboardEvent("keydown", {
        key,
        code,
        bubbles: true,
        cancelable: true,
        ...options
      });
      document.body.dispatchEvent(event);
      return true;
    } catch (e) {
      debugLog("Failed to dispatch key event", { key, error: e?.message });
      return false;
    }
  }

  /**
   * Try to trigger a delete action via button or keyboard shortcuts.
   * @returns {Promise<boolean>} True if a delete attempt was made
   */
  async function tryDeleteAction() {
    // Try button first
    const btn = findDeleteButton();
    if (btn) {
      try {
        btn.click();
        return true;
      } catch (e) {
        debugLog("Failed to click delete button", { error: e?.message });
      }
    }

    // Fallback: Gmail's Shift + # shortcut
    if (dispatchKeyEvent("#", "Digit3", { shiftKey: true })) {
      await sleep(TIMING.KEYBOARD_ACTION_DELAY);
      return true;
    }

    // Final fallback: Delete key
    if (dispatchKeyEvent("Delete", "Delete")) {
      await sleep(TIMING.KEYBOARD_ACTION_DELAY);
      return true;
    }

    return false;
  }

  /**
   * Try to trigger an archive action via button or keyboard shortcuts.
   * @returns {Promise<boolean>} True if an archive attempt was made
   */
  async function tryArchiveAction() {
    // Try button first
    const btn = findArchiveButton();
    if (btn) {
      try {
        btn.click();
        return true;
      } catch (e) {
        debugLog("Failed to click archive button", { error: e?.message });
      }
    }

    // Gmail archive shortcut: "e"
    if (dispatchKeyEvent("e", "KeyE")) {
      await sleep(TIMING.KEYBOARD_ACTION_DELAY);
      return true;
    }

    // Alternative: "y"
    if (dispatchKeyEvent("y", "KeyY")) {
      await sleep(TIMING.KEYBOARD_ACTION_DELAY);
      return true;
    }

    return false;
  }

  /**
   * Apply a tag/label to the currently selected conversations.
   * If anything fails, it silently returns false so cleanup can continue.
   * @param {string} labelName
   * @returns {Promise<boolean>}
   */
  async function applyTagLabel(labelName) {
    if (!labelName?.trim()) return false;

    const btn = findLabelButton();
    if (!btn) {
      safeSend({
        phase: "tag",
        status: "Label button not found; skipping tag.",
        detail: labelName
      });
      return false;
    }

    try {
      btn.click();
    } catch (e) {
      debugLog("Failed to click label button", { error: e?.message });
      return false;
    }

    // Wait for the label dialog / input to appear
    const input = await waitForElement(SELECTORS.labelInputs, {
      timeout: TIMING.LABEL_DIALOG_TIMEOUT
    });

    if (!input || !(input instanceof HTMLInputElement)) {
      safeSend({
        phase: "tag",
        status: "Label input not found; skipping tag.",
        detail: labelName
      });
      return false;
    }

    try {
      input.focus();
      input.value = "";
      input.dispatchEvent(new Event("input", { bubbles: true }));

      input.value = labelName;
      input.dispatchEvent(new Event("input", { bubbles: true }));

      // Press Enter to create/select the label and apply it
      const enterEvent = new KeyboardEvent("keydown", {
        key: "Enter",
        code: "Enter",
        bubbles: true,
        cancelable: true
      });
      input.dispatchEvent(enterEvent);

      // Give Gmail time to apply labels and close dialog
      await sleep(TIMING.LABEL_APPLY_DELAY);

      safeSend({
        phase: "tag",
        status: "Tagged selection before action.",
        detail: labelName
      });

      return true;
    } catch (e) {
      debugLog("Failed to apply tag label", { labelName, error: e?.message });
      return false;
    }
  }

  // =========================
  // Result detection helpers
  // =========================

  /**
   * Detect if the current search has no matching conversations.
   * @returns {boolean}
   */
  function hasNoResults() {
    const mainRoot = getMainRoot();

    // Check for empty grid
    const grid = qs(SELECTORS.grid, mainRoot);
    if (grid) {
      const rows = qsa("tr[role='row']", grid);
      if (rows.length === 0) return true;
    }

    // Check for "no results" text
    const spans = qsa("span", mainRoot);
    return spans.some((el) => {
      const text = getTextContent(el);
      return SELECTORS.noResultsIndicators.some((indicator) => 
        text.includes(indicator)
      );
    });
  }

  /**
   * Parse a number from text like "1–50 of 2,345" or "About 5,432 results".
   * @param {string} text
   * @returns {number | null}
   */
  function parseCountFromText(text) {
    if (!text) return null;

    // Try "of X" pattern first
    const ofMatch = text.match(/\bof\s+([\d,.\s]+)/i);
    if (ofMatch) {
      const n = parseInt(ofMatch[1].replace(/[,.\s]/g, ""), 10);
      if (Number.isFinite(n) && n > 0) return n;
    }

    // Try "About X results" pattern
    const aboutMatch = text.match(/\babout\s+([\d,.\s]+)\s+results/i);
    if (aboutMatch) {
      const n = parseInt(aboutMatch[1].replace(/[,.\s]/g, ""), 10);
      if (Number.isFinite(n) && n > 0) return n;
    }

    return null;
  }

  /**
   * Try to estimate the total result count from Gmail's UI.
   * @returns {number | null}
   */
  function estimateTotalResults() {
    const mainRoot = getMainRoot();
    const nodes = qsa("span, div", mainRoot);

    for (const el of nodes) {
      const text = getTextContent(el);
      const count = parseCountFromText(text);
      if (count !== null) return count;
    }

    return null;
  }

  /**
   * Extract the "X selected" count from Gmail's selection banner.
   * @returns {number | null}
   */
  function extractSelectedCount() {
    const spans = qsa("span");
    const banner = spans.find((el) => /selected/i.test(getTextContent(el)));

    if (!banner) return null;

    const text = getTextContent(banner);
    const matches = text.match(/([\d,.\s]+)/g);

    if (!matches?.length) return null;

    const lastMatch = matches[matches.length - 1];
    const n = parseInt(lastMatch.replace(/[,.\s]/g, ""), 10);

    return Number.isFinite(n) ? n : null;
  }

  // =========================
  // Page action routine
  // =========================

  /**
   * @typedef {Object} PageActionResult
   * @property {boolean} deleted - Whether action was performed
   * @property {number} count - Number of items affected
   * @property {string} [reason] - Reason if action wasn't performed
   * @property {boolean} [bulkSelected] - Whether bulk selection was used
   */

  /**
   * Selects all messages on the current page and deletes/archives them (unless dryRun).
   * Now includes True Bulk Delete: attempts to select ALL conversations matching
   * the search, not just the visible page.
   * Returns stats about what happened.
   * @param {string | null} tagLabel
   * @returns {Promise<PageActionResult>}
   */
  async function actOnCurrentPageIfAny(tagLabel) {
    if (hasNoResults()) {
      debugLog("No results on current page");
      return { deleted: false, count: 0, reason: "No results" };
    }

    // Wait for the toolbar to appear
    await waitFor(findToolbarRoot, {
      timeout: TIMING.WAIT_TOOLBAR_TIMEOUT,
      description: "toolbar"
    });

    if (!clickMasterCheckbox()) {
      debugLog("Master checkbox not found");
      return { deleted: false, count: 0, reason: "No master checkbox" };
    }

    await sleep(TIMING.CHECKBOX_SETTLE_DELAY);

    // ===== TRUE BULK DELETE: Try to select ALL conversations =====
    let bulkSelected = false;
    const initialSelectedCount = extractSelectedCount();
    
    // Attempt to click "Select all X conversations" link
    const clickedSelectAll = await clickSelectAllConversations();
    
    if (clickedSelectAll) {
      bulkSelected = true;
      debugLog("Bulk selection activated");
      
      // Re-check selected count after bulk selection
      await sleep(TIMING.DOM_SETTLE_DELAY);
    }
    // ===== END TRUE BULK DELETE ENHANCEMENT =====

    const selectedCount = extractSelectedCount() ?? initialSelectedCount;
    const actionWord = CONFIG.archiveInsteadOfDelete ? "archive" : "delete";

    // Run-level soft cap guardrail (live mode only)
    if (!CONFIG.dryRun) {
      const projectedTotal = liveRunProcessedSoFar + (selectedCount ?? 0);

      if (projectedTotal > GUARDRAILS.RUN_SOFT_CAP && !window.GCC_CONFIRMED_SOFT_CAP) {
        const confirmed = confirm(
          `Gmail Cleaner: this run is about to ${actionWord} about ${projectedTotal.toLocaleString()} conversations.\n\n` +
          "If your inbox is very large, you may want to start with a smaller rule set, Dry Run, or Safe Mode.\n\n" +
          "Continue anyway?"
        );
        
        if (!confirmed) {
          debugLog("User cancelled at soft cap confirmation", { projectedTotal });
          return { deleted: false, count: 0, reason: "user-soft-cap-cancelled" };
        }
        
        window.GCC_CONFIRMED_SOFT_CAP = true;
      }
    }

    // Tag selection before action (live mode only)
    if (!CONFIG.dryRun && tagLabel && CONFIG.tagBeforeDelete) {
      try {
        await applyTagLabel(tagLabel);
      } catch (e) {
        safeSend({
          phase: "tag",
          status: "Error while tagging; continuing without tag.",
          detail: String(e?.message || e)
        });
      }
    }

    // Dry-run: just report counts
    if (CONFIG.dryRun) {
      const estimated = selectedCount ?? estimateTotalResults() ?? 0;
      debugLog("Dry run page estimate", { estimated, bulkSelected });
      return { deleted: false, count: estimated, reason: "dry-run", bulkSelected };
    }

    const estimatedTotal = selectedCount ?? estimateTotalResults();

    // Extra confirmation for extremely large destructive runs
    if (
      !CONFIG.archiveInsteadOfDelete &&
      estimatedTotal &&
      estimatedTotal > GUARDRAILS.HUGE_RUN_CONFIRM_THRESHOLD &&
      !window.GCC_CONFIRMED_HUGE
    ) {
      const confirmed = confirm(
        `About to delete ~${estimatedTotal.toLocaleString()} conversations. Continue?`
      );
      
      if (!confirmed) {
        debugLog("User cancelled at huge-run confirmation", { estimatedTotal });
        return { deleted: false, count: 0, reason: "user-cancelled" };
      }
      
      window.GCC_CONFIRMED_HUGE = true;
    }

    // Perform the action
    const actionSuccess = CONFIG.archiveInsteadOfDelete
      ? await tryArchiveAction()
      : await tryDeleteAction();

    if (!actionSuccess) {
      const reason = CONFIG.archiveInsteadOfDelete
        ? "No archive button"
        : "No delete button";
      debugLog("No action button found", { reason });
      return { deleted: false, count: 0, reason };
    }

    // ===== TRUE BULK DELETE: Handle confirmation dialog =====
    if (bulkSelected) {
      const confirmedBulk = await handleBulkConfirmation();
      debugLog("Bulk confirmation result", { confirmedBulk });
    }
    // ===== END TRUE BULK DELETE CONFIRMATION =====

    // Give Gmail time to process the action
    await sleep(TIMING.POST_ACTION_DELAY_MS);

    liveRunProcessedSoFar += selectedCount ?? 0;

    return { deleted: true, count: selectedCount ?? 0, bulkSelected };
  }

  // =========================
  // Stats & per-query processing
  // =========================

  /**
   * @typedef {Object} QueryStats
   * @property {string} query
   * @property {string} label
   * @property {number} count
   * @property {"dry" | "live"} mode
   * @property {number} durationMs
   */

  /**
   * @typedef {Object} RunStats
   * @property {number} totalDeleted
   * @property {number} totalWouldDelete
   * @property {number} totalFreedMb
   * @property {QueryStats[]} perQuery
   */

  /** @type {RunStats} */
  const stats = {
    totalDeleted: 0,
    totalWouldDelete: 0,
    totalFreedMb: 0,
    perQuery: []
  };

  /**
   * Reset stats for a new run.
   */
  function resetStats() {
    stats.totalDeleted = 0;
    stats.totalWouldDelete = 0;
    stats.totalFreedMb = 0;
    stats.perQuery = [];
  }

  /**
   * Helper to wait for the user to click Proceed or Skip in Review Mode.
   * @returns {Promise<"resume" | "skip" | "cancel" | null>}
   */
  async function waitForReviewResponse() {
    REVIEW_SIGNAL = null;

    while (!REVIEW_SIGNAL && !CANCELLED) {
      await sleep(TIMING.REVIEW_POLL_INTERVAL);
    }

    return REVIEW_SIGNAL;
  }

  /**
   * Record stats for a completed query.
   * @param {Object} params
   * @param {string} params.query
   * @param {string} params.label
   * @param {number} params.count
   * @param {"dry" | "live"} params.mode
   * @param {number} params.durationMs
   */
  function recordQueryStats({ query, label, count, mode, durationMs }) {
    const queryStats = { query, label, count, mode, durationMs };
    stats.perQuery.push(queryStats);

    safeSend({
      phase: "query-done",
      ...queryStats
    });

    debugLog("Query completed", queryStats);
  }

  /**
   * Run a single Gmail query through up to PASS_CAP passes until empty.
   * @param {string} query
   * @param {number} idx
   * @param {number} total
   */
  async function processQuery(query, idx, total) {
    const label = labelQuery(query);
    const tagLabel = !CONFIG.dryRun && CONFIG.tagBeforeDelete
      ? `${CONFIG.tagLabelPrefix} - ${label}`
      : null;
    const guardedQuery = applyGlobalGuards(query);
    const start = Date.now();
    let pass = 0;
    let queryDeletedCount = 0;
    let hasReviewedThisQuery = false;

    // Estimate size per email for this query to calculate Freed MB
    const mbPerEmail = estimateMbPerEmail(guardedQuery);

    debugLog("Processing query", {
      rawQuery: query,
      guardedQuery,
      index: idx + 1,
      total,
      dryRun: CONFIG.dryRun,
      mbPerEmail
    });

    while (pass < TIMING.PASS_CAP) {
      if (CANCELLED) {
        throw new CancellationError("Query processing cancelled");
      }

      const percent = Math.round((idx / total) * 100);
      safeSend({
        phase: "query",
        status: `Cleaning ${label} (${idx + 1}/${total})`,
        detail: `Pass ${pass + 1}`,
        percent
      });

      await openSearch(guardedQuery);

      // Check for empty results
      if (hasNoResults()) {
        const durationMs = Date.now() - start;
        const mode = CONFIG.dryRun ? "dry" : "live";

        safeSend({ detail: `No results for: ${guardedQuery}` });
        
        recordQueryStats({
          query,
          label,
          count: CONFIG.dryRun ? 0 : queryDeletedCount,
          mode,
          durationMs
        });

        break;
      }

      // Review Mode: pause for user confirmation (once per query)
      if (CONFIG.reviewMode && !hasReviewedThisQuery && !CONFIG.dryRun) {
        const estimated = estimateTotalResults() ?? "many";

        safeSend({
          phase: "review",
          status: "Paused for review",
          detail: `Found ~${estimated} items for "${label}". Waiting for input...`,
          queryLabel: label,
          queryCount: estimated
        });

        safeSendImmediate({
          type: "gmailCleanerRequestReview",
          label,
          query: guardedQuery,
          count: estimated
        });

        const signal = await waitForReviewResponse();

        if (signal === "skip" || signal === "cancel") {
          debugLog("User skipped/cancelled query via Review Mode", { signal, label });
          break;
        }

        hasReviewedThisQuery = true;
      }

      const result = await actOnCurrentPageIfAny(tagLabel);

      // Handle dry run
      if (CONFIG.dryRun) {
        const durationMs = Date.now() - start;
        const count = result.count || estimateTotalResults() || 0;

        stats.totalWouldDelete += count;
        
        safeSend({ detail: `Dry-Run: would affect ${count} for: ${guardedQuery}` });
        
        recordQueryStats({ query, label, count, mode: "dry", durationMs });
        break;
      }

      // Handle no action case
      if (!result.deleted) {
        const durationMs = Date.now() - start;
        
        safeSend({ detail: `Nothing to act on for: ${guardedQuery} (${result.reason})` });
        
        recordQueryStats({
          query,
          label,
          count: queryDeletedCount,
          mode: "live",
          durationMs
        });
        break;
      }

      // Successful action for this pass
      const affectedThisPass = result.count || 0;
      queryDeletedCount += affectedThisPass;
      stats.totalDeleted += affectedThisPass;
      stats.totalFreedMb += (affectedThisPass * mbPerEmail); // Track MB
      pass++;

      debugLog("Live pass completed", {
        query,
        pass,
        affectedThisPass,
        queryDeletedCount,
        totalDeleted: stats.totalDeleted,
        freedMbSoFar: stats.totalFreedMb,
        bulkSelected: result.bulkSelected
      });

      // If bulk selection was used, the query is likely exhausted in one pass
      if (result.bulkSelected) {
        debugLog("Bulk delete completed - skipping additional passes");
        const durationMs = Date.now() - start;
        recordQueryStats({
          query,
          label,
          count: queryDeletedCount,
          mode: "live",
          durationMs
        });
        break;
      }

      await sleep(TIMING.BETWEEN_PASS_SLEEP_MS);

      // Check if query is exhausted
      if (hasNoResults()) {
        const durationMs = Date.now() - start;
        
        recordQueryStats({
          query,
          label,
          count: queryDeletedCount,
          mode: "live",
          durationMs
        });
        break;
      }
    }
  }

  // =========================
  // History & Stats Persistence
  // =========================

  /**
   * Save run stats to local storage for history.
   * @param {Object} doneStats
   */
  async function saveRunHistory(doneStats) {
    if (!hasChromeStorage("local")) return;

    try {
      const result = await new Promise((resolve) => {
        chrome.storage.local.get("runHistory", resolve);
      });

      const history = Array.isArray(result?.runHistory) ? result.runHistory : [];
      history.unshift(doneStats);

      // Keep only last N entries
      if (history.length > GUARDRAILS.MAX_HISTORY_ENTRIES) {
        history.length = GUARDRAILS.MAX_HISTORY_ENTRIES;
      }

      await new Promise((resolve) => {
        chrome.storage.local.set({ runHistory: history }, resolve);
      });

      debugLog("Saved run history", { historyLength: history.length });
    } catch (e) {
      debugLog("Failed to save history", { error: e?.message });
    }
  }

  /**
   * Update Pro lifetime stats if applicable.
   * @param {Object} doneStats
   */
  async function updateProStats(doneStats) {
    if (!hasChromeStorage("sync")) return;

    try {
      const result = await new Promise((resolve) => {
        chrome.storage.sync.get(["proStatus", "proLifetimeStats"], resolve);
      });

      if (!result?.proStatus?.isPro) return;

      const prev = result.proLifetimeStats || {};
      const runCount = doneStats.mode === "dry"
        ? doneStats.totalWouldDelete || 0
        : doneStats.totalDeleted || 0;

      const next = {
        totalRuns: (prev.totalRuns || 0) + 1,
        totalDeleted: (prev.totalDeleted || 0) + (doneStats.totalDeleted || 0),
        totalWouldDelete: (prev.totalWouldDelete || 0) + (doneStats.totalWouldDelete || 0),
        totalQueries: (prev.totalQueries || 0) + (doneStats.totalQueries || 0),
        totalFreedMb: (prev.totalFreedMb || 0) + (doneStats.totalFreedMb || 0),
        biggestRun: Math.max(prev.biggestRun || 0, runCount)
      };

      await new Promise((resolve) => {
        chrome.storage.sync.set({ proLifetimeStats: next }, resolve);
      });

      debugLog("Updated Pro stats", next);
    } catch (e) {
      debugLog("Failed to update Pro stats", { error: e?.message });
    }
  }

  /**
   * Save last run stats for diagnostics.
   * @param {Object} doneStats
   */
  async function saveLastRunStats(doneStats) {
    if (!hasChromeStorage("sync")) return;

    try {
      await new Promise((resolve) => {
        chrome.storage.sync.set({ lastRunStats: doneStats }, resolve);
      });
    } catch (e) {
      debugLog("Failed to save last run stats", { error: e?.message });
    }
  }

  // =========================
  // Main driver
  // =========================

  /**
   * Build final stats object for completion.
   * @param {number} totalQueries
   * @returns {Object}
   */
  function buildFinalStats(totalQueries) {
    const mode = CONFIG.dryRun ? "dry" : "live";
    const runCount = mode === "dry"
      ? stats.totalWouldDelete
      : stats.totalDeleted;

    let sizeBucket = "tiny";
    if (runCount >= 500 && runCount < 2500) sizeBucket = "small";
    else if (runCount >= 2500 && runCount < 10000) sizeBucket = "medium";
    else if (runCount >= 10000) sizeBucket = "huge";

    const baseUrl = getGmailBaseUrl();

    return {
      mode,
      totalDeleted: stats.totalDeleted,
      totalWouldDelete: stats.totalWouldDelete,
      totalFreedMb: stats.totalFreedMb,
      totalQueries,
      perQuery: [...stats.perQuery],
      runCount,
      sizeBucket,
      isHugeRun: runCount >= 5000,
      finishedAt: Date.now(),
      version: GCC_CONTENT_VERSION,
      links: {
        trash: `${baseUrl}#trash`,
        allMail: `${baseUrl}#all`
      }
    };
  }

  /**
   * Generate human-readable summary message.
   * @param {Object} doneStats
   * @param {number} totalQueries
   * @returns {string}
   */
  function buildHumanSummary(doneStats, totalQueries) {
    const { runCount, mode } = doneStats;

    if (runCount === 0) {
      return mode === "dry"
        ? "Dry run finished: nothing matched your rules. No conversations would be changed."
        : "Cleanup finished: nothing matched your rules. No conversations were deleted or archived.";
    }

    if (mode === "dry") {
      return `Dry run finished: would affect about ${runCount.toLocaleString()} conversations across ${totalQueries} queries.`;
    }

    if (CONFIG.archiveInsteadOfDelete) {
        return `Cleanup finished: ${stats.totalDeleted.toLocaleString()} conversations archived across ${totalQueries} queries.`;
    }

    // Default Delete Mode summary with MB freed
    const mbStr = stats.totalFreedMb < 1 
      ? "<1" 
      : Math.round(stats.totalFreedMb).toLocaleString();

    return `Deleted ${stats.totalDeleted.toLocaleString()} emails / freed ${mbStr} MB (all in Trash).`;
  }

  /**
   * Main cleanup flow for all rules.
   */
  async function main() {
    if (RUNNING) {
      debugLog("Run already in progress, ignoring start request");
      return;
    }

    RUNNING = true;

    // Reset run state
    CANCELLED = false;
    REVIEW_SIGNAL = null;
    liveRunProcessedSoFar = 0;
    window.GCC_CONFIRMED_SOFT_CAP = false;
    window.GCC_CONFIRMED_HUGE = false;
    resetStats();

    debugLog("Run starting", {
      intensity: CONFIG.intensity,
      dryRun: CONFIG.dryRun,
      archiveInsteadOfDelete: CONFIG.archiveInsteadOfDelete,
      reviewMode: CONFIG.reviewMode,
      safeMode: CONFIG.safeMode
    });

    try {
      if (!isGmailTab()) {
        alert("Gmail Cleaner: please run this from a Gmail tab.");
        return;
      }

      const rawRules = await getRules(CONFIG.intensity);
      const rules = rawRules.filter((q) => typeof q === "string" && q.trim());
      const totalQueries = rules.length;

      if (totalQueries === 0) {
        const emptyStats = buildFinalStats(0);
        
        safeSendImmediate({
          phase: "done",
          status: "No rules to run.",
          detail: "Rule set is empty.",
          percent: 100,
          done: true,
          stats: emptyStats
        });
        
        debugLog("Run aborted: no rules");
        return;
      }

      safeSend({
        phase: "starting",
        status: "Starting Gmail cleanup...",
        detail: [
          `Level: ${CONFIG.intensity}`,
          `${totalQueries} queries`,
          CONFIG.archiveInsteadOfDelete ? "Mode: Archive" : "Mode: Delete",
          CONFIG.minAge ? `Min age: ${CONFIG.minAge}` : null,
          CONFIG.reviewMode ? "Review mode enabled" : null
        ].filter(Boolean).join(". ") + ".",
        percent: 0
      });

      // Process all queries
      for (let i = 0; i < rules.length; i++) {
        if (CANCELLED) {
          throw new CancellationError("Run cancelled by user");
        }
        await processQuery(rules[i], i, totalQueries);
      }

      // Build and save final stats
      const doneStats = buildFinalStats(totalQueries);
      const humanSummary = buildHumanSummary(doneStats, totalQueries);

      // Persist stats
      await Promise.allSettled([
        saveRunHistory(doneStats),
        updateProStats(doneStats),
        saveLastRunStats(doneStats)
      ]);

      safeSendImmediate({
        phase: "done",
        status: "Cleanup finished.",
        detail: humanSummary,
        percent: 100,
        done: true,
        stats: doneStats
      });

      debugLog("Run finished", {
        mode: doneStats.mode,
        runCount: doneStats.runCount,
        sizeBucket: doneStats.sizeBucket,
        freedMb: doneStats.totalFreedMb
      });

      // Show completion alert for live runs
      if (!CONFIG.dryRun && stats.totalDeleted > 0) {
        const destination = CONFIG.archiveInsteadOfDelete ? "All Mail" : "Trash";
        
        alert(
          `${humanSummary}\n\n` +
          `Check ${destination} if you need to restore anything.`
        );
      }

    } catch (e) {
      const isCancellation = e instanceof CancellationError || 
        (e instanceof Error && e.message.includes("Cancelled"));

      if (isCancellation) {
        safeSendImmediate({
          phase: "cancelled",
          status: "Run cancelled.",
          detail: "Stopped by user.",
          done: true,
          percent: 100
        });
        
        debugLog("Run cancelled", {
          totalDeleted: stats.totalDeleted,
          totalWouldDelete: stats.totalWouldDelete
        });
      } else {
        const errorMessage = e instanceof Error ? e.message : String(e);
        
        logError(e, "main run");
        
        safeSendImmediate({
          phase: "error",
          status: "Error occurred.",
          detail: errorMessage,
          done: true,
          percent: 100
        });
        
        debugLog("Run errored", { message: errorMessage });
      }
    } finally {
      RUNNING = false;
    }
  }

  /**
   * Public entry to start the main run (used by messages and auto-start).
   */
  function startMain() {
    if (!RUNNING) {
      main().catch((e) => logError(e, "startMain"));
    }
  }

  // Export for testing (if in test environment)
  if (typeof window !== "undefined" && window.GCC_TEST_MODE) {
    window.GCC_INTERNALS = {
      CONFIG,
      TIMING,
      GUARDRAILS,
      stats,
      labelQuery,
      applyGlobalGuards,
      parseCountFromText,
      sanitizeConfig,
      clickSelectAllConversations,
      handleBulkConfirmation
    };
  }

  // Auto-start once on injection
  startMain();
})();