{
type: uploaded file
fileName: README.md
fullContent:
# Gmail One-Click Cleaner (v3.2.0)

A Chrome MV3 extension that bulk-cleans Gmail in one click. It runs a configurable sequence of Gmail searches (promos, social, newsletters, large attachments, etc.), shows a live progress window with per-query stats, and supports Dry-Run, safe archiving, and custom rules.

> **Works best from a Gmail tab in Chrome** (or Chromium-based browsers like Brave/Edge).
> Store version: search **“Gmail One-Click Cleaner”** in the Chrome Web Store.

---

## Install (Developer Mode)

1. Download and unzip the project (or use the provided `.zip` and extract it).
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select the extension folder (the one containing `manifest.json`).
5. Pin the extension icon. Open Gmail, then click the extension icon to start.

---

## How It Works

- **Locates Gmail:** Injects a safe content script into the **Gmail tab you launched it from** (multi-account safe).
- **Runs Searches:** Cycles through your selected rule set (e.g., *Promotions*, *Social*, *Large Attachments*).
- **Safe Automation:** For each search, it:
  - Opens the search query in your Gmail tab.
  - Selects matching conversations.
  - **Live Mode:** Tags matches (e.g. `GmailCleaner - Promotions`) -> Deletes or Archives them.
  - **Review Mode:** (Optional) Pauses and asks for confirmation before acting on a batch.
  - **Dry-Run:** Counts matches only, calculates space/count estimates, and touches nothing.
- **Progress UI:** A dedicated tab shows:
  - Live progress bar & current phase.
  - Detailed table of every query run (items found, duration, MB freed).
  - Live activity logs.
- **Result Summary:** Upon completion, displays the total emails deleted and the estimated **MB of storage freed**.

---

## Features (v3.2.0)

### 1. New: Monthly Light Clean
- A "Recommended" quick-action preset.
- Automatically configures the cleaner to **Safe Mode**, **Trash**, and **3 Month** age limit.
- Perfect for regular maintenance without worrying about deleting important emails.

### 2. Guardrails & Safety
- **Action Type:** Choose between **Move to Trash** (Delete) or **Archive** (Keep in All Mail).
- **Minimum Age:** Global override to ensure no mail younger than 3 months, 6 months, etc., is ever touched.
- **Global Whitelist:** Define specific emails or domains (e.g., `boss@work.com`) in Options that are **never** touched.
- **Safety Toggles:**
  - **Skip Starred & Important:** Automatically excludes these items.
  - **Safe Mode:** Automatically skips risky categories like `Updates` (receipts) and `Forums`.

### 3. Smart UI & Reassurance
- **Pin Hint:** A friendly reminder to pin the extension for easy monthly access.
- **Soft Rating:** A prompt appears after 2-3 successful runs to ask for feedback.
- **Mini FAQ:** Built-in reassurance that nothing is permanently deleted until the Trash is emptied (30 days).

### 4. Review & Dry-Run Modes
- **Review Mode:** Pauses before every action to let you see exactly what matched.
- **Dry-Run:** Simulates a full cleanup, counting matches without touching a single email.

### 5. Tagging Before Deletion
- In **Live Mode**, matching conversations are labeled (e.g. `GmailCleaner - Promotions`) **before** action is taken, allowing for easy auditing in the Trash folder.

### 6. Diagnostics & History
- **Cleanup History:** Tracks your last 10 runs locally (date, mode, count, MB freed).
- **Diagnostics Page:** Helps troubleshoot if the extension can't find your Gmail tab.

---

## Jude’s Cheap Storage & Setup Picks
Cleaned your inbox but still running low on storage? Here are the budget picks recommended in the extension to upgrade your setup:

- **[Samsung T7 Portable SSD (1TB)](https://amzn.to/3MrwsMz)** - Best value external storage. Fast (1,050MB/s) and reliable.
- **[Lexar 128GB USB-C Dual Drive](https://amzn.to/3Mftfjl)** - Metal housing, swivel design. Great for moving files between laptop and phone.
- **[Amazon Basics Laptop Stand](https://amzn.to/4aBnKW6)** - Adjustable, sturdy, and improves posture instantly.
- **[Rii Ultra-Slim Compact Keyboard](https://amzn.to/4pqDwYB)** - The best budget keyboard (~$15). Quiet keys, Mac/PC compatible.
- **[192pc Cable Management Kit](https://amzn.to/48oWb0L)** - Everything you need to clean up messy desk wires.

*(As an Amazon Associate I earn from qualifying purchases.)*

---

## Options & Rules

Open the **Rules & Settings** page via the popup or extension management menu.

### Rule Sets
One Gmail search query per line.
- **Light:** Safest. Focuses on huge attachments (`larger:20M`) and very old promotions (`older_than:1y`).
- **Normal:** Recommended. Balanced cleanup of old social updates, newsletters, and attachments.
- **Deep:** Aggressive. Targets younger mail (`older_than:3m`). **Use with Dry-Run first.**

**Example Rules:**
- `category:promotions older_than:6m`
- `category:social older_than:1y`
- `has:attachment larger:10M older_than:6m`
- `"unsubscribe" older_than:1y`

### Global Whitelist
Enter email addresses (one per line) that should be ignored by **all** rules. The cleaner automatically appends `-from:...` to every search query it runs.

---

## Privacy & Data

- **Local Only:** All logic (searching, selecting, tagging, deleting) runs locally in your browser.
- **No Data Collection:** The extension does **not** send your email content, credentials, or metadata to any external server.
- **Permissions:** `activeTab`, `scripting`, `tabs`, `storage`.

> **Note:** Gmail keeps Trash for ~30 days. If you delete something by mistake, you can restore it from the Trash folder within that window.
}