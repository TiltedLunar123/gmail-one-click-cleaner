# Gmail One-Click Cleaner (v3.0)

A Chrome MV3 extension that bulk-cleans Gmail in one click. It runs a configurable sequence of Gmail searches (promos, social, newsletters, large attachments, etc.), shows a live progress window with per-query stats, and supports Dry-Run, safe archiving, and custom rules.

> **Works best from a Gmail tab in Chrome** (or Chromium-based browsers like Brave/Edge).
> Store version: search **“Gmail One-Click Cleaner”** in the Chrome Web Store.

---

## Install (Developer Mode)

1. Download and unzip the project (or use the provided `.zip` and extract it).
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select the extension folder (the one containing `manifest.json`).
5. Pin the extension icon. Open Gmail, then click the extension icon to start.

---

## How It Works

- **Locates Gmail:** Injects a safe content script into the **Gmail tab you launched it from** (multi-account safe).
- **Runs Searches:** cycles through your selected rule set (e.g., *Promotions*, *Social*, *Large Attachments*).
- **Safe Automation:** For each search, it:
  - Opens the search query in your Gmail tab.
  - Selects matching conversations.
  - **Live Mode:** Tags matches (e.g. `GmailCleaner - Promotions`) -> Deletes or Archives them.
  - **Review Mode:** (Optional) Pauses and asks for confirmation before acting on a batch.
  - **Dry-Run:** Counts matches only, calculates space/count estimates, and touches nothing.
- **Progress UI:** A dedicated tab shows:
  - Live progress bar & current phase.
  - Detailed table of every query run (items found, duration).
  - Live activity logs.

Internally it uses `chrome.scripting`, resilient DOM selectors, and a capped number of passes per query to avoid infinite loops when Gmail behaves oddly.

---

## Features (v3.0+)

### 1. Guardrails & Safety
- **Action Type:** Choose between **Move to Trash** (Delete) or **Archive** (Keep in All Mail).
- **Minimum Age:** Global override to ensure no mail younger than 3 months, 6 months, etc., is ever touched, regardless of your specific rules.
- **Global Whitelist (New):** Define specific emails or domains (e.g., `boss@work.com`) in Options that are **never** touched, regardless of any other rule.
- **Safety Toggles:**
  - **Skip Starred:** Automatically excludes starred items (`-is:starred`).
  - **Skip Important:** Automatically excludes important items (`-is:important`).
  - **Safe Mode:** Automatically skips risky categories like `Updates` (receipts) and `Forums` even if they are in your rules.

### 2. Review Mode (New)
- Enable **Review Matches** in the popup to pause the cleaner before it deletes anything.
- For every rule that finds matches, a modal appears showing the count and query.
- You can choose to **Proceed** with cleaning that batch or **Skip** it entirely.

### 3. Dry-Run Mode
- Toggle **Dry Run** in the popup to simulate a full cleanup.
- The extension runs the searches and counts the results but **does not delete or tag** anything.
- Perfect for testing new rules or "Deep" intensity without risk.

### 4. Tagging Before Deletion
- In **Live Mode**, matching conversations are labeled (e.g. `GmailCleaner - Promotions`) **before** action is taken.
- This allows you to easily audit your Trash or All Mail later to see exactly what the extension removed.

### 5. Custom Rules & Backup
- Edit the **Light**, **Normal**, and **Deep** query lists in the **Options** page.
- **Backup & Restore (New):** Export your custom configuration to a JSON file to save your rules or move them to another browser.

### 6. Diagnostics, History & Debugging
- **Cleanup History (New):** The Diagnostics page now tracks your last 10 runs locally, showing date, mode, and total conversations cleaned.
- **Diagnostics Page:** A dedicated tool to help if the extension can't find your Gmail tab.
  - Scans open tabs to see which one the extension will target.
  - Tests script injection.
  - Shows browser environment details.
- **Debug Logging:** Enable "Debug Mode" in **Options > Advanced** to print detailed logs to the browser console (F12) for troubleshooting.

---

## Options & Rules

Open the **Rules & Settings** page via the popup or extension management menu.

### Rule Sets
One Gmail search query per line.
- **Light:** Safest. Focuses on huge attachments (`larger:20M`) and very old promotions (`older_than:1y`).
- **Normal:** Recommended. Balanced cleanup of old social updates, newsletters, and attachments.
- **Deep:** Aggressive. Targets younger mail (`older_than:3m`) and broader categories. **Use with Dry-Run first.**

**Example Rules:**
- `category:promotions older_than:6m`
- `category:social older_than:1y`
- `has:attachment larger:10M older_than:6m`
- `"unsubscribe" older_than:1y`
- `from:(no-reply@ OR donotreply@) older_than:6m`

### Global Whitelist
Enter email addresses (one per line) that should be ignored by **all** rules.
- Example: `my-boss@company.com`
- Example: `*@family-domain.com`
The cleaner automatically appends `-from:...` to every search query it runs.

### Advanced Settings
- **Enable Debug Logging:** Outputs detailed technical logs to the Chrome DevTools Console. Useful for reporting bugs.

---

## Privacy & Data

- **Local Only:** All logic (searching, selecting, tagging, deleting) runs locally in your browser.
- **No Data Collection:** The extension does **not** send your email content, credentials, or metadata to any external server.
- **Permissions:**
  - `activeTab` / `tabs`: To find and communicate with your Gmail tab.
  - `scripting`: To inject the cleaning automation script.
  - `storage`: To save your preferences, history, and rules.
  - `host_permissions` (`mail.google.com`): To run on Gmail.

> **Note:** Gmail keeps Trash for ~30 days. If you delete something by mistake, you can restore it from the Trash folder within that window.