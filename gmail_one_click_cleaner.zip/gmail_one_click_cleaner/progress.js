(() => {
  "use strict";

  // =========================
  // Constants & Configuration
  // =========================

  const PROGRESS_VERSION = "3.1.0";

  const CONFIG = Object.freeze({
    MAX_LOG_ENTRIES: 300,
    TOAST_DURATION_MS: 3000,
    TIP_THRESHOLD_COUNT: 50,
    POLL_INTERVAL_MS: 2000,
    RECONNECT_TIMEOUT_MS: 5000
  });

  const PHASES = Object.freeze({
    BOOT: "boot",
    STARTING: "starting",
    QUERY: "query",
    QUERY_DONE: "query-done",
    TAG: "tag",
    REVIEW: "review",
    DONE: "done",
    CANCELLED: "cancelled",
    ERROR: "error"
  });

  const PHASE_LABELS = Object.freeze({
    [PHASES.BOOT]: "boot",
    [PHASES.STARTING]: "starting",
    [PHASES.QUERY]: "running queries",
    [PHASES.QUERY_DONE]: "query finished",
    [PHASES.TAG]: "tagging",
    [PHASES.REVIEW]: "reviewing",
    [PHASES.DONE]: "done",
    [PHASES.CANCELLED]: "cancelled",
    [PHASES.ERROR]: "error"
  });

  const LOG_LEVELS = Object.freeze({
    INFO: "info",
    SUCCESS: "success",
    WARNING: "warning",
    ERROR: "error"
  });

  // =========================
  // Parse URL Parameters
  // =========================

  const parseGmailTabId = () => {
    try {
      const params = new URLSearchParams(location.search);
      const raw = params.get("gmailTabId");
      
      if (raw === null || raw === "") return null;
      
      const parsed = Number(raw);
      return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
    } catch {
      return null;
    }
  };

  const gmailTabId = parseGmailTabId();

  // =========================
  // State Management
  // =========================

  const state = {
    lastPhase: PHASES.STARTING,
    done: false,
    mode: "live",
    logsExpanded: false,
    rows: [],
    tipShown: false,
    isReconnecting: false,
    logHistory: [],
    startTime: Date.now()
  };

  // =========================
  // DOM Element Cache
  // =========================

  const ui = {
    // Progress elements
    barInner: document.getElementById("barInner"),
    percentText: document.getElementById("percentText"),
    progressBar: document.querySelector(".bar"),
    
    // Status elements
    status: document.getElementById("status"),
    tags: document.getElementById("tags"),
    
    // Log elements
    details: document.getElementById("details"),
    copyLogsBtn: document.getElementById("copyLogsBtn"),
    clearLogsBtn: document.getElementById("clearLogsBtn"),
    
    // Control buttons
    cancel: document.getElementById("cancelBtn"),
    reconnect: document.getElementById("reconnectBtn"),
    reinject: document.getElementById("reinjectBtn"),
    toggleLogs: document.getElementById("toggleLogs"),
    
    // Summary elements
    panel: document.querySelector(".panel"),
    summary: document.getElementById("summary"),
    table: document.getElementById("summaryTable"),
    tipPrompt: document.getElementById("tipPrompt"),
    
    // Review modal (v2.0)
    reviewModal: document.getElementById("reviewModal"),
    modalCount: document.getElementById("modalCount"),
    modalQuery: document.getElementById("modalQuery"),
    modalSkipBtn: document.getElementById("modalSkipBtn"),
    modalProceedBtn: document.getElementById("modalProceedBtn"),
    
    // Toast container
    toastContainer: document.querySelector(".toast-container")
  };

  const tbody = ui.table?.querySelector("tbody") || null;

  // =========================
  // Utility Functions
  // =========================

  /**
   * Check if Chrome runtime is available.
   * @returns {boolean}
   */
  const hasChromeRuntime = () => {
    try {
      return typeof chrome !== "undefined" && !!chrome.runtime;
    } catch {
      return false;
    }
  };

  /**
   * Check if Chrome storage is available.
   * @param {"sync" | "local" | "session"} type
   * @returns {boolean}
   */
  const hasChromeStorage = (type = "sync") => {
    try {
      return (
        typeof chrome !== "undefined" &&
        chrome?.storage?.[type] &&
        typeof chrome.storage[type].get === "function"
      );
    } catch {
      return false;
    }
  };

  /**
   * Get current timestamp string.
   * @returns {string}
   */
  const getTimestamp = () => {
    const now = new Date();
    return now.toLocaleTimeString("en-US", {
      hour12: false,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
  };

  /**
   * Format duration in milliseconds to human readable.
   * @param {number} ms
   * @returns {string}
   */
  const formatDuration = (ms) => {
    if (ms == null || ms < 0) return "–";
    const sec = ms / 1000;
    return sec.toFixed(sec >= 10 ? 0 : 1) + "s";
  };

  /**
   * Format number with locale separators.
   * @param {number} num
   * @returns {string}
   */
  const formatNumber = (num) => {
    if (typeof num !== "number" || !Number.isFinite(num)) return "0";
    return num.toLocaleString();
  };

  /**
   * Escape HTML to prevent XSS.
   * @param {string} str
   * @returns {string}
   */
  const escapeHtml = (str) => {
    if (typeof str !== "string") return "";
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  };

  /**
   * Log to console with prefix.
   * @param {string} level
   * @param {...any} args
   */
  const log = (level, ...args) => {
    const prefix = "[Gmail Cleaner Progress]";
    console[level]?.(prefix, ...args);
  };

  // =========================
  // Toast Notifications
  // =========================

  const TOAST_ICONS = Object.freeze({
    success: "✅",
    error: "❌",
    warning: "⚠️",
    info: "ℹ️"
  });

  /**
   * Show a toast notification.
   * @param {string} message
   * @param {keyof typeof TOAST_ICONS} [type="info"]
   * @param {number} [duration]
   */
  const showToast = (message, type = "info", duration = CONFIG.TOAST_DURATION_MS) => {
    const container = ui.toastContainer;
    if (!container) {
      log("info", `[Toast ${type}]`, message);
      return;
    }

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.setAttribute("role", "alert");

    const icon = document.createElement("span");
    icon.className = "toast-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = TOAST_ICONS[type] || TOAST_ICONS.info;

    const text = document.createElement("span");
    text.textContent = message;

    toast.appendChild(icon);
    toast.appendChild(text);
    container.appendChild(toast);

    // Trigger animation
    requestAnimationFrame(() => {
      toast.classList.add("show");
    });

    // Remove after duration
    setTimeout(() => {
      toast.classList.remove("show");
      setTimeout(() => {
        toast.parentNode?.removeChild(toast);
      }, 300);
    }, duration);
  };

  // =========================
  // Status Management
  // =========================

  /**
   * Set status message.
   * @param {string} message
   */
  const setStatus = (message) => {
    if (!ui.status) return;
    
    // Remove spinner if present
    const spinner = ui.status.querySelector(".spinner");
    if (spinner) spinner.remove();
    
    // Get or create text span
    let textSpan = ui.status.querySelector("span:not(.spinner)");
    if (!textSpan) {
      ui.status.textContent = "";
      textSpan = document.createElement("span");
      ui.status.appendChild(textSpan);
    }
    
    textSpan.textContent = message || "";
  };

  /**
   * Set status with loading spinner.
   * @param {string} message
   */
  const setStatusLoading = (message) => {
    if (!ui.status) return;
    
    ui.status.innerHTML = "";
    
    const spinner = document.createElement("span");
    spinner.className = "spinner";
    spinner.setAttribute("aria-hidden", "true");
    
    const text = document.createElement("span");
    text.textContent = message || "";
    
    ui.status.appendChild(spinner);
    ui.status.appendChild(text);
  };

  /**
   * Set phase tag with data attribute for styling.
   * @param {string} phase
   */
  const setPhaseTag = (phase) => {
    if (!ui.tags) return;

    const label = PHASE_LABELS[phase] || phase || "starting";
    ui.tags.textContent = label;
    ui.tags.setAttribute("data-phase", phase || "starting");
  };

  // =========================
  // Progress Bar
  // =========================

  /**
   * Set progress percentage.
   * @param {number} p
   */
  const setPercent = (p) => {
    const percent = Math.max(0, Math.min(100, Number.isFinite(p) ? p : 0));

    if (ui.barInner) {
      ui.barInner.style.width = `${percent}%`;
      
      // Mark as complete for styling
      if (percent >= 100) {
        ui.barInner.setAttribute("data-complete", "true");
      } else {
        ui.barInner.removeAttribute("data-complete");
      }
    }

    if (ui.percentText) {
      ui.percentText.textContent = `${percent.toFixed(0)}%`;
    }

    if (ui.progressBar) {
      ui.progressBar.setAttribute("aria-valuenow", String(Math.round(percent)));
    }
  };

  // =========================
  // Logging System
  // =========================

  /**
   * Append a log entry.
   * @param {string} line
   * @param {keyof typeof LOG_LEVELS} [level="info"]
   */
  const appendLog = (line, level = LOG_LEVELS.INFO) => {
    if (!ui.details) return;

    // Clear placeholder text on first real log
    const emptyState = ui.details.querySelector(".empty-state");
    if (emptyState) {
      emptyState.remove();
    }

    const timestamp = getTimestamp();
    const entry = `[${timestamp}] ${line}`;
    
    // Store in history
    state.logHistory.push(entry);
    if (state.logHistory.length > CONFIG.MAX_LOG_ENTRIES) {
      state.logHistory.shift();
    }

    // Create log entry element
    const div = document.createElement("div");
    div.className = `log-entry log-${level}`;
    
    const timestampSpan = document.createElement("span");
    timestampSpan.className = "log-timestamp";
    timestampSpan.textContent = `[${timestamp}]`;
    
    div.appendChild(timestampSpan);
    div.appendChild(document.createTextNode(` ${line}`));
    
    ui.details.appendChild(div);

    // Keep DOM nodes limited
    while (ui.details.children.length > CONFIG.MAX_LOG_ENTRIES) {
      ui.details.removeChild(ui.details.firstChild);
    }

    // Auto-scroll to bottom
    ui.details.scrollTop = ui.details.scrollHeight;
  };

  /**
   * Clear all log entries.
   */
  const clearLogs = () => {
    if (!ui.details) return;
    
    ui.details.innerHTML = "";
    state.logHistory = [];
    
    // Add empty state back
    const emptyState = document.createElement("div");
    emptyState.className = "empty-state";
    emptyState.textContent = "Log cleared";
    ui.details.appendChild(emptyState);
    
    showToast("Log cleared", "info");
  };

  /**
   * Copy log content to clipboard.
   */
  const copyLogs = async () => {
    if (state.logHistory.length === 0) {
      showToast("No logs to copy", "warning");
      return;
    }

    const content = [
      `Gmail Cleaner Progress Log`,
      `Generated: ${new Date().toISOString()}`,
      `Gmail Tab ID: ${gmailTabId || "unknown"}`,
      `---`,
      ...state.logHistory
    ].join("\n");

    try {
      await navigator.clipboard.writeText(content);
      showToast("Log copied to clipboard", "success");
    } catch {
      // Fallback for older browsers
      const textarea = document.createElement("textarea");
      textarea.value = content;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      
      try {
        document.execCommand("copy");
        showToast("Log copied to clipboard", "success");
      } catch {
        showToast("Failed to copy log", "error");
      }
      
      document.body.removeChild(textarea);
    }
  };

  // =========================
  // Summary & Stats
  // =========================

  /**
   * Render stats summary pills.
   * @param {Object} stats
   */
  const renderStatsSummary = (stats) => {
    if (!ui.summary) return;
    ui.summary.innerHTML = "";

    if (!stats) return;

    const mode = stats.mode === "dry" ? "dry" : "live";
    state.mode = mode;

    /** @type {Array<[string, string]>} */
    const chips = [];

    if (mode === "dry") {
      chips.push(["Mode", "Dry-run"]);

      const wouldCleanTotal = (stats.totalWouldDelete || 0) + (stats.totalWouldArchive || 0);
      if (wouldCleanTotal > 0) {
        chips.push(["Would clean", formatNumber(wouldCleanTotal)]);
      }
    } else {
      chips.push(["Mode", "Live"]);

      const cleanedTotal = (stats.totalDeleted || 0) + (stats.totalArchived || 0);
      if (cleanedTotal > 0) {
        chips.push(["Cleaned", formatNumber(cleanedTotal)]);
      }
    }

    if (typeof stats.totalQueries === "number") {
      chips.push(["Queries", formatNumber(stats.totalQueries)]);
    }

    // Add duration if available
    const duration = Date.now() - state.startTime;
    if (duration > 1000) {
      chips.push(["Duration", formatDuration(duration)]);
    }

    for (const [label, value] of chips) {
      const pill = document.createElement("span");
      pill.className = "pill";
      pill.innerHTML = `${escapeHtml(label)}: <strong>${escapeHtml(value)}</strong>`;
      ui.summary.appendChild(pill);
    }
  };

  /**
   * Render the per-query results table.
   */
  const renderRowsTable = () => {
    if (!ui.table || !tbody) return;

    if (state.rows.length === 0) {
      ui.table.style.display = "none";
      tbody.innerHTML = "";
      return;
    }

    ui.table.style.display = "table";
    tbody.innerHTML = "";

    const fragment = document.createDocumentFragment();

    for (const row of state.rows) {
      const tr = document.createElement("tr");

      // Query/Label
      const tdQuery = document.createElement("td");
      tdQuery.textContent = row.label || row.query || "(unknown)";
      tdQuery.title = row.query || "";
      tr.appendChild(tdQuery);

      // Mode
      const tdMode = document.createElement("td");
      const modeTag = document.createElement("span");
      modeTag.className = row.mode === "dry" ? "tag tag-info" : "tag tag-success";
      modeTag.textContent = row.mode === "dry" ? "Dry-run" : "Live";
      tdMode.appendChild(modeTag);
      tr.appendChild(tdMode);

      // Count
      const tdCount = document.createElement("td");
      tdCount.className = "mono";
      tdCount.textContent = formatNumber(row.count || 0);
      tr.appendChild(tdCount);

      // Duration
      const tdDuration = document.createElement("td");
      tdDuration.className = "mono";
      tdDuration.textContent = formatDuration(row.durationMs);
      tr.appendChild(tdDuration);

      fragment.appendChild(tr);
    }

    tbody.appendChild(fragment);
  };

  /**
   * Maybe show the tip prompt based on stats.
   * @param {Object} stats
   */
  const maybeShowTipPrompt = (stats) => {
    if (!ui.tipPrompt || state.tipShown) return;
    if (!stats) return;

    const mode = stats.mode === "dry" ? "dry" : "live";
    if (mode !== "live") return;

    const cleanedTotal = (stats.totalDeleted || 0) + (stats.totalArchived || 0);
    if (cleanedTotal < CONFIG.TIP_THRESHOLD_COUNT) return;

    ui.tipPrompt.style.display = "block";
    state.tipShown = true;
  };

  // =========================
  // Button State Management
  // =========================

  /**
   * Set button loading state.
   * @param {HTMLButtonElement | null} btn
   * @param {boolean} loading
   * @param {string} [loadingText]
   */
  const setButtonLoading = (btn, loading, loadingText) => {
    if (!btn) return;

    btn.disabled = loading;

    if (loading) {
      btn.classList.add("loading");
      btn.setAttribute("aria-busy", "true");
      if (loadingText) {
        btn.dataset.originalText = btn.textContent || "";
        btn.textContent = loadingText;
      }
    } else {
      btn.classList.remove("loading");
      btn.removeAttribute("aria-busy");
      if (btn.dataset.originalText) {
        btn.textContent = btn.dataset.originalText;
        delete btn.dataset.originalText;
      }
    }
  };

  /**
   * Update button state for done phase.
   * @param {string} phase
   */
  const updateButtonsForDone = (phase) => {
    if (ui.cancel) {
      ui.cancel.disabled = true;
      ui.cancel.classList.remove("loading");
      
      switch (phase) {
        case PHASES.CANCELLED:
          ui.cancel.textContent = "Run cancelled";
          break;
        case PHASES.ERROR:
          ui.cancel.textContent = "Run ended with error";
          break;
        default:
          ui.cancel.textContent = "Run finished";
      }
    }

    if (ui.reconnect) ui.reconnect.disabled = true;
    if (ui.reinject) ui.reinject.disabled = true;
  };

  // =========================
  // Review Modal (v2.0)
  // =========================

  /**
   * Open the review modal.
   * @param {string} label
   * @param {number | string} count
   * @param {string} query
   */
  const openReviewModal = (label, count, query) => {
    if (!ui.reviewModal) return;

    if (ui.modalCount) {
      ui.modalCount.textContent = typeof count === "number" 
        ? formatNumber(count) 
        : String(count || "many");
    }
    
    if (ui.modalQuery) {
      ui.modalQuery.textContent = label || query || "";
    }

    try {
      ui.reviewModal.showModal();
    } catch (err) {
      log("error", "Failed to show review modal:", err);
    }
  };

  /**
   * Close the review modal.
   */
  const closeReviewModal = () => {
    if (!ui.reviewModal) return;
    
    try {
      ui.reviewModal.close();
    } catch {
      // Ignore close errors
    }
  };

  /**
   * Send review signal to content script.
   * @param {"resume" | "skip"} signal
   */
  const sendReviewSignal = async (signal) => {
    if (!gmailTabId) {
      appendLog("Cannot send review signal: Gmail tab ID missing", LOG_LEVELS.ERROR);
      return;
    }

    try {
      const type = signal === "resume" ? "gmailCleanerResume" : "gmailCleanerSkip";
      await chrome.tabs.sendMessage(gmailTabId, { type });
      
      appendLog(`Review decision: ${signal.toUpperCase()}`, LOG_LEVELS.SUCCESS);
      setPhaseTag(PHASES.QUERY);
      setStatusLoading("Continuing cleanup...");
      
    } catch (err) {
      log("error", "Failed to send review signal:", err);
      appendLog(`Error sending review signal: ${err?.message || err}`, LOG_LEVELS.ERROR);
      showToast("Failed to send review signal", "error");
    }
  };

  // =========================
  // Storage Operations
  // =========================

  /**
   * Save final stats to storage.
   * @param {Object} stats
   */
  const saveStatsToStorage = async (stats) => {
    if (!hasChromeStorage("sync")) return;

    try {
      const finishedAt = Date.now();
      const statsToSave = { ...stats, finishedAt };
      
      await new Promise((resolve) => {
        chrome.storage.sync.set({ lastRunStats: statsToSave }, resolve);
      });
    } catch (err) {
      log("warn", "Failed to save stats to storage:", err);
    }
  };

  /**
   * Get last config from storage.
   * @returns {Promise<Object | null>}
   */
  const getLastConfig = async () => {
    // Try session storage first
    if (hasChromeStorage("session")) {
      try {
        const result = await new Promise((resolve) => {
          chrome.storage.session.get("lastConfig", resolve);
        });
        if (result?.lastConfig) return result.lastConfig;
      } catch {
        // Fall through
      }
    }

    // Fall back to local storage
    if (hasChromeStorage("local")) {
      try {
        const result = await new Promise((resolve) => {
          chrome.storage.local.get("lastConfig", resolve);
        });
        return result?.lastConfig || null;
      } catch {
        // Ignore
      }
    }

    return null;
  };

  // =========================
  // Done Handler
  // =========================

  /**
   * Handle completion of the cleanup run.
   * @param {Object} msg
   */
  const handleDone = (msg) => {
    state.done = true;
    const phase = msg.phase || PHASES.DONE;

    setPhaseTag(phase);
    setPercent(msg.percent ?? 100);
    updateButtonsForDone(phase);

    if (msg.stats && phase === PHASES.DONE) {
      renderStatsSummary(msg.stats);
      maybeShowTipPrompt(msg.stats);
      saveStatsToStorage(msg.stats);
    } else if (msg.stats) {
      renderStatsSummary(msg.stats);
    }

    const summary = msg.detail || "All queries processed.";
    appendLog(`Run finished: ${summary}`, LOG_LEVELS.SUCCESS);

    // Show appropriate toast
    if (phase === PHASES.DONE) {
      showToast("Cleanup completed!", "success");
    } else if (phase === PHASES.CANCELLED) {
      showToast("Cleanup cancelled", "warning");
    } else if (phase === PHASES.ERROR) {
      showToast("Cleanup ended with error", "error");
    }
  };

  // =========================
  // Message Handler
  // =========================

  /**
   * Handle incoming progress messages.
   * @param {Object} message
   */
  const handleProgressMessage = (message) => {
    if (!message) return;

    // Handle Review Request (v2.0)
    if (message.type === "gmailCleanerRequestReview") {
      appendLog(`Review requested for: ${message.label}`, LOG_LEVELS.INFO);
      setPhaseTag(PHASES.REVIEW);
      setStatus("Waiting for user review...");
      openReviewModal(message.label, message.count, message.query);
      return;
    }

    if (message.type !== "gmailCleanerProgress") return;

    const { phase, status, detail, percent, stats } = message;

    // Update status
    if (status) {
      if (phase === PHASES.QUERY || phase === PHASES.TAG) {
        setStatusLoading(status);
      } else {
        setStatus(status);
      }
      appendLog(status + (detail ? ` — ${detail}` : ""), LOG_LEVELS.INFO);
    } else if (detail) {
      appendLog(detail, LOG_LEVELS.INFO);
    }

    // Update progress
    if (typeof percent === "number") {
      setPercent(percent);
    }

    // Update phase
    if (phase) {
      state.lastPhase = phase;
      setPhaseTag(phase);
    }

    // Handle query completion
    if (phase === PHASES.QUERY_DONE) {
      const row = {
        query: message.query || "",
        label: message.label || "",
        count: message.count || 0,
        mode: message.mode || stats?.mode || state.mode || "live",
        durationMs: message.durationMs ?? null
      };
      state.rows.push(row);
      renderRowsTable();
    }

    // Update stats summary
    if (stats) {
      renderStatsSummary(stats);
    }

    // Handle completion states
    if (message.done || phase === PHASES.DONE || phase === PHASES.CANCELLED || phase === PHASES.ERROR) {
      handleDone(message);
    }

    // Log errors
    if (phase === PHASES.ERROR) {
      if (ui.cancel) ui.cancel.disabled = true;
      appendLog(`Error details: ${detail || "unknown error"}`, LOG_LEVELS.ERROR);
    }

    // Log cancellation
    if (phase === PHASES.CANCELLED) {
      appendLog("Run cancelled by user.", LOG_LEVELS.WARNING);
    }
  };

  // =========================
  // Button Handlers
  // =========================

  /**
   * Handle cancel button click.
   */
  const handleCancel = async () => {
    if (!gmailTabId) {
      appendLog("Cannot cancel: Gmail tab ID missing.", LOG_LEVELS.ERROR);
      showToast("Cannot cancel: no tab ID", "error");
      return;
    }

    setButtonLoading(ui.cancel, true, "Cancelling…");
    appendLog("Sending cancel signal...", LOG_LEVELS.INFO);

    try {
      await chrome.tabs.sendMessage(gmailTabId, { type: "gmailCleanerCancel" });
      appendLog(`Cancel signal sent to Gmail tab ${gmailTabId}.`, LOG_LEVELS.SUCCESS);
      showToast("Cancel signal sent", "info");
    } catch (err) {
      log("error", "Failed to send cancel message:", err);
      appendLog(`Failed to send cancel message: ${err?.message || err}`, LOG_LEVELS.ERROR);
      showToast("Failed to cancel", "error");
      setButtonLoading(ui.cancel, false);
    }
  };

  /**
   * Handle reconnect button click.
   */
  const handleReconnect = async () => {
    if (!gmailTabId) {
      appendLog("Cannot reconnect: Gmail tab ID missing.", LOG_LEVELS.ERROR);
      showToast("Cannot reconnect: no tab ID", "error");
      return;
    }

    if (state.isReconnecting) return;
    state.isReconnecting = true;

    setButtonLoading(ui.reconnect, true, "Reconnecting…");
    appendLog("Pinging Gmail content script…", LOG_LEVELS.INFO);

    try {
      const response = await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error("Reconnect timeout"));
        }, CONFIG.RECONNECT_TIMEOUT_MS);

        chrome.tabs.sendMessage(
          gmailTabId,
          { type: "gmailCleanerPing" },
          (resp) => {
            clearTimeout(timeout);
            
            const lastErr = chrome.runtime.lastError;
            if (lastErr) {
              reject(new Error(lastErr.message));
              return;
            }
            
            resolve(resp);
          }
        );
      });

      if (!response?.ok) {
        appendLog("Reconnect: script responded but not ok.", LOG_LEVELS.WARNING);
        setStatus("Reconnect: script responded but not ok.");
        showToast("Reconnect partial success", "warning");
      } else {
        appendLog(`Reconnect OK. Phase: ${response.phase || "unknown"}`, LOG_LEVELS.SUCCESS);
        setStatus("Reconnected to Gmail tab.");
        showToast("Reconnected successfully", "success");
      }
    } catch (err) {
      log("error", "Reconnect error:", err);
      appendLog(`Reconnect failed: ${err?.message || err}`, LOG_LEVELS.ERROR);
      setStatus("Reconnect failed. Try Re-inject.");
      showToast("Reconnect failed", "error");
    } finally {
      setButtonLoading(ui.reconnect, false);
      state.isReconnecting = false;
    }
  };

  /**
   * Handle re-inject button click.
   */
  const handleReinject = async () => {
    if (!gmailTabId) {
      appendLog("Cannot re-inject: Gmail tab ID missing.", LOG_LEVELS.ERROR);
      showToast("Cannot re-inject: no tab ID", "error");
      return;
    }

    setButtonLoading(ui.reinject, true, "Re-injecting…");
    appendLog("Re-injecting cleaner into Gmail tab…", LOG_LEVELS.INFO);
    setStatusLoading("Re-injecting cleaner into Gmail tab…");

    try {
      // Try to get last config
      const cfg = await getLastConfig();

      // Inject config if available
      if (cfg) {
        await chrome.scripting.executeScript({
          target: { tabId: gmailTabId },
          func: (config) => {
            window.GMAIL_CLEANER_CONFIG = config || window.GMAIL_CLEANER_CONFIG || {};
          },
          args: [cfg]
        });
      }

      // Inject content script
      await chrome.scripting.executeScript({
        target: { tabId: gmailTabId },
        files: ["contentScript.js"]
      });

      appendLog("Re-injected content script into Gmail tab.", LOG_LEVELS.SUCCESS);
      setStatus("Cleaner re-injected. It should resume sending progress shortly.");
      showToast("Content script re-injected", "success");
    } catch (err) {
      log("error", "Re-inject error:", err);
      appendLog(`Re-inject error: ${err?.message || err}`, LOG_LEVELS.ERROR);
      setStatus("Re-inject failed. You can close this and start a new run from the popup.");
      showToast("Re-inject failed", "error");
    } finally {
      setButtonLoading(ui.reinject, false);
    }
  };

  /**
   * Handle toggle logs button click.
   */
  const handleToggleLogs = () => {
    if (!ui.details) return;

    state.logsExpanded = !state.logsExpanded;

    if (state.logsExpanded) {
      ui.details.style.maxHeight = "none";
      ui.details.style.overflowY = "visible";
      if (ui.toggleLogs) {
        ui.toggleLogs.textContent = "Collapse";
        ui.toggleLogs.setAttribute("aria-pressed", "true");
      }
    } else {
      ui.details.style.maxHeight = "240px";
      ui.details.style.overflowY = "auto";
      if (ui.toggleLogs) {
        ui.toggleLogs.textContent = "Logs";
        ui.toggleLogs.setAttribute("aria-pressed", "false");
      }
    }
  };

  // =========================
  // Keyboard Shortcuts
  // =========================

  /**
   * Set up keyboard shortcuts.
   */
  const setupKeyboardShortcuts = () => {
    document.addEventListener("keydown", (e) => {
      // Escape to cancel
      if (e.key === "Escape") {
        if (ui.reviewModal?.open) {
          closeReviewModal();
          sendReviewSignal("skip");
        } else if (!state.done && ui.cancel && !ui.cancel.disabled) {
          handleCancel();
        }
      }

      // Ctrl/Cmd + C to copy logs
      if ((e.ctrlKey || e.metaKey) && e.key === "c" && !window.getSelection()?.toString()) {
        // Only if no text is selected
        e.preventDefault();
        copyLogs();
      }

      // Enter to proceed in review modal
      if (e.key === "Enter" && ui.reviewModal?.open) {
        e.preventDefault();
        closeReviewModal();
        sendReviewSignal("resume");
      }
    });
  };

  // =========================
  // Event Listeners
  // =========================

  /**
   * Wire up all event listeners.
   */
  const wireEventListeners = () => {
    // Control buttons
    ui.cancel?.addEventListener("click", handleCancel);
    ui.reconnect?.addEventListener("click", handleReconnect);
    ui.reinject?.addEventListener("click", handleReinject);
    ui.toggleLogs?.addEventListener("click", handleToggleLogs);

    // Log actions
    ui.copyLogsBtn?.addEventListener("click", copyLogs);
    ui.clearLogsBtn?.addEventListener("click", clearLogs);

    // Review modal buttons
    ui.modalProceedBtn?.addEventListener("click", () => {
      closeReviewModal();
      sendReviewSignal("resume");
    });

    ui.modalSkipBtn?.addEventListener("click", () => {
      closeReviewModal();
      sendReviewSignal("skip");
    });

    // Close modal on backdrop click
    ui.reviewModal?.addEventListener("click", (e) => {
      if (e.target === ui.reviewModal) {
        closeReviewModal();
        sendReviewSignal("skip");
      }
    });

    // Keyboard shortcuts
    setupKeyboardShortcuts();

    // Listen for progress messages
    if (hasChromeRuntime() && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener((msg) => {
        try {
          handleProgressMessage(msg);
        } catch (err) {
          log("error", "Error handling progress message:", err);
        }
      });
    }
  };

  // =========================
  // Initialization
  // =========================

  /**
   * Initialize the progress page.
   */
  const init = () => {
    log("info", `Progress page v${PROGRESS_VERSION} initializing...`);

    if (!gmailTabId) {
      setStatus("Could not read Gmail tab ID from URL. You can close this and try again.");
      appendLog("Missing or invalid gmailTabId in query string.", LOG_LEVELS.ERROR);
      
      if (ui.cancel) ui.cancel.disabled = true;
      if (ui.reconnect) ui.reconnect.disabled = true;
      if (ui.reinject) ui.reinject.disabled = true;
      
      return;
    }

    setStatusLoading(`Waiting for cleaner in Gmail tab ${gmailTabId} to send progress…`);
    appendLog(`Connected to Gmail tab ${gmailTabId}`, LOG_LEVELS.INFO);

    wireEventListeners();

    log("info", "Progress page ready.");
  };

  // Run initialization when DOM is ready
  if (document.readyState === "loading") {
    window.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();