# Security Policy – Gmail One-Click Cleaner

Gmail One-Click Cleaner is a Chrome extension that automates safe Gmail searches and bulk deletes. It **never** exfiltrates email contents, attachments, or credentials.

This document explains what the extension can access, what data leaves your browser, and how to report issues.

---

## Supported Versions

I aim to support the latest published version in the Chrome Web Store:

| Version | Status | Description |
| :--- | :--- | :--- |
| **3.0.x (Stable)** | :white_check_mark: Supported | Latest Web Store release (recommended) |
| **Dev / Unpacked** | :warning: Best-effort | Current GitHub or local “Load unpacked” build |

If you find a security issue in an older version, please confirm it still exists in the latest Stable or Dev build before reporting.

---

## Permissions & Data Access

Gmail One-Click Cleaner requests only the permissions needed to automate Gmail cleanup:

### Chrome permissions

- `activeTab`
  - Lets the extension act on the tab you clicked it from (usually Gmail).

- `tabs`
  - Lets the popup find an appropriate Gmail tab, open the progress page, and optionally open support links.

- `scripting`
  - Injects the cleanup content script and small diagnostic snippets into your Gmail tab.

- `storage`
  - Saves your rule sets, last-used settings, history, and small UI preferences.

### Host permissions

- `https://mail.google.com/*`
  - Required to read the Gmail UI (DOM) and trigger built-in Gmail actions (search, select, delete).

- `https://gmail-one-click-cleaner.vercel.app/*`
  - Used **only** for future Pro license checks.
  - Current public releases may include UI for Pro, but the backend and activation flow may not be fully live yet. License checks involve only the license key and basic license metadata, *not* Gmail data.

---

## What the extension does with Gmail

Inside Gmail, the extension:

- Reads and manipulates **page structure (DOM)** to:
  - Type search queries into Gmail’s search box
  - Click built-in buttons (search, select-all, delete, archive, label)
  - Detect whether a search has results, and how many are selected

- Uses **Gmail’s own search syntax** (e.g. `category:promotions older_than:6m`) to find low-value mail.

- **Applies Safety Filters (Local Logic):**
  - **Whitelist:** If you configure a Global Whitelist, the extension locally appends `-from:email` to every search query before running it.
  - **Review Mode:** If enabled, the extension pauses execution after a search and waits for a user signal (via the Progress UI) before selecting or deleting anything.

- Uses **Gmail’s own controls** to:
  - Select conversations
  - Apply labels like `GmailCleaner - Promotions` (optional, before delete)
  - Move selected conversations to **Trash** or **All Mail** (Archive)

It does **not**:

- Read or transmit raw email bodies or attachment contents
- Bypass Gmail’s permission model or authentication
- Store or transmit your Google credentials

All cleanup automation runs locally in your browser, against the Gmail UI, using standard Gmail actions.

---

## What data is stored locally

The extension stores small configuration values using `chrome.storage`:

- **Sync Storage** (Syncs across your Chrome instances):
  - Cleanup intensity (`light`, `normal`, `deep`)
  - Custom Rule sets
  - **Global Whitelist:** List of emails/domains to protect.
  - Preferences: Debug Mode, Pro status (if applicable).

- **Local Storage** (Device only):
  - `lastConfig`: Remembers popup toggles (Dry Run, Review Mode, etc.).
  - `runHistory`: A log of your last 10 runs (Date, Mode, Count, Queries). This data is used for the Diagnostics history table and never leaves the device.

No email content, email subjects, attachment contents, or Gmail message bodies are stored or sent anywhere.

---

## Network calls

Current versions only make external network calls in **two places**:

1. **Pro license activation (future / optional)**
   - Endpoint: `https://gmail-one-click-cleaner.vercel.app/api/check-license`
   - Payload: license key (and possibly basic metadata like extension version)
   - Response: whether the license is valid, email tied to the license, and limited license metadata
   - No Gmail messages, labels, or search results are sent.

2. **User-initiated links**
   - Example: clicking support links, diagnostics info, Cash App tip link, or a future docs/GitHub link.
   - These are normal browser navigations you trigger (new tab with the target URL).

Outside of that, the extension does not phone home, use analytics trackers, or send Gmail data off-device.

---

## Diagnostics & Debugging

A dedicated Diagnostics page is included to help debug issues:

- Lists open Gmail tabs (tab ID, window ID, URL truncated)
- Shows which Gmail tab the popup will pick
- Shows environment info (browser, platform, extension version, requested permissions)
- Shows **Cleanup History** (read locally from `chrome.storage.local`)
- Has a **Test inject** button:
  - Injects a tiny console-logging function into the chosen Gmail tab
  - Logs the current URL and timestamp in that tab’s console

Diagnostics are meant for debugging **selector issues, tab selection, and script injection problems**. They do not read or send email content.

---

## How to Report a Vulnerability

If you believe you’ve found a security or privacy issue (for example, unexpected data access, a way to run arbitrary code, or permission misuse):

1. **Do not** post full details publicly (Chrome reviews, Reddit, etc.).
2. Collect:
   - Extension version (from `chrome://extensions` or the Web Store)
   - Browser + version (e.g. “Chrome 130.0.x”, “Brave 1.xx”)
   - OS (e.g. Windows 11, macOS 15, Ubuntu 24.04)
   - Exact, step-by-step reproduction instructions
   - Any relevant screenshots or console logs (sanitized of personal data)

3. Report via one of:
   - **GitHub Issues:** Open an issue and mark it clearly as **[Security]** in the title with a high-level, non-sensitive summary.
   - **Chrome Web Store support tab:** Include “Security issue” in the subject and summarize the behavior.

If extra sensitive details are needed, you can offer to share them privately after initial triage.

---

## Responsible Disclosure

Please give a reasonable amount of time to investigate and fix the issue before disclosing it publicly.

In general:

- I’ll try to acknowledge security-relevant reports quickly.
- For serious issues, I’ll prioritize a fix and push a new version to the Web Store.
- Changelogs and release notes may reference **“security hardening”** or **“fixes”** without disclosing full exploit details until most users have updated.

---

## Hardening Suggestions & Feedback

If you have ideas to make Gmail One-Click Cleaner safer (better default rules, reduced permissions, sandboxing ideas, threat scenarios, etc.):

- Open a GitHub issue labeled **“enhancement”** or **“security hardening”**.
- Or use the **Chrome Web Store support** channel with a short proposal.

Thanks for helping keep users safe.