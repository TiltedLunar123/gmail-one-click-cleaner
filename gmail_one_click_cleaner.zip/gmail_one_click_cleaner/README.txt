Gmail One-Click Cleaner (Chrome Extension)
=========================================

What it does
------------
This simple Chrome extension lets you open Gmail, click one button, and run
a handful of bulk-cleanup rules:

- Delete big attachments (10MB+ or 5MB+ older than 1 year)
- Delete old Promotions (older than 6 months)
- Delete old Social emails (older than 6 months)
- Delete old no-reply style emails (older than 6 months)

It works by:
- Opening each search inside Gmail
- Clicking the master checkbox
- Clicking "Select all conversations that match this search" (if shown)
- Clicking the Delete button

How to install
--------------
1. Download the `gmail_one_click_cleaner.zip` file and unzip it somewhere.
2. In Chrome, go to: chrome://extensions
3. Turn on "Developer mode" in the top-right.
4. Click "Load unpacked" and select the unzipped folder.
5. Pin the extension if you want quick access.

How to use
----------
1. Open Gmail in a tab (mail.google.com).
2. Click the "Gmail One-Click Cleaner" extension icon.
3. In the popup, click "Run cleanup".
4. Confirm the warning popup in Gmail.
5. Wait while it cycles through a few searches and deletes matches.

Notes / warnings
----------------
- This is "best effort" and depends on Gmail's current layout (ARIA labels).
  If Google changes the UI, some clicks may stop working and you'll need
  to tweak selectors in `contentScript.js`.
- Deleted messages go to Trash; Gmail typically empties Trash automatically
  after 30 days, but you can restore from Trash in the meantime.
- The queries are hard-coded in `CLEANUP_QUERIES` inside `contentScript.js`.
  Feel free to edit them to be more or less aggressive.

Use at your own risk. Always make sure you understand what is being deleted.