# Changelog – Gmail One-Click Cleaner

All notable changes to this project will be documented in this file.
This log tracks user-visible behavior, UI changes, and important internal fixes.

## 3.0.0

- **Major Feature: Review Mode**
  - Added a "Review matches before action" toggle. When enabled, the cleaner pauses after finding results for a rule, allowing you to see exactly what will be deleted and choose to **Proceed** or **Skip** that specific query before any action is taken.

- **Major Feature: Global Whitelist**
  - Introduced a global exclusion list. You can now specify email addresses (e.g., family or work VIPs) that are automatically excluded from *all* rules, ensuring they are never archived or deleted.

- **Cleanup History**
  - The Diagnostics page now tracks your last 10 runs locally. You can review past performance, including the date, mode (Dry Run vs Live), Archive vs Delete setting, and total conversations affected.

- **Core Improvements**
  - Updated the automation engine to support interactive "Pause/Resume" signals for Review Mode.
  - Migrated run stats storage to `chrome.storage.local` to support history tracking without hitting sync limits.

## 2.10.5

- Stability + clarity patch focused on safer runs and more honest feedback:
  - Added a soft cap on how many conversations a single run will act on, with a confirmation step before continuing on very large inboxes.
  - Improved handling of empty or failed Gmail searches so runs end with clear “nothing matched” or “search failed” messages instead of looking like a silent success.

- More accurate progress and end-of-run reporting:
  - Progress bar now reflects the number of conversations matched at the start of the run, not just rough batches.
  - Tracked counts for “checked”, “labeled / archived”, and “skipped” threads and surfaced them in the end-of-run summary.
  - Dry Run now ends with a “would have affected” summary so you can see what a real run would do without touching your inbox.

- Better safety and recovery behavior:
  - Hardened the content script boot sequence to avoid duplicate injection and to fail visibly if Gmail isn’t ready.
  - Ensured runs cannot stay stuck in a “Running” state after errors, and that cancel / stop exits cleanly.

- Optional Debug mode for advanced users:
  - New toggle in settings that logs key events (start, batches, errors) with a consistent prefix in the browser console.
  - Designed for bug reports and troubleshooting without changing how the cleaner itself behaves.

> Note: 2.10.1–2.10.4 were internal / pre-release iterations. Their changes are folded into the 2.10.5 notes above.

## 2.10.0

- Added new safety guardrails and a non-destructive mode option:
  - You can now choose to **archive** matching conversations instead of deleting them for extra-safe first runs.
  - New global guardrail can skip **starred** and **Important** threads so they’re never touched by bulk cleanups.
  - Added a “minimum age” dropdown so rule sets only act on mail older than 3, 6, or 12 months, even if a rule is looser.

- Improved rule editing and testing on the Options page:
  - Each rule set now includes a quick “open in Gmail” test action so you can preview what a query will match before running a cleanup.
  - Clarified copy around what Light / Normal / Deep target and how Safe Mode further narrows the rules.

- Internal configuration cleanup:
  - Plumbed the new guardrail settings through popup → Gmail tab → content script so everything stays in sync.
  - Kept all behavior **local-only** with no external servers required for these new features.

## 2.9.8

- Fixed issues when running in Brave and multi-Gmail setups:
  - Improved detection of the “active” Gmail tab so cleanup runs against the right account.
  - Reduced dependence on the extension docs / options tab being in focus.
- Hardened content script messaging and reconnection behavior when Gmail reloads mid-run.
- Small polish to the Progress window layout and copy.
- Internal refactors to keep progress logic, rule sets, and UI wiring in sync.

## 2.9.7

- Added a richer Progress window:
  - Live percent complete and current phase text.
  - A summary table with per-query counts and durations.
  - “Tags” area for showing current rule labels / hints.
- Added **Reconnect** and **Re-inject** buttons to recover from:
  - Gmail reloads
  - Lost content script connections
- Improved Cancel behavior:
  - Cancels the current phase cleanly.
  - Closes the progress session without leaving partial state.

## 2.9.6

- Introduced the **Tip / Support panel** in the Progress window:
  - Optional section explaining how to support the project (e.g. small tips).
  - Does not affect privacy or Gmail behavior.
- Tuned the Progress UI styling:
  - Darker background, softer card edges, and more readable text.
  - Better spacing on small windows.

## 2.9.5

- Added optional “tag before trash” behavior in the cleanup flow:
  - Before deleting, messages can be tagged with a dedicated Gmail label.
  - This makes it easier to search the Trash by that label and verify results.
- Internal changes to how rule metadata is passed from options → progress page.
- Minor logging clean-up and more defensive checks for missing DOM elements.

## 2.9.4

- Expanded the **cleanup rule system**:
  - Introduced three intensities: **Light**, **Normal**, **Aggressive**.
  - Each intensity uses its own array of safe Gmail queries (large attachments, promos, social, newsletters, etc.).
- Synced default rules between the options page and the run logic using a shared `DEFAULT_RULES` object.
- Adjusted some default queries to be safer:
  - Slightly older date thresholds for aggressive modes.
  - Clearer focus on bulk, low-value categories.

## 2.9.3

- New Progress window UI (HTML/CSS refresh):
  - Card-based layout with a single clear progress bar.
  - Status line, details text, and compact controls.
- Better error reporting when:
  - No Gmail tab is found.
  - The content script fails to attach.
- Slight performance improvements in how the extension advances between queries.

## 2.9.2

- Improved options page:
  - Cleaner descriptions of each rule set.
  - Safer defaults for new users.
- More robust handling of local storage:
  - Defaults are applied if settings are missing or invalid.
- Reduced redundant messages between popup → background → content scripts.

## 2.9.1

- Added **Safe Mode** toggle:
  - Runs only the safest, least risky rule subset.
  - Skips any “heavier” queries that might get too close to long-term history.
- Improved **Dry Run** behavior:
  - Ensures no destructive actions are taken when Dry Run is on.
  - Still drives the UI and progress screen so users can see what would happen.

## 2.9.0

- Major internal refactor of the run logic:
  - Centralized state management for phases, counts, and errors.
  - Clear separation between “rules” and “execution engine”.
- Better handling of Gmail rate limits and slower accounts:
  - Slight randomized delays between operations.
  - Reduced chance of hitting hard limits during long runs.

---

## 2.8.x

- Added support for more Gmail categories (Updates, Forums) in some rule sets.
- Tuned large-attachment filters (e.g. `larger:20M`, `has:attachment larger:10M older_than:6m`).
- Fixed occasional issues where “Select all conversations” was not clicked properly on some layouts.
- First iteration of the dark theme for the progress window.

---

## 2.7.x

- Introduced **Dry Run** mode for the first time:
  - Simulates the run without deleting messages.
  - Helpful for sanity-checking rules on big, old inboxes.
- Added basic error banners when Gmail layout does not match expected selectors.
- Minor UI cleanup on popup text and buttons.

---

## 2.6.x

- Improved handling when multiple Gmail accounts are open in the same browser session.
- Early support for non-Chrome Chromium browsers (Brave, Edge, etc.).
- Small optimizations to reduce flicker when switching between search queries.

---

## 2.5.x

- More robust detection of key Gmail buttons (search results, select-all, delete).
- Reduced chances of running with Gmail still loading or partially rendered.
- Light performance tweaks and code organization.

---

## 2.0.0 – MV3 Rewrite

- Migrated the extension to **Manifest V3**.
- Re-architected the extension around:
  - A service worker background script.
  - `chrome.scripting` for injecting the Gmail automation.
  - A dedicated Progress page to show run status.
- Added configurable options for future rule tuning.

---

## 1.x – Initial Releases

- First public release of **Gmail One-Click Cleaner**.
- Core feature:
  - Run a sequence of Gmail searches targeting bulk clutter:
    - Promotions
    - Social
    - Newsletters / marketing
    - Large attachments
  - Select all results and delete in bulk.
- Basic popup UI with a single **Run cleanup** button.
- Simple, local-only behavior with no external servers.