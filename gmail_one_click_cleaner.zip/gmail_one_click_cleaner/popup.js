document.addEventListener("DOMContentLoaded", () => {
  "use strict";

  const $ = (id) => document.getElementById(id);

  // Main Controls
  const runBtn = $("runCleanup");
  const statusEl = $("status");
  const intensityEl = $("intensity");
  const actionTypeEl = $("actionType"); // New: Trash vs Archive
  const minAgeEl = $("minAge");         // New: Time guardrail
  
  // Toggles
  const dryRunEl = $("dryRun");
  const reviewModeEl = $("reviewMode"); // New v2.0
  const safeModeEl = $("safeMode");
  const skipStarredEl = $("skipStarred");     // New
  const skipImportantEl = $("skipImportant"); // New

  // Nav
  const openOptionsBtn = $("openOptions");
  const openDiagnosticsBtn = $("openDiagnostics"); // New

  // Safety check to ensure DOM matches script expectations
  if (!runBtn || !statusEl || !intensityEl || !dryRunEl || !safeModeEl) {
    console.error("[Gmail Cleaner] Critical DOM elements missing.");
    return;
  }

  // Button text helpers
  const runLabelSpan = runBtn.querySelector(".label");
  const runSubSpan = runBtn.querySelector(".sub");
  const originalLabel =
    (runLabelSpan && runLabelSpan.textContent) || runBtn.textContent || "Run";
  const originalSub = (runSubSpan && runSubSpan.textContent) || "";

  /**
   * Set run button state (disabled + label/sub text) safely.
   */
  function setRunButtonState({ disabled, label, sub }) {
    runBtn.disabled = !!disabled;

    if (runLabelSpan && typeof label === "string") {
      runLabelSpan.textContent = label;
    } else if (typeof label === "string") {
      runBtn.textContent = label;
    }

    if (runSubSpan && typeof sub === "string") {
      runSubSpan.textContent = sub;
    }
  }

  /**
   * Update status text (clears previous content).
   */
  function setStatus(message) {
    if (!statusEl) return;
    statusEl.textContent = message || "";
  }

  /**
   * Helper to fetch the "Debug Mode" preference from sync storage.
   * This is set in the Options page.
   */
  async function getDebugModeSetting() {
    try {
      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync) {
        const res = await chrome.storage.sync.get("debugMode");
        return !!res.debugMode;
      }
    } catch {
      return false;
    }
    return false;
  }
  
  /**
   * Helper to fetch the Global Whitelist from sync storage.
   * This is set in the Options page.
   */
  async function getWhitelist() {
    try {
      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync) {
        const res = await chrome.storage.sync.get("whitelist");
        return Array.isArray(res.whitelist) ? res.whitelist : [];
      }
    } catch {
      return [];
    }
    return [];
  }

  /**
   * Try to restore last used settings into the popup controls.
   * Uses session storage first, then falls back to local.
   */
  async function restoreLastConfig() {
    try {
      let lastConfig = null;

      // Try session storage first
      try {
        const sessionResult = await chrome.storage.session.get("lastConfig");
        lastConfig = sessionResult.lastConfig || null;
      } catch {
        // ignore
      }

      if (!lastConfig) {
        const localResult = await chrome.storage.local.get("lastConfig");
        lastConfig = localResult.lastConfig || null;
      }

      if (!lastConfig || typeof lastConfig !== "object") return;

      // Restore inputs
      if (lastConfig.intensity && intensityEl.querySelector(`option[value="${lastConfig.intensity}"]`)) {
        intensityEl.value = lastConfig.intensity;
      }

      // Map boolean archiveInsteadOfDelete back to select box
      if (actionTypeEl) {
        actionTypeEl.value = lastConfig.archiveInsteadOfDelete ? "archive" : "trash";
      }

      if (minAgeEl && lastConfig.minAge !== undefined) {
         // Check if the value exists in dropdown, otherwise default to ""
         const exists = minAgeEl.querySelector(`option[value="${lastConfig.minAge}"]`);
         minAgeEl.value = exists ? lastConfig.minAge : "";
      }

      if (typeof lastConfig.dryRun === "boolean") {
        dryRunEl.checked = lastConfig.dryRun;
      }
      if (reviewModeEl && typeof lastConfig.reviewMode === "boolean") {
        reviewModeEl.checked = lastConfig.reviewMode;
      }
      if (typeof lastConfig.safeMode === "boolean") {
        safeModeEl.checked = lastConfig.safeMode;
      }
      if (skipStarredEl && typeof lastConfig.guardSkipStarred === "boolean") {
        skipStarredEl.checked = lastConfig.guardSkipStarred;
      }
      if (skipImportantEl && typeof lastConfig.guardSkipImportant === "boolean") {
        skipImportantEl.checked = lastConfig.guardSkipImportant;
      }

    } catch (err) {
      console.warn("[Gmail Cleaner] Failed to restore last config.", err);
    }
  }

  /**
   * Persist the current config for reuse next time.
   */
  async function persistLastConfig(config) {
    try {
      await chrome.storage.session.set({ lastConfig: config });
    } catch {
      try {
        await chrome.storage.local.set({ lastConfig: config });
      } catch {
        // Ignore
      }
    }
  }

  // --- Navigation Handlers ---

  if (openOptionsBtn) {
    openOptionsBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      try {
        const url = chrome.runtime.getURL("options.html");
        await chrome.tabs.create({ url });
      } catch (err) {
        console.error("Failed to open options.", err);
      }
    });
  }

  if (openDiagnosticsBtn) {
    openDiagnosticsBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      try {
        const url = chrome.runtime.getURL("diagnostics.html");
        await chrome.tabs.create({ url });
      } catch (err) {
        console.error("Failed to open diagnostics.", err);
      }
    });
  }

  /**
   * Find an appropriate Gmail tab in the current window.
   */
  async function findGmailTab() {
    try {
      // 1. Prefer active tab if it's Gmail
      const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true
      });

      if (
        activeTab &&
        activeTab.url &&
        activeTab.url.startsWith("https://mail.google.com/")
      ) {
        return activeTab;
      }

      // 2. Fallback: find any Gmail tab in this window
      const tabs = await chrome.tabs.query({
        url: "https://mail.google.com/*",
        currentWindow: true
      });

      if (!tabs || !tabs.length) return null;

      // Prefer one that is 'active' if somehow query logic above missed it, 
      // otherwise just take the first one.
      const active = tabs.find((t) => t.active);
      return active || tabs[0];
    } catch (err) {
      console.error("[Gmail Cleaner] Error finding tab:", err);
      return null;
    }
  }

  /**
   * Show helper button if Gmail isn't found.
   */
  function showOpenGmailHelper() {
    if (!statusEl) return;
    setStatus("Open Gmail first, then try again.");

    const existing = statusEl.querySelector("button.open-gmail-helper");
    if (existing) return;

    const openBtn = document.createElement("button");
    openBtn.type = "button";
    openBtn.className = "open-gmail-helper";
    openBtn.textContent = "Open Gmail";
    openBtn.style.marginTop = "8px";
    openBtn.style.padding = "4px 10px";
    openBtn.style.borderRadius = "999px";
    openBtn.style.border = "1px solid rgba(148,163,184,0.7)";
    openBtn.style.background = "rgba(15,23,42,0.9)";
    openBtn.style.color = "#e5e7eb";
    openBtn.style.fontSize = "11px";
    openBtn.style.cursor = "pointer";

    openBtn.onclick = async () => {
      try {
        await chrome.tabs.create({
          url: "https://mail.google.com/mail/u/0/#inbox"
        });
      } catch (err) {
        console.error("Failed to open Gmail.", err);
      }
    };
    statusEl.appendChild(openBtn);
  }

  // --- Main Run Handler ---

  runBtn.addEventListener("click", async () => {
    // 1. UI Feedback
    setRunButtonState({
      disabled: true,
      label: "Starting...",
      sub: "Locating Gmail & attaching cleaner"
    });
    setStatus("Locating a Gmail tab...");

    try {
      // 2. Locate Tab
      const gmailTab = await findGmailTab();

      if (!gmailTab || typeof gmailTab.id !== "number") {
        showOpenGmailHelper();
        setRunButtonState({
          disabled: false,
          label: originalLabel,
          sub: originalSub
        });
        return;
      }

      // 3. Build Configuration
      const isArchive = actionTypeEl ? actionTypeEl.value === "archive" : false;
      const debugMode = await getDebugModeSetting();
      const whitelist = await getWhitelist();

      const config = {
        intensity: intensityEl.value,
        dryRun: !!dryRunEl.checked,
        safeMode: !!safeModeEl.checked,
        
        // New Guardrails & Features
        archiveInsteadOfDelete: isArchive,
        minAge: (minAgeEl && minAgeEl.value) ? minAgeEl.value : null,
        guardSkipStarred: skipStarredEl ? !!skipStarredEl.checked : true,
        guardSkipImportant: skipImportantEl ? !!skipImportantEl.checked : true,
        
        reviewMode: reviewModeEl ? !!reviewModeEl.checked : false,
        whitelist: whitelist,

        // Debugging
        debugMode: debugMode
      };

      await persistLastConfig(config);

      const destination = config.archiveInsteadOfDelete ? "All Mail" : "Trash";
      
      // Update UI text before launching
      setRunButtonState({
        disabled: true,
        label: config.dryRun ? "Starting dry-run..." : "Starting cleanup...",
        sub: config.dryRun
          ? "No mail will be moved yet"
          : `Tagging, then moving old mail to ${destination}`
      });
      
      setStatus(
        config.dryRun
          ? "Dry-run mode: counting matches without moving anything."
          : `Live mode: messages will be tagged, then moved to ${destination}.`
      );

      // 4. Open Progress Window
      const progressUrl = chrome.runtime.getURL(
        `progress.html?gmailTabId=${gmailTab.id}`
      );
      await chrome.tabs.create({ url: progressUrl, active: true });

      // 5. Inject Config & Script
      await chrome.scripting.executeScript({
        target: { tabId: gmailTab.id },
        func: (cfg) => {
          // This code runs in the Gmail page context.
          window.GMAIL_CLEANER_CONFIG = cfg;
        },
        args: [config]
      });

      await chrome.scripting.executeScript({
        target: { tabId: gmailTab.id },
        files: ["contentScript.js"]
      });

      // 6. Close Popup
      window.close();

    } catch (err) {
      console.error("[Gmail Cleaner] Error starting cleanup:", err);
      setStatus(`Error: ${err?.message || String(err)}`);
      setRunButtonState({
        disabled: false,
        label: originalLabel,
        sub: originalSub
      });
    }
  });

  // --- Tip & Footer Handlers ---

  // Handle footer links (BMC / CashApp)
  (function attachFooterTipLinkHandler() {
    const BMC_URL = "https://www.buymeacoffee.com/judeh1l";
    const CASH_URL = "https://cash.app/$judeh1l";

    const links = document.querySelectorAll(`a[href="${BMC_URL}"], a[href="${CASH_URL}"]`);
    if (!links.length) return;

    links.forEach((footerTipLink) => {
      footerTipLink.addEventListener("click", async (e) => {
        e.preventDefault();

        const url = footerTipLink.href || BMC_URL;
        const source = url.includes("buymeacoffee.com") ? "buymeacoffee" : "cashapp";

        try {
          await chrome.tabs.create({ url });
          // Log intent (best effort)
          try {
            await chrome.storage.local.set({
              lastTipIntentAt: Date.now(),
              lastTipIntentSource: source
            });
          } catch {}
        } catch {}

        window.close();
      });
    });
  })();

  // Allow Enter to trigger run (UX convenience)
  document.addEventListener("keydown", (evt) => {
    if (evt.key !== "Enter") return;
    const target = evt.target;
    if (!target) return;

    // Don't hijack Enter inside inputs
    const tag = target.tagName;
    if (tag === "INPUT" || tag === "SELECT" || tag === "BUTTON" || tag === "TEXTAREA") {
      return;
    }

    if (!runBtn.disabled) {
      runBtn.click();
    }
  });

  // Init
  restoreLastConfig().catch(() => {});
});