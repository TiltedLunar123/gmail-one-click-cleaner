document.addEventListener("DOMContentLoaded", () => {
  "use strict";

  // =========================
  // Constants & Configuration
  // =========================

  const POPUP_VERSION = "3.2.0";

  const CONFIG = Object.freeze({
    TOAST_DURATION_MS: 3000,
    BUTTON_SUCCESS_DURATION_MS: 2000,
    STATUS_CLEAR_DELAY_MS: 5000,
    GMAIL_URL: "https://mail.google.com/",
    GMAIL_INBOX_URL: "https://mail.google.com/mail/u/0/#inbox",
    RATING_THRESHOLD_RUNS: 2
  });

  const STORAGE_KEYS = Object.freeze({
    LAST_CONFIG: "lastConfig",
    DEBUG_MODE: "debugMode",
    WHITELIST: "whitelist",
    TIP_INTENT: "lastTipIntentAt",
    TIP_SOURCE: "lastTipIntentSource",
    PIN_DISMISSED: "pinHintDismissed",
    RUN_COUNT: "runSuccessCount",
    RATING_DISMISSED: "ratingPromptDismissed"
  });

  const BUTTON_STATES = Object.freeze({
    IDLE: "idle",
    LOADING: "loading",
    RUNNING: "running",
    SUCCESS: "success"
  });

  const STATUS_TYPES = Object.freeze({
    INFO: "info",
    SUCCESS: "success",
    WARNING: "warning",
    ERROR: "error",
    RUNNING: "running"
  });

  // =========================
  // State Management
  // =========================

  const state = {
    isRunning: false,
    currentGmailTabId: null,
    buttonState: BUTTON_STATES.IDLE
  };

  // =========================
  // Utility Functions
  // =========================

  /**
   * Safely get element by ID.
   * @param {string} id
   * @returns {HTMLElement | null}
   */
  const $ = (id) => document.getElementById(id);

  /**
   * Safely query for elements.
   * @param {string} selector
   * @returns {NodeListOf<Element>}
   */
  const $$ = (selector) => document.querySelectorAll(selector);

  /**
   * Check if Chrome storage is available.
   * @param {"sync" | "local" | "session"} type
   * @returns {boolean}
   */
  const hasChromeStorage = (type = "sync") => {
    try {
      return (
        typeof chrome !== "undefined" &&
        chrome?.storage?.[type] &&
        typeof chrome.storage[type].get === "function"
      );
    } catch {
      return false;
    }
  };

  /**
   * Check if Chrome tabs API is available.
   * @returns {boolean}
   */
  const hasChromeTabs = () => {
    try {
      return typeof chrome !== "undefined" && !!chrome.tabs;
    } catch {
      return false;
    }
  };

  /**
   * Check if Chrome scripting API is available.
   * @returns {boolean}
   */
  const hasChromeScripting = () => {
    try {
      return typeof chrome !== "undefined" && !!chrome.scripting;
    } catch {
      return false;
    }
  };

  /**
   * Log with prefix.
   * @param {string} level
   * @param  {...any} args
   */
  const log = (level, ...args) => {
    const prefix = `[Gmail Cleaner Popup]`;
    console[level]?.(prefix, ...args);
  };

  // =========================
  // DOM Element Cache
  // =========================

  const elements = {
    // Main controls
    runBtn: $("runCleanup"),
    statusEl: $("status"),
    intensityEl: $("intensity"),
    actionTypeEl: $("actionType"),
    minAgeEl: $("minAge"),

    // Monthly Clean Preset
    monthlyCleanBtn: $("monthlyCleanBtn"),

    // Pin Hint
    pinHint: $("pinHint"),
    pinHintClose: $("pinHintClose"),

    // Toggles
    dryRunEl: $("dryRun"),
    reviewModeEl: $("reviewMode"),
    safeModeEl: $("safeMode"),
    skipStarredEl: $("skipStarred"),
    skipImportantEl: $("skipImportant"),

    // Navigation
    openOptionsBtn: $("openOptions"),
    openDiagnosticsBtn: $("openDiagnostics"),

    // Progress & Quick Actions
    progressBar: $("progressBar"),
    progressBarInner: $("progressBarInner"),
    quickActions: $("quickActions"),
    cancelBtn: $("cancelBtn"),
    openProgressBtn: $("openProgressBtn"),

    // Results & Success Screens
    resultSummary: $("resultSummary"),
    resultCount: $("resultCount"),
    resultSize: $("resultSize"),
    successCtas: $("successCtas"),
    
    // Rating Prompt
    ratingPrompt: $("ratingPrompt"),
    ratingDismiss: $("ratingDismiss"),
    ratingBtn: $("ratingBtn"),

    // Toast
    toastContainer: $("toastContainer")
  };

  // Validate critical elements
  const criticalElements = ["runBtn", "statusEl", "intensityEl", "dryRunEl", "safeModeEl"];
  const missingElements = criticalElements.filter((key) => !elements[key]);

  if (missingElements.length > 0) {
    log("error", "Critical DOM elements missing:", missingElements);
    return;
  }

  // Cache button text elements
  const runLabelSpan = elements.runBtn.querySelector(".label");
  const runSubSpan = elements.runBtn.querySelector(".sub");
  const originalLabel = runLabelSpan?.textContent || elements.runBtn.textContent || "Run Cleaner";
  const originalSub = runSubSpan?.textContent || "Items are tagged before action";

  // =========================
  // Toast Notifications
  // =========================

  const TOAST_ICONS = Object.freeze({
    success: "✅",
    error: "❌",
    warning: "⚠️",
    info: "ℹ️"
  });

  /**
   * Show a toast notification.
   * @param {string} message
   * @param {keyof typeof TOAST_ICONS} [type="info"]
   * @param {number} [duration]
   */
  const showToast = (message, type = "info", duration = CONFIG.TOAST_DURATION_MS) => {
    const container = elements.toastContainer;
    if (!container) {
      log("info", `[Toast ${type}]`, message);
      return;
    }

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.setAttribute("role", "alert");

    const icon = document.createElement("span");
    icon.className = "toast-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = TOAST_ICONS[type] || TOAST_ICONS.info;

    const text = document.createElement("span");
    text.textContent = message;

    toast.appendChild(icon);
    toast.appendChild(text);
    container.appendChild(toast);

    // Trigger animation
    requestAnimationFrame(() => {
      toast.classList.add("show");
    });

    // Remove after duration
    setTimeout(() => {
      toast.classList.remove("show");
      setTimeout(() => {
        toast.parentNode?.removeChild(toast);
      }, 300);
    }, duration);
  };

  // =========================
  // Status Management
  // =========================

  /** @type {number | null} */
  let statusClearTimeout = null;

  /**
   * Update status text with optional type styling.
   * @param {string} message
   * @param {keyof typeof STATUS_TYPES} [type]
   * @param {boolean} [autoClear=false]
   */
  const setStatus = (message, type = STATUS_TYPES.INFO, autoClear = false) => {
    const el = elements.statusEl;
    if (!el) return;

    // Clear any pending timeout
    if (statusClearTimeout) {
      clearTimeout(statusClearTimeout);
      statusClearTimeout = null;
    }

    // Remove all status type classes
    el.className = "status";

    // Add type class if provided
    if (type && STATUS_TYPES[type.toUpperCase()]) {
      el.classList.add(`status-${type.toLowerCase()}`);
    }

    el.textContent = message || "";

    // Auto-clear if requested
    if (autoClear && message) {
      statusClearTimeout = setTimeout(() => {
        el.textContent = "";
        el.className = "status";
      }, CONFIG.STATUS_CLEAR_DELAY_MS);
    }
  };

  /**
   * Clear status message.
   */
  const clearStatus = () => {
    setStatus("");
  };

  // =========================
  // Button State Management
  // =========================

  /**
   * Set the run button state.
   * @param {Object} options
   * @param {boolean} [options.disabled]
   * @param {string} [options.label]
   * @param {string} [options.sub]
   * @param {keyof typeof BUTTON_STATES} [options.state]
   */
  const setRunButtonState = ({ disabled, label, sub, state: buttonState }) => {
    const btn = elements.runBtn;
    if (!btn) return;

    btn.disabled = Boolean(disabled);

    // Update state class
    if (buttonState) {
      btn.classList.remove("loading", "running", "success");
      if (buttonState !== BUTTON_STATES.IDLE) {
        btn.classList.add(buttonState.toLowerCase());
      }
      state.buttonState = buttonState;
    }

    // Update label
    if (typeof label === "string") {
      if (runLabelSpan) {
        runLabelSpan.textContent = label;
      } else {
        btn.textContent = label;
      }
    }

    // Update subtitle
    if (typeof sub === "string" && runSubSpan) {
      runSubSpan.textContent = sub;
    }

    // Update aria-busy
    if (buttonState === BUTTON_STATES.LOADING || buttonState === BUTTON_STATES.RUNNING) {
      btn.setAttribute("aria-busy", "true");
    } else {
      btn.removeAttribute("aria-busy");
    }
  };

  /**
   * Reset button to original state.
   */
  const resetRunButton = () => {
    setRunButtonState({
      disabled: false,
      label: originalLabel,
      sub: originalSub,
      state: BUTTON_STATES.IDLE
    });
  };

  /**
   * Show success state on button.
   */
  const showButtonSuccess = () => {
    setRunButtonState({
      disabled: false,
      label: "Started!",
      sub: "Opening progress window...",
      state: BUTTON_STATES.SUCCESS
    });

    setTimeout(resetRunButton, CONFIG.BUTTON_SUCCESS_DURATION_MS);
  };

  // =========================
  // Progress Bar
  // =========================

  /**
   * Show progress bar.
   * @param {number} [percent=0]
   */
  const showProgress = (percent = 0) => {
    if (!elements.progressBar) return;
    
    elements.progressBar.classList.add("show");
    elements.progressBar.setAttribute("aria-valuenow", String(percent));
    
    if (elements.progressBarInner) {
      elements.progressBarInner.style.width = `${Math.min(100, Math.max(0, percent))}%`;
    }
  };

  /**
   * Hide progress bar.
   */
  const hideProgress = () => {
    if (!elements.progressBar) return;
    
    elements.progressBar.classList.remove("show");
    
    if (elements.progressBarInner) {
      elements.progressBarInner.style.width = "0%";
    }
  };

  /**
   * Update progress bar percentage.
   * @param {number} percent
   */
  const updateProgress = (percent) => {
    if (!elements.progressBar) return;
    
    elements.progressBar.setAttribute("aria-valuenow", String(percent));
    
    if (elements.progressBarInner) {
      elements.progressBarInner.style.width = `${Math.min(100, Math.max(0, percent))}%`;
    }
  };

  // =========================
  // Quick Actions
  // =========================

  /**
   * Show quick action buttons.
   */
  const showQuickActions = () => {
    if (elements.quickActions) {
      elements.quickActions.classList.add("show");
    }
  };

  /**
   * Hide quick action buttons.
   */
  const hideQuickActions = () => {
    if (elements.quickActions) {
      elements.quickActions.classList.remove("show");
    }
  };

  // =========================
  // Storage Helpers
  // =========================

  /**
   * Get debug mode setting from storage.
   * @returns {Promise<boolean>}
   */
  const getDebugModeSetting = async () => {
    if (!hasChromeStorage("sync")) return false;

    try {
      const result = await new Promise((resolve) => {
        chrome.storage.sync.get(STORAGE_KEYS.DEBUG_MODE, resolve);
      });
      return Boolean(result?.[STORAGE_KEYS.DEBUG_MODE]);
    } catch (err) {
      log("warn", "Failed to get debug mode setting:", err);
      return false;
    }
  };

  /**
   * Get global whitelist from storage.
   * @returns {Promise<string[]>}
   */
  const getWhitelist = async () => {
    if (!hasChromeStorage("sync")) return [];

    try {
      const result = await new Promise((resolve) => {
        chrome.storage.sync.get(STORAGE_KEYS.WHITELIST, resolve);
      });
      const whitelist = result?.[STORAGE_KEYS.WHITELIST];
      return Array.isArray(whitelist) ? whitelist : [];
    } catch (err) {
      log("warn", "Failed to get whitelist:", err);
      return [];
    }
  };

  /**
   * Restore last used config from storage.
   */
  const restoreLastConfig = async () => {
    let lastConfig = null;

    // Try session storage first
    if (hasChromeStorage("session")) {
      try {
        const result = await new Promise((resolve) => {
          chrome.storage.session.get(STORAGE_KEYS.LAST_CONFIG, resolve);
        });
        lastConfig = result?.[STORAGE_KEYS.LAST_CONFIG] || null;
      } catch {
        // Ignore session storage errors
      }
    }

    // Fall back to local storage
    if (!lastConfig && hasChromeStorage("local")) {
      try {
        const result = await new Promise((resolve) => {
          chrome.storage.local.get(STORAGE_KEYS.LAST_CONFIG, resolve);
        });
        lastConfig = result?.[STORAGE_KEYS.LAST_CONFIG] || null;
      } catch {
        // Ignore local storage errors
      }
    }

    if (!lastConfig || typeof lastConfig !== "object") return;

    // Apply saved values
    applyConfig(lastConfig);
  };

  /**
   * Apply a config object to form elements.
   * @param {Object} config
   */
  const applyConfig = (config) => {
    // Intensity
    if (config.intensity && elements.intensityEl) {
      const option = elements.intensityEl.querySelector(`option[value="${config.intensity}"]`);
      if (option) {
        elements.intensityEl.value = config.intensity;
      }
    }

    // Action type
    if (elements.actionTypeEl) {
      elements.actionTypeEl.value = config.archiveInsteadOfDelete ? "archive" : "trash";
    }

    // Minimum age
    if (elements.minAgeEl && config.minAge !== undefined) {
      const option = elements.minAgeEl.querySelector(`option[value="${config.minAge || ''}"]`);
      elements.minAgeEl.value = option ? (config.minAge || "") : "";
    }

    // Toggles
    if (typeof config.dryRun === "boolean" && elements.dryRunEl) {
      elements.dryRunEl.checked = config.dryRun;
    }

    if (typeof config.reviewMode === "boolean" && elements.reviewModeEl) {
      elements.reviewModeEl.checked = config.reviewMode;
    }

    if (typeof config.safeMode === "boolean" && elements.safeModeEl) {
      elements.safeModeEl.checked = config.safeMode;
    }

    if (typeof config.guardSkipStarred === "boolean" && elements.skipStarredEl) {
      elements.skipStarredEl.checked = config.guardSkipStarred;
    }

    if (typeof config.guardSkipImportant === "boolean" && elements.skipImportantEl) {
      elements.skipImportantEl.checked = config.guardSkipImportant;
    }
  };

  /**
   * Persist current config to storage.
   * @param {Object} config
   */
  const persistLastConfig = async (config) => {
    // Try session storage first
    if (hasChromeStorage("session")) {
      try {
        await new Promise((resolve, reject) => {
          chrome.storage.session.set({ [STORAGE_KEYS.LAST_CONFIG]: config }, () => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve();
            }
          });
        });
        return;
      } catch {
        // Fall through to local storage
      }
    }

    // Fall back to local storage
    if (hasChromeStorage("local")) {
      try {
        await new Promise((resolve) => {
          chrome.storage.local.set({ [STORAGE_KEYS.LAST_CONFIG]: config }, resolve);
        });
      } catch {
        // Ignore storage errors
      }
    }
  };

  // =========================
  // Gmail Tab Management
  // =========================

  /**
   * Find an appropriate Gmail tab.
   * @returns {Promise<chrome.tabs.Tab | null>}
   */
  const findGmailTab = async () => {
    if (!hasChromeTabs()) {
      log("error", "Chrome tabs API not available");
      return null;
    }

    try {
      // 1. Check if active tab is Gmail
      const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true
      });

      if (activeTab?.url?.startsWith(CONFIG.GMAIL_URL)) {
        return activeTab;
      }

      // 2. Find any Gmail tab in current window
      const currentWindowTabs = await chrome.tabs.query({
        url: `${CONFIG.GMAIL_URL}*`,
        currentWindow: true
      });

      if (currentWindowTabs?.length) {
        const active = currentWindowTabs.find((t) => t.active);
        return active || currentWindowTabs[0];
      }

      // 3. Find any Gmail tab in any window
      const allTabs = await chrome.tabs.query({
        url: `${CONFIG.GMAIL_URL}*`
      });

      if (allTabs?.length) {
        const active = allTabs.find((t) => t.active);
        return active || allTabs[0];
      }

      return null;
    } catch (err) {
      log("error", "Error finding Gmail tab:", err);
      return null;
    }
  };

  /**
   * Show helper button when Gmail isn't found.
   */
  const showOpenGmailHelper = () => {
    setStatus("Open Gmail first, then try again.", STATUS_TYPES.WARNING);

    // Check if helper already exists
    const existing = elements.statusEl.querySelector(".open-gmail-helper");
    if (existing) return;

    const openBtn = document.createElement("button");
    openBtn.type = "button";
    openBtn.className = "open-gmail-helper quick-action-btn";
    openBtn.textContent = "Open Gmail";
    openBtn.style.marginTop = "8px";

    openBtn.addEventListener("click", async () => {
      try {
        await chrome.tabs.create({ url: CONFIG.GMAIL_INBOX_URL });
        showToast("Opening Gmail...", "info");
      } catch (err) {
        log("error", "Failed to open Gmail:", err);
        showToast("Failed to open Gmail", "error");
      }
    });

    elements.statusEl.appendChild(openBtn);
  };

  /**
   * Remove the Gmail helper button if present.
   */
  const removeOpenGmailHelper = () => {
    const helper = elements.statusEl?.querySelector(".open-gmail-helper");
    helper?.remove();
  };

  // =========================
  // Feature Logic: Monthly Clean, Hints, Ratings
  // =========================

  /**
   * Handle "Monthly Light Clean" preset click.
   */
  const handleMonthlyClean = () => {
    if (elements.intensityEl) elements.intensityEl.value = "light";
    if (elements.actionTypeEl) elements.actionTypeEl.value = "trash";
    if (elements.minAgeEl) elements.minAgeEl.value = "3m"; // Safer 3m default
    
    // Enable Safe Mode for monthly clean
    if (elements.safeModeEl) elements.safeModeEl.checked = true;
    
    showToast("Preset applied! Review settings below.", "success");
    
    // Smooth scroll to run button or just focus it
    elements.runBtn.focus();
    elements.runBtn.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  /**
   * Check and show "Pin Me" hint.
   */
  const checkPinHint = async () => {
    if (!hasChromeStorage("local") || !elements.pinHint) return;
    
    try {
      const result = await chrome.storage.local.get(STORAGE_KEYS.PIN_DISMISSED);
      if (!result[STORAGE_KEYS.PIN_DISMISSED]) {
        elements.pinHint.classList.add("show");
      }
    } catch (e) {
      // Ignore
    }
  };

  /**
   * Dismiss "Pin Me" hint.
   */
  const dismissPinHint = async () => {
    if (elements.pinHint) {
      elements.pinHint.classList.remove("show");
    }
    if (hasChromeStorage("local")) {
      await chrome.storage.local.set({ [STORAGE_KEYS.PIN_DISMISSED]: true });
    }
  };

  /**
   * Handle rating prompt logic (increment run count, show if needed).
   */
  const handleRatingLogic = async () => {
    if (!hasChromeStorage("local")) return;

    try {
      const result = await chrome.storage.local.get([
        STORAGE_KEYS.RUN_COUNT, 
        STORAGE_KEYS.RATING_DISMISSED
      ]);
      
      let count = (result[STORAGE_KEYS.RUN_COUNT] || 0) + 1;
      await chrome.storage.local.set({ [STORAGE_KEYS.RUN_COUNT]: count });

      // If dismissed, do nothing
      if (result[STORAGE_KEYS.RATING_DISMISSED]) return;

      // Show prompt if threshold met
      if (count >= CONFIG.RATING_THRESHOLD_RUNS && elements.ratingPrompt) {
        elements.ratingPrompt.classList.add("show");
      }
    } catch (e) {
      log("warn", "Rating logic error", e);
    }
  };

  /**
   * Dismiss rating prompt.
   */
  const dismissRatingPrompt = async () => {
    if (elements.ratingPrompt) {
      elements.ratingPrompt.classList.remove("show");
    }
    if (hasChromeStorage("local")) {
      await chrome.storage.local.set({ [STORAGE_KEYS.RATING_DISMISSED]: true });
    }
  };

  // =========================
  // Build Configuration
  // =========================

  /**
   * Collect current form values into a config object.
   * @returns {Promise<Object>}
   */
  const buildConfig = async () => {
    const [debugMode, whitelist] = await Promise.all([
      getDebugModeSetting(),
      getWhitelist()
    ]);

    // Check specific "monthly" value which maps to "light" in logic but we handle UI mapping here
    let intensity = elements.intensityEl?.value || "normal";
    if (intensity === "monthly") intensity = "light";

    return {
      intensity,
      dryRun: Boolean(elements.dryRunEl?.checked),
      safeMode: Boolean(elements.safeModeEl?.checked),
      archiveInsteadOfDelete: elements.actionTypeEl?.value === "archive",
      minAge: elements.minAgeEl?.value || null,
      guardSkipStarred: elements.skipStarredEl?.checked ?? true,
      guardSkipImportant: elements.skipImportantEl?.checked ?? true,
      reviewMode: Boolean(elements.reviewModeEl?.checked),
      whitelist,
      debugMode,
      version: POPUP_VERSION
    };
  };

  // =========================
  // Run Cleanup
  // =========================

  /**
   * Main cleanup handler.
   */
  const runCleanup = async () => {
    if (state.isRunning) {
      log("warn", "Cleanup already running");
      return;
    }

    state.isRunning = true;
    removeOpenGmailHelper();

    // 1. Update UI to loading state
    setRunButtonState({
      disabled: true,
      label: "Starting...",
      sub: "Locating Gmail & preparing cleaner",
      state: BUTTON_STATES.LOADING
    });
    setStatus("Locating a Gmail tab...", STATUS_TYPES.RUNNING);
    showProgress(10);

    try {
      // 2. Find Gmail tab
      const gmailTab = await findGmailTab();

      if (!gmailTab?.id) {
        showOpenGmailHelper();
        resetRunButton();
        hideProgress();
        state.isRunning = false;
        return;
      }

      state.currentGmailTabId = gmailTab.id;
      updateProgress(30);

      // 3. Build configuration
      const config = await buildConfig();
      await persistLastConfig(config);

      const destination = config.archiveInsteadOfDelete ? "All Mail" : "Trash";
      const modeLabel = config.dryRun ? "dry-run" : "live cleanup";

      updateProgress(50);

      // 4. Update UI to running state
      setRunButtonState({
        disabled: true,
        label: config.dryRun ? "Starting dry-run..." : "Starting cleanup...",
        sub: config.dryRun
          ? "Counting matches without moving mail"
          : `Tagging, then moving to ${destination}`,
        state: BUTTON_STATES.RUNNING
      });

      setStatus(
        config.dryRun
          ? "Dry-run mode: counting matches..."
          : `Live mode: moving old mail to ${destination}...`,
        STATUS_TYPES.RUNNING
      );

      updateProgress(70);

      // 5. Open progress window
      const progressUrl = chrome.runtime.getURL(`progress.html?gmailTabId=${gmailTab.id}`);
      await chrome.tabs.create({ url: progressUrl, active: true });

      updateProgress(85);

      // 6. Inject config and content script
      if (!hasChromeScripting()) {
        throw new Error("Chrome scripting API not available");
      }

      await chrome.scripting.executeScript({
        target: { tabId: gmailTab.id },
        func: (cfg) => {
          window.GMAIL_CLEANER_CONFIG = cfg;
        },
        args: [config]
      });

      await chrome.scripting.executeScript({
        target: { tabId: gmailTab.id },
        files: ["contentScript.js"]
      });

      updateProgress(100);

      // 7. Show success and close (optional: keep open to show results? Usually progress window handles it, 
      // but if user switches back to popup we want to know state. For now, we auto-close for UX flow).
      showButtonSuccess();
      showToast(`${modeLabel.charAt(0).toUpperCase() + modeLabel.slice(1)} started!`, "success");

      // Close popup after brief delay
      setTimeout(() => window.close(), 500);

    } catch (err) {
      log("error", "Error starting cleanup:", err);
      
      const message = err?.message || String(err);
      setStatus(`Error: ${message}`, STATUS_TYPES.ERROR);
      showToast(`Failed to start: ${message}`, "error");
      
      resetRunButton();
      hideProgress();
      state.isRunning = false;
    }
  };

  // =========================
  // Quick Action Handlers
  // =========================

  /**
   * Cancel the current cleanup.
   */
  const handleCancel = async () => {
    if (!state.currentGmailTabId) return;

    try {
      await chrome.tabs.sendMessage(state.currentGmailTabId, {
        type: "gmailCleanerCancel"
      });
      
      showToast("Cancel signal sent", "info");
      hideQuickActions();
      resetRunButton();
      setStatus("Cleanup cancelled", STATUS_TYPES.WARNING, true);
      
      state.isRunning = false;
    } catch (err) {
      log("error", "Failed to send cancel:", err);
      showToast("Failed to cancel", "error");
    }
  };

  /**
   * Open the progress window.
   */
  const handleOpenProgress = async () => {
    if (!state.currentGmailTabId) {
      showToast("No active cleanup", "warning");
      return;
    }

    try {
      const progressUrl = chrome.runtime.getURL(
        `progress.html?gmailTabId=${state.currentGmailTabId}`
      );
      await chrome.tabs.create({ url: progressUrl, active: true });
    } catch (err) {
      log("error", "Failed to open progress:", err);
      showToast("Failed to open progress", "error");
    }
  };

  // =========================
  // Navigation Handlers
  // =========================

  /**
   * Open options page.
   */
  const openOptions = async () => {
    try {
      const url = chrome.runtime.getURL("options.html");
      await chrome.tabs.create({ url });
    } catch (err) {
      log("error", "Failed to open options:", err);
      showToast("Failed to open options", "error");
    }
  };

  /**
   * Open diagnostics page.
   */
  const openDiagnostics = async () => {
    try {
      const url = chrome.runtime.getURL("diagnostics.html");
      await chrome.tabs.create({ url });
    } catch (err) {
      log("error", "Failed to open diagnostics:", err);
      showToast("Failed to open diagnostics", "error");
    }
  };

  // =========================
  // Tip Link Handler
  // =========================

  /**
   * Set up tip link click tracking.
   */
  const setupTipLinks = () => {
    const tipLinks = $$('a[href*="buymeacoffee.com"], a[href*="cash.app"]');

    tipLinks.forEach((link) => {
      link.addEventListener("click", async (e) => {
        e.preventDefault();

        const url = link.href;
        const source = url.includes("buymeacoffee.com") ? "buymeacoffee" : "cashapp";

        try {
          await chrome.tabs.create({ url });

          // Log intent (best effort)
          if (hasChromeStorage("local")) {
            chrome.storage.local.set({
              [STORAGE_KEYS.TIP_INTENT]: Date.now(),
              [STORAGE_KEYS.TIP_SOURCE]: source
            }).catch(() => {});
          }
        } catch (err) {
          log("error", "Failed to open tip link:", err);
        }

        window.close();
      });
    });
  };

  // =========================
  // Keyboard Shortcuts
  // =========================

  /**
   * Set up keyboard shortcuts.
   */
  const setupKeyboardShortcuts = () => {
    document.addEventListener("keydown", (e) => {
      // Enter to run (when not focused on input)
      if (e.key === "Enter") {
        const target = e.target;
        const tag = target?.tagName;

        // Don't hijack Enter inside form elements
        if (["INPUT", "SELECT", "BUTTON", "TEXTAREA"].includes(tag)) {
          return;
        }

        if (!elements.runBtn.disabled) {
          e.preventDefault();
          elements.runBtn.click();
        }
      }

      // Escape to close popup
      if (e.key === "Escape") {
        window.close();
      }

      // Ctrl/Cmd + D for dry run toggle
      if ((e.ctrlKey || e.metaKey) && e.key === "d") {
        e.preventDefault();
        if (elements.dryRunEl) {
          elements.dryRunEl.checked = !elements.dryRunEl.checked;
          showToast(
            `Dry Run ${elements.dryRunEl.checked ? "enabled" : "disabled"}`,
            "info"
          );
        }
      }
    });
  };

  // =========================
  // Collapsible Section Accessibility
  // =========================

  /**
   * Update aria-expanded on details toggle.
   */
  const setupDetailsAccessibility = () => {
    const safetySection = $("safetySection");
    
    if (safetySection) {
      const summary = safetySection.querySelector("summary");
      
      if (summary) {
        // Set initial state
        summary.setAttribute("aria-expanded", safetySection.open ? "true" : "false");

        // Update on toggle
        safetySection.addEventListener("toggle", () => {
          summary.setAttribute("aria-expanded", safetySection.open ? "true" : "false");
        });
      }
    }
  };

  // =========================
  // Event Listeners
  // =========================

  /**
   * Set up all event listeners.
   */
  const setupEventListeners = () => {
    // Main run button
    elements.runBtn.addEventListener("click", runCleanup);

    // Monthly Clean Preset
    elements.monthlyCleanBtn?.addEventListener("click", handleMonthlyClean);

    // Pin Hint Dismiss
    elements.pinHintClose?.addEventListener("click", dismissPinHint);

    // Rating Prompt
    elements.ratingBtn?.addEventListener("click", dismissRatingPrompt);
    elements.ratingDismiss?.addEventListener("click", dismissRatingPrompt);

    // Quick actions
    elements.cancelBtn?.addEventListener("click", handleCancel);
    elements.openProgressBtn?.addEventListener("click", handleOpenProgress);

    // Navigation
    elements.openOptionsBtn?.addEventListener("click", openOptions);
    elements.openDiagnosticsBtn?.addEventListener("click", openDiagnostics);

    // Tip links
    setupTipLinks();

    // Keyboard shortcuts
    setupKeyboardShortcuts();

    // Details accessibility
    setupDetailsAccessibility();

    // Listen for progress updates from content script
    if (chrome.runtime?.onMessage) {
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg?.type !== "gmailCleanerProgress") return;

        if (msg.percent !== undefined) {
          updateProgress(msg.percent);
        }

        if (msg.phase === "done") {
          // Cleanup completed
          state.isRunning = false;
          hideProgress();
          
          // Show Result Summary instead of just resetting form
          if (elements.resultSummary && msg.stats) {
            elements.resultCount.textContent = msg.stats.totalDeleted || 0;
            // Format MB: <0.1 if small, otherwise 1 decimal
            const mb = msg.stats.totalFreedMb || 0;
            elements.resultSize.textContent = (mb > 0 && mb < 0.1) ? "<0.1" : mb.toFixed(1);
            
            elements.resultSummary.classList.add("show");
            if (elements.successCtas) elements.successCtas.classList.add("show");
            
            // Hide Run button to avoid confusion
            elements.runBtn.style.display = "none";
          } else {
             resetRunButton();
          }

          // Handle Rating Logic
          handleRatingLogic();
        } else if (msg.phase === "cancelled" || msg.phase === "error") {
          state.isRunning = false;
          hideQuickActions();
          hideProgress();
          resetRunButton();
        }
      });
    }
  };

  // =========================
  // Initialization
  // =========================

  /**
   * Initialize the popup.
   */
  const init = async () => {
    log("info", `Popup v${POPUP_VERSION} initializing...`);

    // Set up event listeners
    setupEventListeners();

    // Check Pin Hint
    await checkPinHint();

    // Restore last config
    await restoreLastConfig();

    log("info", "Popup ready.");
  };

  // Run initialization
  init().catch((err) => log("error", "Init failed:", err));
});