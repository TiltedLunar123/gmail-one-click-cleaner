# Gmail One-Click Cleaner (v2)

MV3 Chrome extension that bulk-cleans Gmail in one click. It runs a sequence of Gmail searches (promos, social, newsletters, large attachments, etc.), shows a live progress window, and supports Dry-Run, Cancel, and options-based rules.

## Install (Developer Mode)

1. Download and unzip the project (or use the provided `.zip` and extract it).
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top-right).
4. Click **Load unpacked** and select the extension folder (the one containing `manifest.json`).
5. Pin the extension. Open Gmail, then click the extension icon and hit **Run cleanup**.

> If you prefer the store version, search for **“Gmail One-Click Cleaner”** in the Chrome Web Store and install it from there.

## How it works

- Uses a content script + `chrome.scripting` to open safe Gmail searches and bulk-delete matching conversations.
- Shows a dedicated **Progress** page with:
  - Current phase and percent complete
  - Per-query counts and durations
  - Live log of each step
- Uses resilient selectors to keep working when Gmail’s UI shifts.

## Features

- **Dry-Run mode**  
  See how many conversations *would* be deleted without touching your Trash.

- **Cancel mid-run**  
  Click **Cancel** and the cleaner stops within a few seconds.

- **Custom rule sets**  
  Edit the **Light**, **Normal**, and **Deep** query lists in the Options page. Rules are stored in `chrome.storage.sync`, so they follow you across Chrome profiles where sync is enabled.

- **Safe by default**  
  Default rules focus on obvious low-value mail (old promos, social noise, large attachments). Optional “Skip Updates & Forums” toggle to leave receipts and order notifications alone.
