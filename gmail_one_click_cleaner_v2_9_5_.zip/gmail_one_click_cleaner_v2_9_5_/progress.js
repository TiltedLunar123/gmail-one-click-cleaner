(() => {
  "use strict";

  const qs = new URLSearchParams(location.search);
  const gmailTabIdRaw = qs.get("gmailTabId");
  const gmailTabId =
    gmailTabIdRaw != null && gmailTabIdRaw !== ""
      ? Number(gmailTabIdRaw)
      : null;

  const ui = {
    barInner: document.getElementById("barInner"),
    percentText: document.getElementById("percentText"),
    status: document.getElementById("status"),
    details: document.getElementById("details"),
    tags: document.getElementById("tags"),
    cancel: document.getElementById("cancelBtn"),
    reconnect: document.getElementById("reconnectBtn"),
    reinject: document.getElementById("reinjectBtn"),
    panel: document.querySelector(".panel"),
    summary: document.getElementById("summary"),
    table: document.getElementById("summaryTable")
  };

  const tbody = ui.table ? ui.table.querySelector("tbody") : null;
  const progressBar = document.querySelector(".bar");

  const state = {
    trashButtonAdded: false,
    tipPanelAdded: false
  };

  // -----------------------------
  // UI helpers
  // -----------------------------

  function setPercent(p) {
    if (!ui.barInner || !ui.percentText) return;

    const clamped = Math.max(0, Math.min(100, Math.round(p)));
    ui.barInner.style.width = clamped + "%";
    ui.percentText.textContent = clamped + "%";

    // Sync ARIA on the progressbar wrapper if present.
    if (progressBar) {
      progressBar.setAttribute("aria-valuenow", String(clamped));
    }
  }

  function addLog(text) {
    if (!ui.details) return;

    const ts = new Date().toLocaleTimeString();
    const div = document.createElement("div");
    div.textContent = `[${ts}] ${text}`;
    ui.details.prepend(div);
  }

  function setPhase(ph) {
    if (!ui.tags) return;
    ui.tags.textContent = ph || "";
  }

  function ensureTable() {
    if (!ui.table) return;
    ui.table.style.display = "";
  }

  function fmtMs(ms) {
    if (typeof ms !== "number" || !Number.isFinite(ms)) return "—";
    if (ms < 1000) return `${ms} ms`;
    const s = (ms / 1000).toFixed(1);
    return `${s} s`;
  }

  function addRow({ label, mode, count, durationMs }) {
    if (!tbody) return;

    ensureTable();

    const tr = document.createElement("tr");

    const tdQ = document.createElement("td");
    tdQ.textContent = label || "Query";
    tr.appendChild(tdQ);

    const tdM = document.createElement("td");
    tdM.textContent = mode === "dry" ? "Dry-Run" : "Live";
    tr.appendChild(tdM);

    const tdC = document.createElement("td");
    tdC.textContent = (count ?? 0).toLocaleString();
    tr.appendChild(tdC);

    const tdD = document.createElement("td");
    tdD.textContent = durationMs ? fmtMs(durationMs) : "—";
    tr.appendChild(tdD);

    tbody.appendChild(tr);
  }

  function setKPIs({ mode, totalDeleted, totalWouldDelete, totalQueries }) {
    if (!ui.summary) return;

    ui.summary.innerHTML = "";

    const make = (text) => {
      const span = document.createElement("span");
      span.className = "pill";
      span.textContent = text;
      return span;
    };

    const safeModeLabel = mode === "dry" ? "Dry-Run" : "Live";

    ui.summary.appendChild(make(`Mode: ${safeModeLabel}`));
    ui.summary.appendChild(make(`Queries: ${totalQueries ?? 0}`));

    if (mode === "dry") {
      ui.summary.appendChild(
        make(
          `Would delete: ${(totalWouldDelete || 0).toLocaleString()}`
        )
      );
    } else {
      ui.summary.appendChild(
        make(`Deleted: ${(totalDeleted || 0).toLocaleString()}`)
      );
    }
  }

  function addTrashButton() {
    if (state.trashButtonAdded || !ui.panel) return;

    const btn = document.createElement("button");
    btn.textContent = "Open Trash";
    btn.type = "button";
    btn.style.marginTop = "8px";
    btn.style.padding = "6px 12px";
    btn.style.borderRadius = "999px";
    btn.style.border = "1px solid rgba(55,65,81,0.9)";
    btn.style.background = "rgba(15,23,42,0.95)";
    btn.style.color = "#e5e7eb";
    btn.style.fontSize = "11px";
    btn.style.cursor = "pointer";

    btn.onclick = () => {
      window.open("https://mail.google.com/mail/u/0/#trash", "_blank");
    };

    ui.panel.appendChild(btn);
    state.trashButtonAdded = true;
  }

  function showTipPanel(stats) {
    if (state.tipPanelAdded || !ui.panel) return;

    const panel = document.createElement("div");
    panel.style.marginTop = "12px";
    panel.style.padding = "14px";
    panel.style.border = "1px solid var(--border)";
    panel.style.borderRadius = "12px";
    panel.style.background = "rgba(255,255,255,0.04)";
    panel.setAttribute("role", "region");
    panel.setAttribute("aria-label", "Support");

    const savedCount =
      stats?.mode === "dry"
        ? stats?.totalWouldDelete || 0
        : stats?.totalDeleted || 0;

    const heading = document.createElement("div");
    heading.style.fontWeight = "700";
    heading.style.marginBottom = "6px";
    heading.textContent = savedCount
      ? `Nice! ${savedCount.toLocaleString()} emails processed.`
      : "Nice! Cleanup complete.";
    panel.appendChild(heading);

    const micro = document.createElement("div");
    micro.style.fontSize = "12px";
    micro.style.color = "var(--muted)";
    micro.style.marginBottom = "10px";
    micro.textContent =
      "If this saved you time, you can send a tip — it helps keep updates coming.";
    panel.appendChild(micro);

    const btn = document.createElement("button");
    btn.textContent = "Send a tip";
    btn.type = "button";
    btn.style.padding = "10px 14px";
    btn.style.borderRadius = "10px";
    btn.style.border = "1px solid var(--border)";
    btn.style.background = "#0b1220";
    btn.style.color = "#fff";
    btn.style.fontWeight = "600";
    btn.style.cursor = "pointer";

    btn.onclick = () => {
      window.open("https://cash.app/$judeh1l", "_blank");
    };

    panel.appendChild(btn);

    ui.panel.appendChild(panel);
    state.tipPanelAdded = true;
  }

  // -----------------------------
  // Message handling from content script
  // -----------------------------

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.type !== "gmailCleanerProgress") return;

    if (typeof msg.percent === "number") {
      setPercent(msg.percent);
    }

    if (msg.status && ui.status) {
      ui.status.textContent = msg.status;
    }

    if (msg.detail) {
      addLog(msg.detail);
    }

    if (msg.phase) {
      setPhase(msg.phase);
    }

    if (msg.phase === "query-done") {
      try {
        addRow(msg);
      } catch (e) {
        console.warn("[Gmail Cleaner] Failed to add row:", e);
      }
    }

    if (msg.done) {
      setPercent(100);
      if (ui.status) ui.status.textContent = "Cleanup complete.";
      if (ui.cancel) ui.cancel.disabled = true;

      addLog("Done.");
      addTrashButton();

      if (msg.stats) {
        setKPIs(msg.stats);
        showTipPanel(msg.stats);
      }
    }
  });

  // -----------------------------
  // Cancel, reconnect, reinject
  // -----------------------------

  async function sendCancel() {
    addLog("Cancel requested…");

    try {
      const targets =
        typeof gmailTabId === "number" && !Number.isNaN(gmailTabId)
          ? [{ id: gmailTabId }]
          : await chrome.tabs.query({ url: "https://mail.google.com/*" });

      for (const t of targets) {
        if (!t || typeof t.id !== "number") continue;
        try {
          await chrome.tabs.sendMessage(t.id, { type: "gmailCleanerCancel" });
        } catch {
          // ignore per-tab errors
        }
      }
    } catch (err) {
      addLog("Cancel failed: " + (err?.message || String(err)));
    }
  }

  const reconnect = async () => {
    if (typeof gmailTabId !== "number" || Number.isNaN(gmailTabId)) {
      addLog("No Gmail tab ID available. Try Re-inject or start from popup again.");
      return;
    }

    try {
      const res = await chrome.tabs.sendMessage(gmailTabId, {
        type: "gmailCleanerPing"
      });

      if (res && res.ok) {
        addLog("Connected to Gmail tab.");
        if (ui.status) ui.status.textContent = "Connected to Gmail. Watching run…";
        return;
      }

      addLog("No response from Gmail tab. You can try Re-inject.");
    } catch {
      addLog("Ping failed. Try Re-inject.");
    }
  };

  const reinject = async () => {
    if (typeof gmailTabId !== "number" || Number.isNaN(gmailTabId)) {
      addLog("No Gmail tab ID to re-inject into. Start from the popup again.");
      return;
    }

    try {
      let storedConfig = null;

      try {
        const sessionRes = await chrome.storage.session.get("lastConfig");
        storedConfig = sessionRes.lastConfig || null;
      } catch {
        // session may not exist; fall back to local
      }

      if (!storedConfig) {
        try {
          const localRes = await chrome.storage.local.get("lastConfig");
          storedConfig = localRes.lastConfig || null;
        } catch {
          // ignore local failure
        }
      }

      const lastConfig = storedConfig;
      if (!lastConfig) {
        addLog("No last config found. Run the cleaner from the popup again.");
        return;
      }

      await chrome.scripting.executeScript({
        target: { tabId: gmailTabId },
        func: (cfg) => {
          // runs in page context
          window.GMAIL_CLEANER_CONFIG = cfg;
        },
        args: [lastConfig]
      });

      await chrome.scripting.executeScript({
        target: { tabId: gmailTabId },
        files: ["contentScript.js"]
      });

      addLog("Re-injected content script.");
      if (ui.status) ui.status.textContent = "Re-injected. Waiting for progress…";
    } catch (e) {
      addLog("Re-inject failed: " + (e?.message || String(e)));
    }
  };

  if (ui.cancel) {
    ui.cancel.addEventListener("click", () => {
      void sendCancel();
    });
  }

  if (ui.reconnect) {
    ui.reconnect.addEventListener("click", () => {
      void reconnect();
    });
  }

  if (ui.reinject) {
    ui.reinject.addEventListener("click", () => {
      void reinject();
    });
  }

  // -----------------------------
  // Logs toggle
  // -----------------------------

  try {
    const toggleLogsBtn = document.getElementById("toggleLogs");
    if (toggleLogsBtn && ui.details && ui.table) {
      toggleLogsBtn.addEventListener("click", () => {
        const logsHidden = ui.details.style.display === "none";
        ui.details.style.display = logsHidden ? "" : "none";
        ui.table.style.display = logsHidden ? "" : "none";
      });
    }
  } catch {
    // If logs toggle wiring fails, silently ignore.
  }

  // Initial reconnect attempt shortly after load.
  setTimeout(() => {
    void reconnect();
  }, 800);
})();
