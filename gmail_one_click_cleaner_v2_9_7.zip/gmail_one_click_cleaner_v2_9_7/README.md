# Gmail One-Click Cleaner (v2)

MV3 Chrome extension that bulk-cleans Gmail in one click. It runs a sequence of Gmail searches (promos, social, newsletters, large attachments, etc.), shows a live progress window, and supports Dry-Run, Cancel, tagging-before-delete, and options-based rules.

> Works best from a Gmail tab in Chrome (or Chromium-based browsers).  
> Store version: search **“Gmail One-Click Cleaner”** in the Chrome Web Store.

---

## Install (Developer Mode)

1. Download and unzip the project (or use the provided `.zip` and extract it).
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top-right).
4. Click **Load unpacked** and select the extension folder (the one containing `manifest.json`).
5. Pin the extension. Open Gmail, then click the extension icon and hit **Run cleanup**.

---

## How it works

- Injects a content script into the **Gmail tab you launched it from** (multi-account safe).
- Runs a fixed sequence of Gmail searches, like:
  - Promotions / Social / Updates / Forums
  - Old newsletters and no-reply mail
  - Very large / old attachments
- For each search it:
  - Opens the search in your existing Gmail tab
  - Selects matching conversations (including “Select all that match this search”)
  - **Live mode:** optionally tags matches, then deletes to Trash  
  - **Dry-Run:** counts matches only, no deletions
- A separate **Progress** page shows:
  - Current phase and percent complete
  - Per-query counts and durations
  - A live log of each step
  - Reconnect / Re-inject helpers if the connection to Gmail is lost

Internally it uses `chrome.scripting`, resilient selectors, and a capped number of passes per query to avoid infinite loops when Gmail behaves oddly.

---

## Features

- **Dry-Run mode**  
  See how many conversations *would* be deleted without touching your Trash.

- **Tag before Trash (live runs)**  
  When enabled, matching conversations are labeled (for example  
  `GmailCleaner - Promotions`, `GmailCleaner - Social`, etc.) **before** they’re moved to Trash, so you can search/audit them later.

- **Cancel mid-run**  
  Click **Cancel** and the cleaner stops within a few seconds.

- **Custom rule sets**  
  Edit the **Light**, **Normal**, and **Deep** query lists in the Options page.  
  Rules are stored in `chrome.storage.sync`, so they follow you across Chrome profiles where sync is enabled.

- **Safe by default**  
  Default rules focus on obvious low-value mail (old promos, social noise, large attachments).  
  There’s an optional **Skip Updates & Forums** toggle to leave receipts, order notifications, and some forum mail alone.

- **Multi-account aware**  
  Targets the Gmail account in the tab you clicked the extension from, even if you’re signed into multiple Gmail accounts.

---

## Customizing rules

Open the **Options** page from the popup and edit the text areas:

- One Gmail search query per line.
- Sections:
  - **Light** – very safe, big attachments + older obvious junk
  - **Normal** – recommended everyday cleanup
  - **Deep** – more aggressive on older promos / newsletters

Examples (on separate lines):

- `category:promotions older_than:6m`
- `category:social older_than:1y`
- `has:attachment larger:10M older_than:6m`
- `"unsubscribe" older_than:1y`
- `from:(no-reply@ OR donotreply@ OR "do-not-reply") older_than:6m`

---

## Privacy

- All logic runs locally in your browser.
- The extension does **not** send your email content or metadata to any external server.
- It only interacts with Gmail through the DOM and standard Gmail search queries.
