# Security Policy – Gmail One-Click Cleaner

Gmail One-Click Cleaner is a Chrome extension that automates safe Gmail searches and bulk deletes. It **never** exfiltrates email contents, attachments, or credentials.

This document explains how we think about security and how to report issues.

---

## Supported Versions

I aim to support the latest published version in the Chrome Web Store:

- **Stable:** Latest Web Store release (recommended)
- **Dev:** Current GitHub / unpacked version (best-effort support)

If you find a security issue in an older version, please confirm it still exists in the latest release before reporting.

---

## Data & Permissions

Gmail One-Click Cleaner:

- Uses `https://mail.google.com/*` host permissions to run in Gmail
- Uses `scripting` and `tabs` to inject the cleanup logic into your open Gmail tab
- Uses local storage for:
  - Cleanup intensity / rule settings
  - UI preferences (dry run, safe mode, etc.)

It **does not**:

- Send your emails or attachments to any external server
- Collect personal data for ads or analytics
- Store your Google credentials

All logic runs locally in your browser.

---

## How to Report a Vulnerability

If you believe you’ve found a security or privacy issue (for example, unexpected data access or a way to run arbitrary code):

1. **Do not** post full details publicly (reviews, Reddit, etc.).
2. Collect:
   - Extension version
   - Browser + version (e.g. Chrome 130 / Brave)
   - OS (e.g. Windows 11, macOS 15, Linux distro)
   - Exact steps to reproduce

3. Report it via:
   - **GitHub Issues:** Open a “Security” issue with a short, non-sensitive summary  
   - Or via the **Chrome Web Store support** tab with the same info

If the issue is high-impact, you can mention that it is *security-related* in the title so it gets prioritized.

---

## Responsible Disclosure

Please give a reasonable amount of time to investigate and fix the issue before sharing details publicly.

In general:

- I’ll try to acknowledge reports quickly.
- For serious issues, I’ll prioritize a fix and push a new version to the Web Store.
- Release notes / changelog entries will avoid leaking exploit details until users have had time to update.

---

## Hardening Suggestions & Feedback

If you have ideas to make Gmail One-Click Cleaner safer (better default rules, stricter permissions, threat scenarios I should consider), feel free to open an issue labeled **“enhancement”** or **“security hardening”**.

Thank you for helping keep users safe.
