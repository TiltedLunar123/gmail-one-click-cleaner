(async () => {
  "use strict";

  const API_ENDPOINT =
    "https://gmail-one-click-cleaner.vercel.app/api/check-license";

  const $ = (id) => document.getElementById(id);

  const RULE_KEYS = ["light", "normal", "deep"];

  const DEFAULT_RULES = {
    light: [
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "category:promotions older_than:1y",
      "category:social older_than:1y",
      "\"unsubscribe\" older_than:2y"
    ],
    normal: [
      "larger:20M",
      "has:attachment larger:10M older_than:6m",
      "has:attachment larger:5M older_than:2y",
      "category:promotions older_than:3m",
      "category:promotions older_than:1y",
      "category:social older_than:6m",
      "category:updates older_than:6m",
      "category:forums older_than:6m",
      "has:newsletter older_than:6m",
      "\"unsubscribe\" older_than:1y",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:6m"
    ],
    deep: [
      "larger:20M",
      "has:attachment larger:10M older_than:3m",
      "has:attachment larger:5M older_than:1y",
      "category:promotions older_than:2m",
      "category:promotions older_than:6m",
      "category:social older_than:3m",
      "category:social older_than:6m",
      "category:updates older_than:3m",
      "category:forums older_than:3m",
      "has:newsletter older_than:3m",
      "\"unsubscribe\" older_than:6m",
      "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:3m"
    ]
  };

  const state = {
    saving: false,
    activating: false
  };

  const clone = (obj) => {
    if (typeof structuredClone === "function") return structuredClone(obj);
    try {
      return JSON.parse(JSON.stringify(obj));
    } catch {
      return obj;
    }
  };

  const hasSyncStorage = () => {
    try {
      return (
        typeof chrome !== "undefined" &&
        chrome.storage &&
        chrome.storage.sync &&
        typeof chrome.storage.sync.get === "function" &&
        typeof chrome.storage.sync.set === "function"
      );
    } catch {
      return false;
    }
  };

  // ---- Rules ----

  function normalizeRules(rules) {
    if (!rules || typeof rules !== "object") return clone(DEFAULT_RULES);

    const out = { light: [], normal: [], deep: [] };

    for (const key of RULE_KEYS) {
      const source = Array.isArray(rules[key]) ? rules[key] : DEFAULT_RULES[key];
      out[key] = (source || []).filter(
        (line) => typeof line === "string" && line.trim().length
      );
    }

    return out;
  }

  function renderRules(rules) {
    if ($("light")) $("light").value = (rules.light || []).join("\n");
    if ($("normal")) $("normal").value = (rules.normal || []).join("\n");
    if ($("deep")) $("deep").value = (rules.deep || []).join("\n");
  }

  function readLines(id) {
    const el = $(id);
    if (!el) return [];
    return el.value
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
  }

  async function loadRules() {
    try {
      if (!hasSyncStorage()) {
        renderRules(clone(DEFAULT_RULES));
        return;
      }

      const { rules } = await chrome.storage.sync.get("rules");
      const normalized = normalizeRules(rules);
      renderRules(normalized);
    } catch (err) {
      console.error("[Gmail Cleaner] Failed to load rules, using defaults.", err);
      renderRules(clone(DEFAULT_RULES));
    }
  }

  async function saveRules(evt) {
    evt?.preventDefault?.();

    if (state.saving) return;
    state.saving = true;

    const btn = $("save");
    const originalLabel = btn ? btn.textContent : null;
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Saving...";
    }

    try {
      const rules = {
        light: readLines("light"),
        normal: readLines("normal"),
        deep: readLines("deep")
      };

      if (!hasSyncStorage()) {
        throw new Error("chrome.storage.sync is not available");
      }

      await chrome.storage.sync.set({ rules });
      alert("Rules saved.");
    } catch (err) {
      console.error("[Gmail Cleaner] Failed to save rules.", err);
      alert("Could not save rules. Please try again.");
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = originalLabel;
      }
      state.saving = false;
    }
  }

  // ---- Pro + lifetime stats ----

  function renderProLifetimeStats(stats) {
    const wrap = $("proLifetime");
    const body = $("proLifetimeBody");
    if (!wrap || !body) return;

    body.innerHTML = "";

    if (!stats || !stats.totalRuns) {
      wrap.hidden = true;
      return;
    }

    wrap.hidden = false;

    const chips = [
      ["Runs", stats.totalRuns || 0],
      ["Total deleted", stats.totalDeleted || 0],
      ["Total 'would delete' (dry)", stats.totalWouldDelete || 0],
      ["Total queries", stats.totalQueries || 0],
      ["Biggest single run", stats.biggestRun || 0]
    ];

    for (const [label, value] of chips) {
      const div = document.createElement("div");
      div.className = "pro-lifetime-chip";
      div.textContent = `${label}: ${Number(value || 0).toLocaleString()}`;
      body.appendChild(div);
    }
  }

  async function loadProStatus() {
    const statusEl = $("proStatus");
    const msgEl = $("proMessage");

    if (!statusEl || !hasSyncStorage()) return;

    try {
      const { proStatus, proLifetimeStats } = await chrome.storage.sync.get([
        "proStatus",
        "proLifetimeStats"
      ]);

      const isPro = !!(proStatus && proStatus.isPro);

      statusEl.textContent = isPro ? "Pro active" : "Free mode";

      if (msgEl) {
        msgEl.className = "";
        msgEl.textContent = "";
      }

      if (isPro) {
        renderProLifetimeStats(proLifetimeStats || null);
      } else {
        renderProLifetimeStats(null);
      }
    } catch (err) {
      console.error("[Gmail Cleaner] Failed to load pro status.", err);
    }
  }

  async function activatePro(evt) {
    evt?.preventDefault?.();

    if (state.activating) return;
    state.activating = true;

    const input = $("proLicense");
    const btn = $("proActivate");
    const statusEl = $("proStatus");
    const msgEl = $("proMessage");

    const rawKey = (input?.value || "").trim();

    if (!rawKey) {
      if (msgEl) {
        msgEl.className = "err";
        msgEl.textContent = "Paste your Gumroad license key first.";
      }
      state.activating = false;
      return;
    }

    if (!hasSyncStorage()) {
      if (msgEl) {
        msgEl.className = "err";
        msgEl.textContent =
          "chrome.storage.sync is not available in this context.";
      }
      state.activating = false;
      return;
    }

    if (btn) {
      btn.disabled = true;
      btn.textContent = "Checking…";
    }
    if (msgEl) {
      msgEl.className = "";
      msgEl.textContent = "";
    }

    try {
      const res = await fetch(API_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ licenseKey: rawKey })
      });

      if (!res.ok) {
        throw new Error(`Server error (${res.status})`);
      }

      const data = await res.json();

      if (!data.ok || !data.valid) {
        if (msgEl) {
          msgEl.className = "err";
          msgEl.textContent =
            data.reason || data.error || "License invalid or not recognized.";
        }

        await chrome.storage.sync.set({
          proStatus: {
            isPro: false,
            lastCheckAt: Date.now()
          }
        });

        await loadProStatus();
        return;
      }

      const proStatus = {
        isPro: true,
        email: data.email || null,
        licenseKeyLast4: data.licenseKeyLast4 || rawKey.slice(-4),
        lastCheckAt: Date.now(),
        source: "gumroad"
      };

      await chrome.storage.sync.set({ proStatus });

      if (statusEl) {
        statusEl.textContent = "Pro active";
      }
      if (msgEl) {
        msgEl.className = "ok";
        msgEl.textContent = `Pro unlocked for ${data.email || "your account"}.`;
      }

      await loadProStatus();
    } catch (err) {
      console.error("[Gmail Cleaner] License activation error:", err);
      if (msgEl) {
        msgEl.className = "err";
        msgEl.textContent =
          err?.message || "Could not reach the license server. Try again.";
      }
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Activate Pro";
      }
      state.activating = false;
    }
  }

  function init() {
    const saveBtn = $("save");
    if (saveBtn) {
      saveBtn.addEventListener("click", saveRules);
    }

    const proBtn = $("proActivate");
    if (proBtn) {
      proBtn.addEventListener("click", activatePro);
    }

    // Allow Enter in the license field to trigger activation.
    const licenseInput = $("proLicense");
    if (licenseInput) {
      licenseInput.addEventListener("keydown", (evt) => {
        if (evt.key === "Enter") {
          activatePro(evt);
        }
      });
    }

    loadRules();
    loadProStatus();
  }

  if (document.readyState === "loading") {
    window.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
