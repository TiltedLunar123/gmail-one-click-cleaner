# Changelog – Gmail One-Click Cleaner

All notable changes to this project will be documented in this file.  
This log tracks user-visible behavior, UI changes, and important internal fixes.

## 2.9.8

- Fixed issues when running in Brave and multi-Gmail setups:
  - Improved detection of the “active” Gmail tab so cleanup runs against the right account.
  - Reduced dependence on the extension docs / options tab being in focus.
- Hardened content script messaging and reconnection behavior when Gmail reloads mid-run.
- Small polish to the Progress window layout and copy.
- Internal refactors to keep progress logic, rule sets, and UI wiring in sync.

## 2.9.7

- Added a richer Progress window:
  - Live percent complete and current phase text.
  - A summary table with per-query counts and durations.
  - “Tags” area for showing current rule labels / hints.
- Added **Reconnect** and **Re-inject** buttons to recover from:
  - Gmail reloads
  - Lost content script connections
- Improved Cancel behavior:
  - Cancels the current phase cleanly.
  - Closes the progress session without leaving partial state.

## 2.9.6

- Introduced the **Tip / Support panel** in the Progress window:
  - Optional section explaining how to support the project (e.g. small tips).
  - Does not affect privacy or Gmail behavior.
- Tuned the Progress UI styling:
  - Darker background, softer card edges, and more readable text.
  - Better spacing on small windows.

## 2.9.5

- Added optional “tag before trash” behavior in the cleanup flow:
  - Before deleting, messages can be tagged with a dedicated Gmail label.
  - This makes it easier to search the Trash by that label and verify results.
- Internal changes to how rule metadata is passed from options → progress page.
- Minor logging clean-up and more defensive checks for missing DOM elements.

## 2.9.4

- Expanded the **cleanup rule system**:
  - Introduced three intensities: **Light**, **Normal**, **Aggressive**.
  - Each intensity uses its own array of safe Gmail queries (large attachments, promos, social, newsletters, etc.).
- Synced default rules between the options page and the run logic using a shared `DEFAULT_RULES` object.
- Adjusted some default queries to be safer:
  - Slightly older date thresholds for aggressive modes.
  - Clearer focus on bulk, low-value categories.

## 2.9.3

- New Progress window UI (HTML/CSS refresh):
  - Card-based layout with a single clear progress bar.
  - Status line, details text, and compact controls.
- Better error reporting when:
  - No Gmail tab is found.
  - The content script fails to attach.
- Slight performance improvements in how the extension advances between queries.

## 2.9.2

- Improved options page:
  - Cleaner descriptions of each rule set.
  - Safer defaults for new users.
- More robust handling of local storage:
  - Defaults are applied if settings are missing or invalid.
- Reduced redundant messages between popup → background → content scripts.

## 2.9.1

- Added **Safe Mode** toggle:
  - Runs only the safest, least risky rule subset.
  - Skips any “heavier” queries that might get too close to long-term history.
- Improved **Dry Run** behavior:
  - Ensures no destructive actions are taken when Dry Run is on.
  - Still drives the UI and progress screen so users can see what would happen.

## 2.9.0

- Major internal refactor of the run logic:
  - Centralized state management for phases, counts, and errors.
  - Clear separation between “rules” and “execution engine”.
- Better handling of Gmail rate limits and slower accounts:
  - Slight randomized delays between operations.
  - Reduced chance of hitting hard limits during long runs.

---

## 2.8.x

- Added support for more Gmail categories (Updates, Forums) in some rule sets.
- Tuned large-attachment filters (e.g. `larger:20M`, `has:attachment larger:10M older_than:6m`).
- Fixed occasional issues where “Select all conversations” was not clicked properly on some layouts.
- First iteration of the dark theme for the progress window.

---

## 2.7.x

- Introduced **Dry Run** mode for the first time:
  - Simulates the run without deleting messages.
  - Helpful for sanity-checking rules on big, old inboxes.
- Added basic error banners when Gmail layout does not match expected selectors.
- Minor UI cleanup on popup text and buttons.

---

## 2.6.x

- Improved handling when multiple Gmail accounts are open in the same browser session.
- Early support for non-Chrome Chromium browsers (Brave, Edge, etc.).
- Small optimizations to reduce flicker when switching between search queries.

---

## 2.5.x

- More robust detection of key Gmail buttons (search results, select-all, delete).
- Reduced chances of running with Gmail still loading or partially rendered.
- Light performance tweaks and code organization.

---

## 2.0.0 – MV3 Rewrite

- Migrated the extension to **Manifest V3**.
- Re-architected the extension around:
  - A service worker background script.
  - `chrome.scripting` for injecting the Gmail automation.
  - A dedicated Progress page to show run status.
- Added configurable options for future rule tuning.

---

## 1.x – Initial Releases

- First public release of **Gmail One-Click Cleaner**.
- Core feature:
  - Run a sequence of Gmail searches targeting bulk clutter:
    - Promotions
    - Social
    - Newsletters / marketing
    - Large attachments
  - Select all results and delete in bulk.
- Basic popup UI with a single **Run cleanup** button.
- Simple, local-only behavior with no external servers.

