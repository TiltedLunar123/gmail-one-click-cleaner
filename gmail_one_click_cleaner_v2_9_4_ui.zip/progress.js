(() => {
  const qs = new URLSearchParams(location.search);
  const gmailTabId = Number(qs.get("gmailTabId")) || null;

  const ui = {
    barInner: document.getElementById("barInner"),
    percentText: document.getElementById("percentText"),
    status: document.getElementById("status"),
    details: document.getElementById("details"),
    tags: document.getElementById("tags"),
    cancel: document.getElementById("cancelBtn"),
    reconnect: document.getElementById("reconnectBtn"),
    reinject: document.getElementById("reinjectBtn")
  };

  function setPercent(p) {
    const clamped = Math.max(0, Math.min(100, Math.round(p)));
    ui.barInner.style.width = clamped + "%";
    ui.percentText.textContent = clamped + "%";
  }
  function addLog(text) {
    const ts = new Date().toLocaleTimeString();
    const div = document.createElement("div");
    div.textContent = `[${ts}] ${text}`;
    ui.details.prepend(div);
  }
  function setPhase(ph) { ui.tags.textContent = ph || ""; }

  const summary = document.getElementById("summary");
  const table = document.getElementById("summaryTable");
  const tbody = table.querySelector("tbody");

  function ensureTable(){ table.style.display = ""; }
  function fmtMs(ms){ if(ms<1000) return ms+" ms"; const s=(ms/1000).toFixed(1); return s+" s"; }
  function addRow({label, mode, count, durationMs}){
    ensureTable();
    const tr = document.createElement("tr");
    const tdQ = document.createElement("td"); tdQ.textContent = label || "Query"; tr.appendChild(tdQ);
    const tdM = document.createElement("td"); tdM.textContent = mode === "dry" ? "Dry-Run" : "Live"; tr.appendChild(tdM);
    const tdC = document.createElement("td"); tdC.textContent = (count ?? 0).toLocaleString(); tr.appendChild(tdC);
    const tdD = document.createElement("td"); tdD.textContent = durationMs ? fmtMs(durationMs) : "—"; tr.appendChild(tdD);
    tbody.appendChild(tr);
  }
  function setKPIs({mode,totalDeleted,totalWouldDelete,totalQueries}){
    summary.innerHTML = "";
    const make = (t)=>{ const s=document.createElement("span"); s.className="pill"; s.textContent=t; return s; };
    summary.appendChild(make(`Mode: ${mode==="dry"?"Dry-Run":"Live"}`));
    summary.appendChild(make(`Queries: ${totalQueries}`));
    if(mode==="dry"){ summary.appendChild(make(`Would delete: ${(totalWouldDelete||0).toLocaleString()}`)); }
    else { summary.appendChild(make(`Deleted: ${(totalDeleted||0).toLocaleString()}`)); }
  }

  function addTrashButton(){
    const btn = document.createElement('button');
    btn.textContent = "Open Trash";
    btn.style.marginTop = "8px";
    btn.onclick = () => window.open("https://mail.google.com/mail/u/0/#trash", "_blank");
    document.querySelector('.panel').appendChild(btn);
  }

  function showTipPanel(stats){
    const panel = document.createElement("div");
    panel.style.marginTop = "12px";
    panel.style.padding = "14px";
    panel.style.border = "1px solid var(--border)";
    panel.style.borderRadius = "12px";
    panel.style.background = "rgba(255,255,255,0.04)";
    panel.setAttribute("role", "region");
    panel.setAttribute("aria-label", "Support");

    const saved = stats?.mode === "dry" ? (stats?.totalWouldDelete || 0) : (stats?.totalDeleted || 0);
    const h = document.createElement("div");
    h.style.fontWeight = "700";
    h.style.marginBottom = "6px";
    h.textContent = saved ? `Nice! ${saved.toLocaleString()} emails processed.` : "Nice! Cleanup complete.";
    panel.appendChild(h);

    const micro = document.createElement("div");
    micro.style.fontSize = "12px";
    micro.style.color = "var(--muted)";
    micro.style.marginBottom = "10px";
    micro.textContent = "If this saved you time, you can send a tip — it helps keep updates coming.";
    panel.appendChild(micro);

    const btn = document.createElement("button");
    btn.textContent = "Send a tip";
    btn.style.padding = "10px 14px";
    btn.style.borderRadius = "10px";
    btn.style.border = "1px solid var(--border)";
    btn.style.background = "#0b1220";
    btn.style.color = "#fff";
    btn.style.fontWeight = "600";
    btn.style.cursor = "pointer";
    btn.onclick = () => window.open("https://cash.app/$judeh1l", "_blank");
    panel.appendChild(btn);

    document.querySelector(".panel").appendChild(panel);
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.type !== "gmailCleanerProgress") return;
    if (typeof msg.percent === "number") setPercent(msg.percent);
    if (msg.status) ui.status.textContent = msg.status;
    if (msg.detail) addLog(msg.detail);
    if (msg.phase) setPhase(msg.phase);
    if (msg.phase === "query-done") { try { addRow(msg); } catch(e) {} }
    if (msg.done) {
      setPercent(100);
      ui.status.textContent = "Cleanup Complete";
      ui.cancel.disabled = true;
      addLog("Done.");
      addTrashButton();
      if (msg.stats) { setKPIs(msg.stats); showTipPanel(msg.stats); }
    }
  });

  ui.cancel.addEventListener("click", async () => {
    addLog("Cancel requested…");
    const targets = gmailTabId
      ? [{ id: gmailTabId }]
      : await chrome.tabs.query({ url: "https://mail.google.com/*" });

    for (const t of targets) {
      try {
        await chrome.tabs.sendMessage(t.id, { type: "gmailCleanerCancel" });
      } catch {}
    }
  });

  const reconnect = async () => {
    try {
      const res = await chrome.tabs.sendMessage(gmailTabId, { type: "gmailCleanerPing" });
      if (res && res.ok) { addLog("Connected to Gmail tab."); ui.status.textContent = "Connected"; return; }
      addLog("No response. You can try Re-inject.");
    } catch {
      addLog("Ping failed. Try Re-inject.");
    }
  };

  const reinject = async () => {
    try {
      let storeCfg = null; try { storeCfg = (await chrome.storage.session.get("lastConfig")).lastConfig; } catch {}
      if (!storeCfg) { try { storeCfg = (await chrome.storage.local.get("lastConfig")).lastConfig; } catch {} }
      const lastConfig = storeCfg;
      if (!lastConfig) { addLog("No last config found. Run from popup again."); return; }

      await chrome.scripting.executeScript({
        target: { tabId: gmailTabId },
        func: (cfg) => { window.GMAIL_CLEANER_CONFIG = cfg; },
        args: [ lastConfig ]
      });
      await chrome.scripting.executeScript({
        target: { tabId: gmailTabId },
        files: ["contentScript.js"]
      });
      addLog("Re-injected content script.");
    } catch (e) {
      addLog("Re-inject failed: " + (e?.message || e));
    }
  };

  // Toggle logs
  try {
    document.getElementById("toggleLogs").addEventListener("click", () => {
      const d = document.getElementById("details");
      const t = document.getElementById("summaryTable");
      if (!d || !t) return;
      const isHidden = d.style.display === "none";
      d.style.display = isHidden ? "" : "none";
      t.style.display = isHidden ? "" : "none";
    });
  } catch {}

  setTimeout(reconnect, 800);
  ui.reconnect.addEventListener("click", reconnect);
  ui.reinject.addEventListener("click", reinject);
})();