(() => {
  "use strict";

  // =========================
  // Constants & Configuration
  // =========================

  const DIAGNOSTICS_VERSION = "3.3.0";

  const CONFIG = Object.freeze({
    MAX_URL_LENGTH: 120,
    MAX_LOG_ENTRIES: 150,
    TOAST_DURATION_MS: 3000,
    LOADING_CLASS: "loading",
    BUTTON_LOADING_CLASS: "loading",
    SW_PING_TIMEOUT_MS: 1200
  });

  const SELECTORS = Object.freeze({
    envBrowser: "envBrowser",
    envPlatform: "envPlatform",
    envExtension: "envExtension",
    envPerms: "envPerms",
    envServiceWorker: "envServiceWorker",
    envTabStrategy: "envTabStrategy",
    envStatusTag: "envStatusTag",

    tabCount: "gmailTabCount",
    tabTableBody: "gmailTabTableBody",

    chosenTabText: "chosenTabText",
    chosenTabTextInline: "chosenTabTextInline",
    cleanerTabText: "cleanerTabText",
    cleanerTabTextInline: "cleanerTabTextInline",

    scanTabsBtn: "scanTabsBtn",
    testInjectBtn: "testInjectBtn",
    pingSwBtn: "pingSwBtn",

    log: "log",
    diagVersionBadge: "diagVersionBadge",

    lastRunSummary: "lastRunSummary",
    lastRunMeta: "lastRunMeta",
    lastRunBucketTag: "lastRunBucketTag",
    lastRunButtons: "lastRunButtons",

    runHistoryTableBody: "runHistoryTableBody",

    copyLogBtn: "copyLogBtn",
    clearLogBtn: "clearLogBtn",

    toastContainer: ".toast-container"
  });

  const TAG_CLASSES = Object.freeze({
    dry: "tag tag-info",
    archive: "tag tag-success",
    delete: "tag tag-danger",
    default: "tag tag-primary"
  });

  // =========================
  // Utility Functions
  // =========================

  const getEl = (id) => document.getElementById(id);

  const qs = (selector) => {
    try {
      return document.querySelector(selector);
    } catch {
      return null;
    }
  };

  const truncate = (str, maxLength = CONFIG.MAX_URL_LENGTH) => {
    if (typeof str !== "string") return "";
    return str.length > maxLength ? str.slice(0, maxLength - 3) + "..." : str;
  };

  const escapeHtml = (str) => {
    if (typeof str !== "string") return "";
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  };

  const formatNumber = (num) => {
    if (typeof num !== "number" || !Number.isFinite(num)) return "0";
    return num.toLocaleString();
  };

  const formatDate = (timestamp) => {
    if (typeof timestamp !== "number" || !Number.isFinite(timestamp)) {
      return "(time not recorded)";
    }
    try {
      return new Date(timestamp).toLocaleString();
    } catch {
      return "(invalid date)";
    }
  };

  const hasChromeRuntime = () => {
    try {
      return typeof chrome !== "undefined" && !!chrome.runtime;
    } catch {
      return false;
    }
  };

  const hasChromeTabs = () => {
    try {
      return typeof chrome !== "undefined" && !!chrome.tabs;
    } catch {
      return false;
    }
  };

  const hasChromeStorage = (type = "sync") => {
    try {
      return (
        typeof chrome !== "undefined" &&
        chrome?.storage?.[type] &&
        typeof chrome.storage[type].get === "function"
      );
    } catch {
      return false;
    }
  };

  const hasChromeScripting = () => {
    try {
      return typeof chrome !== "undefined" && !!chrome.scripting;
    } catch {
      return false;
    }
  };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // =========================
  // Promisified Chrome APIs (compat-safe)
  // =========================

  const tabsQuery = (queryInfo) =>
    new Promise((resolve, reject) => {
      try {
        chrome.tabs.query(queryInfo, (tabs) => {
          const err = chrome.runtime?.lastError;
          if (err) return reject(new Error(err.message || "tabs.query failed"));
          resolve(Array.isArray(tabs) ? tabs : []);
        });
      } catch (e) {
        reject(e);
      }
    });

  const storageGet = (area, keys) =>
    new Promise((resolve, reject) => {
      try {
        chrome.storage[area].get(keys, (result) => {
          const err = chrome.runtime?.lastError;
          if (err) return reject(new Error(err.message || "storage.get failed"));
          resolve(result || {});
        });
      } catch (e) {
        reject(e);
      }
    });

  const executeScript = (details) =>
    new Promise((resolve, reject) => {
      try {
        chrome.scripting.executeScript(details, (results) => {
          const err = chrome.runtime?.lastError;
          if (err) return reject(new Error(err.message || "executeScript failed"));
          resolve(Array.isArray(results) ? results : []);
        });
      } catch (e) {
        reject(e);
      }
    });

  const sendRuntimeMessage = (message) =>
    new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(message, (resp) => {
          const err = chrome.runtime?.lastError;
          if (err) return reject(new Error(err.message || "sendMessage failed"));
          resolve(resp);
        });
      } catch (e) {
        reject(e);
      }
    });

  // =========================
  // DOM Element Cache
  // =========================

  const elements = {
    envBrowser: getEl(SELECTORS.envBrowser),
    envPlatform: getEl(SELECTORS.envPlatform),
    envExtension: getEl(SELECTORS.envExtension),
    envPerms: getEl(SELECTORS.envPerms),
    envServiceWorker: getEl(SELECTORS.envServiceWorker),
    envTabStrategy: getEl(SELECTORS.envTabStrategy),
    envStatusTag: getEl(SELECTORS.envStatusTag),

    tabCount: getEl(SELECTORS.tabCount),
    tabTableBody: getEl(SELECTORS.tabTableBody),

    chosenTabText: getEl(SELECTORS.chosenTabText),
    chosenTabTextInline: getEl(SELECTORS.chosenTabTextInline),
    cleanerTabText: getEl(SELECTORS.cleanerTabText),
    cleanerTabTextInline: getEl(SELECTORS.cleanerTabTextInline),

    scanTabsBtn: getEl(SELECTORS.scanTabsBtn),
    testInjectBtn: getEl(SELECTORS.testInjectBtn),
    pingSwBtn: getEl(SELECTORS.pingSwBtn),

    log: getEl(SELECTORS.log),
    diagVersionBadge: getEl(SELECTORS.diagVersionBadge),

    lastRunSummary: getEl(SELECTORS.lastRunSummary),
    lastRunMeta: getEl(SELECTORS.lastRunMeta),
    lastRunBucketTag: getEl(SELECTORS.lastRunBucketTag),
    lastRunButtons: getEl(SELECTORS.lastRunButtons),

    runHistoryTableBody: getEl(SELECTORS.runHistoryTableBody),

    copyLogBtn: getEl(SELECTORS.copyLogBtn),
    clearLogBtn: getEl(SELECTORS.clearLogBtn),

    toastContainer: qs(SELECTORS.toastContainer)
  };

  // =========================
  // Toast Notifications
  // =========================

  const showToast = (message, type = "info", duration = CONFIG.TOAST_DURATION_MS) => {
    const container = elements.toastContainer;
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    toast.setAttribute("role", "alert");

    container.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add("show"));

    setTimeout(() => {
      toast.classList.remove("show");
      setTimeout(() => {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 250);
    }, duration);
  };

  // =========================
  // Logging System
  // =========================

  const logHistory = [];

  const getTimestamp = () => {
    const now = new Date();
    return now.toLocaleTimeString("en-US", {
      hour12: false,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
  };

  const addLog = (text, level = "info") => {
    if (!elements.log) return;

    const timestamp = getTimestamp();
    const entry = `[${timestamp}] ${text}`;

    logHistory.push(entry);
    if (logHistory.length > CONFIG.MAX_LOG_ENTRIES) logHistory.shift();

    const entryEl = document.createElement("div");
    entryEl.className = `log-entry log-${level}`;

    const timestampSpan = document.createElement("span");
    timestampSpan.className = "log-timestamp";
    timestampSpan.textContent = `[${timestamp}]`;

    entryEl.appendChild(timestampSpan);
    entryEl.appendChild(document.createTextNode(` ${text}`));

    elements.log.appendChild(entryEl);
    elements.log.scrollTop = elements.log.scrollHeight;
  };

  const setLog = (text, level = "info") => {
    if (!elements.log) return;
    elements.log.innerHTML = "";
    logHistory.length = 0;
    if (text) addLog(text, level);
  };

  const clearLog = () => {
    if (!elements.log) return;
    elements.log.innerHTML = "";
    logHistory.length = 0;
    showToast("Log cleared", "info");
  };

  const copyLog = async () => {
    if (logHistory.length === 0) {
      showToast("No logs to copy", "warning");
      return;
    }

    const content = logHistory.join("\n");

    try {
      await navigator.clipboard.writeText(content);
      showToast("Log copied to clipboard", "success");
      return;
    } catch {
      // fallback
    }

    try {
      const textarea = document.createElement("textarea");
      textarea.value = content;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      showToast("Log copied to clipboard", "success");
    } catch {
      showToast("Failed to copy log", "error");
    }
  };

  // =========================
  // Button State Management
  // =========================

  const setButtonLoading = (btn, loading) => {
    if (!btn) return;
    btn.disabled = loading;

    if (loading) {
      btn.classList.add(CONFIG.BUTTON_LOADING_CLASS);
      btn.setAttribute("aria-busy", "true");
    } else {
      btn.classList.remove(CONFIG.BUTTON_LOADING_CLASS);
      btn.removeAttribute("aria-busy");
    }
  };

  const removeLoadingSkeleton = (el) => {
    if (!el) return;
    el.classList.remove(CONFIG.LOADING_CLASS);
  };

  const setEnvStatus = (text, kind = "primary") => {
    if (!elements.envStatusTag) return;
    elements.envStatusTag.textContent = text;
    elements.envStatusTag.className = `tag tag-${kind}`;
  };

  // =========================
  // Environment Rendering
  // =========================

  const getBrowserInfo = () => {
    const ua = navigator.userAgent || "";
    if (ua.includes("Edg/")) {
      const match = ua.match(/Edg\/([\d.]+)/);
      return match ? `Edge ${match[1]}` : "Edge";
    }
    if (ua.includes("Chrome/")) {
      const match = ua.match(/Chrome\/([\d.]+)/);
      return match ? `Chrome ${match[1]}` : "Chrome";
    }
    if (ua.includes("Firefox/")) {
      const match = ua.match(/Firefox\/([\d.]+)/);
      return match ? `Firefox ${match[1]}` : "Firefox";
    }
    if (ua.includes("Safari") && !ua.includes("Chrome")) {
      const match = ua.match(/Version\/([\d.]+)/);
      return match ? `Safari ${match[1]}` : "Safari";
    }
    return ua || "(unknown)";
  };

  const getPlatformInfo = () => {
    if (navigator.userAgentData?.platform) return navigator.userAgentData.platform;
    return navigator.platform || "(unknown)";
  };

  const getManifestInfo = () => {
    try {
      if (!hasChromeRuntime()) return null;
      const manifest = chrome.runtime.getManifest();
      return {
        name: manifest.name || "Gmail One-Click Cleaner",
        version: manifest.version_name || manifest.version || "?"
      };
    } catch {
      return null;
    }
  };

  const getPermissions = () => {
    try {
      if (!hasChromeRuntime()) return [];
      const manifest = chrome.runtime.getManifest();
      const permissions = Array.isArray(manifest.permissions) ? manifest.permissions : [];
      const hostPermissions = Array.isArray(manifest.host_permissions) ? manifest.host_permissions : [];
      return [...permissions, ...hostPermissions];
    } catch {
      return [];
    }
  };

  const renderEnv = async () => {
    // Browser
    if (elements.envBrowser) {
      elements.envBrowser.textContent = getBrowserInfo();
      removeLoadingSkeleton(elements.envBrowser);
    }

    // Platform
    if (elements.envPlatform) {
      elements.envPlatform.textContent = getPlatformInfo();
      removeLoadingSkeleton(elements.envPlatform);
    }

    // Extension info
    const manifestInfo = getManifestInfo();
    if (elements.envExtension) {
      if (manifestInfo) {
        elements.envExtension.textContent = `${manifestInfo.name} – v${manifestInfo.version}`;
      } else {
        elements.envExtension.textContent = "Gmail One-Click Cleaner – (runtime unavailable)";
      }
      removeLoadingSkeleton(elements.envExtension);
    }

    // Version badge
    if (elements.diagVersionBadge) {
      if (manifestInfo) elements.diagVersionBadge.textContent = `v${manifestInfo.version} snapshot`;
      else elements.diagVersionBadge.textContent = `v${DIAGNOSTICS_VERSION} snapshot`;
    }

    // Permissions
    if (elements.envPerms) {
      const perms = getPermissions();
      elements.envPerms.textContent = perms.length > 0 ? perms.join(", ") : "(none or unavailable)";
      removeLoadingSkeleton(elements.envPerms);
    }

    // Tab strategy (best-effort; falls back to default)
    const strategy = await detectTabStrategy().catch(() => ({
      strategy: "active",
      enabled: false,
      source: "default"
    }));

    if (elements.envTabStrategy) {
      elements.envTabStrategy.textContent =
        strategy.strategy === "dedicated"
          ? `Dedicated cleaning tab preferred (${strategy.source})`
          : `Active Gmail tab preferred (${strategy.source})`;
      removeLoadingSkeleton(elements.envTabStrategy);
    }

    // Service worker health (best-effort)
    const sw = await pingServiceWorker(true).catch((e) => ({ ok: false, detail: e?.message || "error" }));
    if (elements.envServiceWorker) {
      elements.envServiceWorker.textContent = sw.ok ? "Responsive" : `No response (${sw.detail})`;
      removeLoadingSkeleton(elements.envServiceWorker);
    }

    // Overall env status
    const okRuntime = hasChromeRuntime();
    const okTabs = hasChromeTabs();
    const okScript = hasChromeScripting();

    if (!okRuntime) {
      setEnvStatus("runtime missing", "danger");
    } else if (!okTabs) {
      setEnvStatus("tabs api missing", "warning");
    } else if (!okScript) {
      setEnvStatus("scripting missing", "warning");
    } else {
      setEnvStatus("ready", "success");
    }
  };

  // =========================
  // Service Worker Ping
  // =========================

  const pingServiceWorker = async (quiet = false) => {
    if (!hasChromeRuntime()) return { ok: false, detail: "runtime unavailable" };

    const pingMsg = {
      type: "__gcc_diagnostics_ping__",
      ts: Date.now(),
      v: DIAGNOSTICS_VERSION
    };

    try {
      const resp = await Promise.race([
        sendRuntimeMessage(pingMsg),
        (async () => {
          await sleep(CONFIG.SW_PING_TIMEOUT_MS);
          throw new Error("timeout");
        })()
      ]);

      const ok =
        resp &&
        (resp.ok === true ||
          resp.type === "__gcc_diagnostics_pong__" ||
          resp.pong === true);

      return { ok: !!ok, detail: ok ? "pong" : "unexpected response" };
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (!quiet) addLog(`Service worker ping failed: ${msg}`, "error");
      return { ok: false, detail: msg };
    }
  };

  // =========================
  // Tab Strategy Detection (best-effort)
  // =========================

  const detectTabStrategy = async () => {
    // default behavior: active tab in current window
    if (!hasChromeStorage("sync")) {
      return { strategy: "active", enabled: false, source: "default" };
    }

    // we don't know your exact settings keys, so we probe common ones safely
    const keys = [
      "useDedicatedCleaningTab",
      "runInDedicatedTab",
      "dedicatedTabEnabled",
      "preferDedicatedTab",
      "useCleanerTab",
      "openDedicatedTab",
      "dedicatedGmailTabEnabled",
      "dedicatedGmailTab"
    ];

    const res = await storageGet("sync", keys).catch(() => ({}));

    let enabled = null;
    let source = "default";

    for (const k of keys) {
      if (typeof res?.[k] === "boolean") {
        enabled = res[k];
        source = k;
        break;
      }
      // allow string flags like "true"/"false" (bad data but happens)
      if (typeof res?.[k] === "string" && (res[k] === "true" || res[k] === "false")) {
        enabled = res[k] === "true";
        source = k;
        break;
      }
    }

    if (enabled === true) return { strategy: "dedicated", enabled: true, source };
    return { strategy: "active", enabled: false, source };
  };

  // =========================
  // Last Run Stats
  // =========================

  const getRunCount = (stats) => {
    if (!stats) return 0;
    if (typeof stats.runCount === "number") return stats.runCount;
    return stats.mode === "dry" ? (stats.totalWouldDelete || 0) : (stats.totalDeleted || 0);
  };

  const getActionWord = (stats) => {
    if (!stats) return "affected";
    if (stats.mode === "dry") return "would affect";
    return stats.archiveInsteadOfDelete ? "archived" : "deleted";
  };

  const getModeLabel = (stats) => {
    if (!stats) return "Unknown";
    if (stats.mode === "dry") return "Dry Run";
    return stats.archiveInsteadOfDelete ? "Archive" : "Delete";
  };

  const getTagClass = (stats) => {
    if (!stats) return TAG_CLASSES.default;
    if (stats.mode === "dry") return TAG_CLASSES.dry;
    return stats.archiveInsteadOfDelete ? TAG_CLASSES.archive : TAG_CLASSES.delete;
  };

  const applyLastRunToDom = (stats) => {
    if (!elements.lastRunSummary && !elements.lastRunMeta && !elements.lastRunBucketTag && !elements.lastRunButtons) {
      return;
    }

    if (!stats) {
      if (elements.lastRunSummary) elements.lastRunSummary.textContent = "No cleanup runs recorded yet in this browser.";
      if (elements.lastRunMeta) elements.lastRunMeta.textContent = "";
      if (elements.lastRunBucketTag) {
        elements.lastRunBucketTag.textContent = "no runs";
        elements.lastRunBucketTag.className = "tag";
      }
      if (elements.lastRunButtons) elements.lastRunButtons.innerHTML = "";
      return;
    }

    const mode = stats.mode === "dry" ? "preview (dry run)" : "live cleanup";
    const runCount = getRunCount(stats);
    const sizeBucket = stats.sizeBucket || "tiny";
    const totalQueries = typeof stats.totalQueries === "number" ? stats.totalQueries : "?";
    const actionWord = getActionWord(stats);
    const finishedText = formatDate(stats.finishedAt ?? null);

    let freedMbText = "";
    if (typeof stats.totalFreedMb === "number" && stats.mode !== "dry") {
      if (stats.totalFreedMb < 0.1 && stats.totalFreedMb > 0) freedMbText = "< 0.1 MB";
      else freedMbText = `${stats.totalFreedMb.toFixed(1)} MB`;
    } else {
      freedMbText = sizeBucket;
    }

    if (elements.lastRunSummary) {
      elements.lastRunSummary.textContent = `Last run: ${mode}, ${formatNumber(runCount)} conversations ${actionWord}.`;
    }

    if (elements.lastRunMeta) {
      elements.lastRunMeta.textContent = `Queries: ${totalQueries} • Freed: ${freedMbText} • Finished: ${finishedText}`;
    }

    if (elements.lastRunBucketTag) {
      elements.lastRunBucketTag.textContent = sizeBucket;
      elements.lastRunBucketTag.className = sizeBucket !== "tiny" ? "tag tag-primary" : "tag";
    }

    if (elements.lastRunButtons) {
      elements.lastRunButtons.innerHTML = "";
      const links = stats.links || {};

      if (links.trash) {
        const trashBtn = document.createElement("a");
        trashBtn.href = links.trash;
        trashBtn.target = "_blank";
        trashBtn.rel = "noopener noreferrer";
        trashBtn.textContent = "🗑️ Open Trash";
        trashBtn.className = "button-link";
        trashBtn.setAttribute("aria-label", "Open Gmail Trash (opens in new tab)");
        elements.lastRunButtons.appendChild(trashBtn);
      }

      if (links.allMail) {
        const allMailBtn = document.createElement("a");
        allMailBtn.href = links.allMail;
        allMailBtn.target = "_blank";
        allMailBtn.rel = "noopener noreferrer";
        allMailBtn.textContent = "📬 Open All Mail";
        allMailBtn.className = "button-link btn-ghost";
        allMailBtn.setAttribute("aria-label", "Open Gmail All Mail (opens in new tab)");
        elements.lastRunButtons.appendChild(allMailBtn);
      }
    }
  };

  const renderLastRunFromStorage = async () => {
    if (!hasChromeStorage("sync")) return;
    try {
      const result = await storageGet("sync", ["lastRunStats"]);
      applyLastRunToDom(result?.lastRunStats ?? null);
    } catch (err) {
      console.warn("[Diagnostics] Failed to load last run stats:", err);
    }
  };

  // =========================
  // Run History
  // =========================

  const createHistoryRow = (run) => {
    const row = document.createElement("tr");
    const count = getRunCount(run);

    const dateCell = document.createElement("td");
    dateCell.className = "mono small";
    dateCell.textContent = formatDate(run.finishedAt ?? null);

    const modeCell = document.createElement("td");
    const modeTag = document.createElement("span");
    modeTag.className = getTagClass(run);
    modeTag.textContent = getModeLabel(run);
    modeCell.appendChild(modeTag);

    const countCell = document.createElement("td");
    countCell.className = "mono";
    countCell.textContent = formatNumber(count);

    const queriesCell = document.createElement("td");
    queriesCell.className = "mono";
    queriesCell.textContent = `${run.totalQueries ?? "?"} queries`;

    const sizeCell = document.createElement("td");
    sizeCell.className = "small muted";

    let mbText = "-";
    if (typeof run.totalFreedMb === "number") {
      if (run.totalFreedMb < 0.1 && run.totalFreedMb > 0) mbText = "<0.1 MB";
      else mbText = `${run.totalFreedMb.toFixed(1)} MB`;
    } else if (run.sizeBucket) {
      mbText = run.sizeBucket;
    }
    sizeCell.textContent = mbText;

    row.appendChild(dateCell);
    row.appendChild(modeCell);
    row.appendChild(countCell);
    row.appendChild(queriesCell);
    row.appendChild(sizeCell);

    return row;
  };

  const createEmptyHistoryRow = (message) => {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 5;
    cell.className = "table-empty";
    cell.innerHTML = `
      <div class="table-empty-icon" aria-hidden="true">📋</div>
      <div>${escapeHtml(message)}</div>
    `;
    row.appendChild(cell);
    return row;
  };

  const renderRunHistory = async () => {
    if (!elements.runHistoryTableBody) return;

    if (!hasChromeStorage("local")) {
      elements.runHistoryTableBody.innerHTML = "";
      elements.runHistoryTableBody.appendChild(createEmptyHistoryRow("Storage unavailable"));
      return;
    }

    try {
      const result = await storageGet("local", ["runHistory"]);
      const history = Array.isArray(result?.runHistory) ? result.runHistory : [];

      elements.runHistoryTableBody.innerHTML = "";

      if (history.length === 0) {
        elements.runHistoryTableBody.appendChild(
          createEmptyHistoryRow("No history recorded yet. Run a cleanup to see history here.")
        );
        return;
      }

      const sorted = [...history].sort((a, b) => (b.finishedAt ?? 0) - (a.finishedAt ?? 0));

      const fragment = document.createDocumentFragment();
      for (const run of sorted.slice(0, 10)) fragment.appendChild(createHistoryRow(run));
      elements.runHistoryTableBody.appendChild(fragment);
    } catch (err) {
      console.error("[Diagnostics] Failed to render history:", err);
      elements.runHistoryTableBody.innerHTML = "";
      elements.runHistoryTableBody.appendChild(createEmptyHistoryRow("Failed to load history"));
    }
  };

  // =========================
  // Gmail Tab Detection
  // =========================

  const isGmailUrl = (url) => typeof url === "string" && url.startsWith("https://mail.google.com/");

  const findGmailTab = async () => {
    if (!hasChromeTabs()) {
      addLog("chrome.tabs is not available in this context.", "error");
      return null;
    }

    try {
      const activeTabs = await tabsQuery({ active: true, currentWindow: true });
      const activeTab = activeTabs?.[0] || null;

      if (activeTab?.id && isGmailUrl(activeTab.url)) return activeTab;

      const tabsInWindow = await tabsQuery({ url: "https://mail.google.com/*", currentWindow: true });
      if (tabsInWindow?.length) {
        const active = tabsInWindow.find((t) => t.active);
        return active || tabsInWindow[0];
      }

      const allTabs = await tabsQuery({ url: "https://mail.google.com/*" });
      if (!allTabs?.length) return null;

      const activeAnywhere = allTabs.find((t) => t.active);
      return activeAnywhere || allTabs[0];
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      addLog(`Error finding Gmail tab: ${message}`, "error");
      return null;
    }
  };

  const computeCleanerTabCandidate = (tabs, chosenTab, strategy) => {
    // If dedicated strategy is enabled, prefer a non-active Gmail tab in the same window.
    if (strategy?.strategy === "dedicated" && chosenTab?.windowId != null) {
      const sameWindow = tabs.filter((t) => t.windowId === chosenTab.windowId);
      const nonActive = sameWindow.find((t) => !t.active && isGmailUrl(t.url));
      return nonActive || chosenTab || null;
    }
    // Otherwise: cleaner tab = chosen tab
    return chosenTab || null;
  };

  const createTabRow = (tab) => {
    const row = document.createElement("tr");

    const idCell = document.createElement("td");
    idCell.textContent = String(tab.id ?? "?");
    idCell.className = "mono";

    const winCell = document.createElement("td");
    winCell.textContent = String(tab.windowId ?? "?");
    winCell.className = "mono";

    const actCell = document.createElement("td");
    if (tab.active) {
      const activeBadge = document.createElement("span");
      activeBadge.className = "tag tag-success";
      activeBadge.textContent = "yes";
      actCell.appendChild(activeBadge);
    } else {
      actCell.textContent = "no";
      actCell.className = "muted";
    }

    const urlCell = document.createElement("td");
    urlCell.textContent = truncate(tab.url || "(unknown)");
    urlCell.className = "mono";
    urlCell.title = tab.url || "";

    row.appendChild(idCell);
    row.appendChild(winCell);
    row.appendChild(actCell);
    row.appendChild(urlCell);

    return row;
  };

  const createEmptyTabRow = (message) => {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 4;
    cell.className = "table-empty";
    cell.innerHTML = `
      <div class="table-empty-icon" aria-hidden="true">📧</div>
      <div>${escapeHtml(message)}</div>
    `;
    row.appendChild(cell);
    return row;
  };

  const setChosenAndCleanerText = (chosen, cleaner) => {
    const chosenText = chosen?.id
      ? `Tab ${chosen.id} in window ${chosen.windowId} – ${truncate(chosen.url || "", 100)}`
      : "None – not computed yet.";

    const cleanerText = cleaner?.id
      ? `Tab ${cleaner.id} in window ${cleaner.windowId} – ${truncate(cleaner.url || "", 100)}`
      : "None – not computed yet.";

    if (elements.chosenTabText) elements.chosenTabText.textContent = chosenText;
    if (elements.chosenTabTextInline) elements.chosenTabTextInline.textContent = chosen?.id ? `${chosen.id}` : "none";

    if (elements.cleanerTabText) elements.cleanerTabText.textContent = cleanerText;
    if (elements.cleanerTabTextInline) elements.cleanerTabTextInline.textContent = cleaner?.id ? `${cleaner.id}` : "none";
  };

  const scanTabs = async () => {
    if (!hasChromeTabs()) {
      setLog("chrome.tabs is not available in this context.", "error");
      showToast("Tab API unavailable", "error");
      return;
    }

    setButtonLoading(elements.scanTabsBtn, true);
    setButtonLoading(elements.testInjectBtn, true);

    addLog("Scanning for Gmail tabs...", "info");

    try {
      const tabs = await tabsQuery({ url: "https://mail.google.com/*" });

      if (elements.tabCount) elements.tabCount.textContent = String(tabs.length);

      if (elements.tabTableBody) {
        elements.tabTableBody.innerHTML = "";
        if (tabs.length === 0) {
          elements.tabTableBody.appendChild(createEmptyTabRow("No Gmail tabs found. Open Gmail and try again."));
        } else {
          const fragment = document.createDocumentFragment();
          for (const tab of tabs) fragment.appendChild(createTabRow(tab));
          elements.tabTableBody.appendChild(fragment);
        }
      }

      if (tabs.length === 0) {
        if (elements.chosenTabText) {
          elements.chosenTabText.textContent = "None – no Gmail tabs detected.";
          elements.chosenTabText.className = "env-value mono text-warning";
        }
        if (elements.cleanerTabText) {
          elements.cleanerTabText.textContent = "None – no Gmail tabs detected.";
          elements.cleanerTabText.className = "env-value mono text-warning";
        }
        if (elements.chosenTabTextInline) elements.chosenTabTextInline.textContent = "none";
        if (elements.cleanerTabTextInline) elements.cleanerTabTextInline.textContent = "none";

        addLog("No Gmail tabs found.", "warning");
        showToast("No Gmail tabs found", "warning");
        return;
      }

      const chosen = await findGmailTab();
      const strategy = await detectTabStrategy().catch(() => ({ strategy: "active", enabled: false, source: "default" }));
      const cleaner = computeCleanerTabCandidate(tabs, chosen, strategy);

      if (!chosen) {
        if (elements.chosenTabText) {
          elements.chosenTabText.textContent = "None – detection failed even though Gmail tabs exist.";
          elements.chosenTabText.className = "env-value mono text-danger";
        }
        addLog("Gmail tabs exist, but tab detection returned null.", "error");
        showToast("Tab detection failed", "error");
        return;
      }

      // Update main chosen text style
      if (elements.chosenTabText) elements.chosenTabText.className = "env-value mono text-success";
      if (elements.cleanerTabText) elements.cleanerTabText.className = "env-value mono";

      setChosenAndCleanerText(chosen, cleaner);

      addLog(`Detection OK. Popup tab: ${chosen.id} (win ${chosen.windowId}).`, "success");
      addLog(
        strategy.strategy === "dedicated"
          ? `Cleaner strategy: dedicated tab preferred (${strategy.source}). Cleaner tab: ${cleaner?.id ?? "none"}.`
          : `Cleaner strategy: active tab preferred (${strategy.source}).`,
        "info"
      );

      showToast(`Found ${tabs.length} Gmail tab(s)`, "success");
      setButtonLoading(elements.testInjectBtn, false);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      addLog(`Failed to query tabs: ${message}`, "error");
      showToast("Tab scan failed", "error");
    } finally {
      setButtonLoading(elements.scanTabsBtn, false);
    }
  };

  const testInject = async () => {
    if (!hasChromeScripting() || !hasChromeTabs() || !hasChromeRuntime()) {
      setLog("chrome.scripting is not available in this context.", "error");
      showToast("Scripting API unavailable", "error");
      return;
    }

    setButtonLoading(elements.testInjectBtn, true);
    addLog("Attempting to inject diagnostic script...", "info");

    try {
      const tab = await findGmailTab();
      if (!tab?.id) {
        addLog("No Gmail tab available for injection.", "warning");
        showToast("No Gmail tab available", "warning");
        return;
      }

      const results = await executeScript({
        target: { tabId: tab.id },
        func: () => {
          const now = new Date().toISOString();
          console.log("[GmailCleaner][Diagnostics] Inject ping at", now, "URL:", location.href);
          return {
            title: document.title,
            href: location.href,
            time: now,
            attached: !!window.__GCC_ATTACHED__
          };
        }
      });

      const payload = results?.[0]?.result ?? null;

      if (payload) {
        addLog(`Inject succeeded into tab ${tab.id}:`, "success");
        addLog(JSON.stringify(payload, null, 2), "info");
        showToast(payload.attached ? "Content script already attached" : "Inject successful", "success");
      } else {
        addLog(`Inject completed but returned no data for tab ${tab.id}`, "warning");
        showToast("Inject completed (no data)", "warning");
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      addLog(`Inject failed: ${message}`, "error");
      showToast("Inject failed", "error");
    } finally {
      setButtonLoading(elements.testInjectBtn, false);
    }
  };

  // =========================
  // Event Listeners
  // =========================

  const setupEventListeners = () => {
    elements.scanTabsBtn?.addEventListener("click", () => scanTabs().catch(console.error));
    elements.testInjectBtn?.addEventListener("click", () => testInject().catch(console.error));

    elements.pingSwBtn?.addEventListener("click", async () => {
      setButtonLoading(elements.pingSwBtn, true);
      addLog("Pinging service worker...", "info");
      const res = await pingServiceWorker(false);
      if (res.ok) {
        addLog("Service worker responded (pong).", "success");
        showToast("Service worker responsive", "success");
      } else {
        addLog(`No service worker response: ${res.detail}`, "warning");
        showToast("No service worker response", "warning");
      }
      setButtonLoading(elements.pingSwBtn, false);
    });

    elements.copyLogBtn?.addEventListener("click", () => copyLog().catch(console.error));
    elements.clearLogBtn?.addEventListener("click", clearLog);

    if (hasChromeRuntime() && chrome.runtime?.onMessage) {
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg?.type !== "gmailCleanerProgress") return;
        if (msg.phase === "done" && msg.stats) {
          applyLastRunToDom(msg.stats);
          renderRunHistory().catch(console.error);
          addLog("Received completion stats from cleaner run", "success");
        }
      });
    }

    // Ctrl/Cmd+K copies logs
    document.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        copyLog().catch(console.error);
      }
    });
  };

  // =========================
  // Initialization
  // =========================

  const init = async () => {
    await renderEnv();
    setupEventListeners();

    await Promise.allSettled([renderLastRunFromStorage(), renderRunHistory()]);

    addLog(`Diagnostics page initialized (v${DIAGNOSTICS_VERSION})`, "success");
  };

  init().catch(console.error);
})();
