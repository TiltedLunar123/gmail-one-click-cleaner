(() => {
  // ---- boot ----
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const safeSend = (msg) => { try { chrome.runtime.sendMessage(Object.assign({ type: "gmailCleanerProgress" }, msg)); } catch {} };

  // prevent parse errors from stopping boot logs: keep code valid and minimal at top
  if (window.__GCC_ATTACHED__) { safeSend({ phase: "boot", status: "Already attached", detail: "Duplicate inject ignored.", percent: 0 }); return; }
  window.__GCC_ATTACHED__ = true;
  safeSend({ phase: "boot", status: "Content script attached", detail: "Initializing…", percent: 0 });

  // ---- config / flags ----
  let CANCELLED = false;
  let RUNNING = false;
  const CONFIG = Object.assign({ intensity: "normal", dryRun: false, safeMode: false }, (window.GMAIL_CLEANER_CONFIG || {}));
  const PASS_CAP = 30;

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg) return;
    if (msg.type === "gmailCleanerCancel") { CANCELLED = true; }
    if (msg.type === "gmailCleanerPing") { sendResponse({ ok: true, phase: RUNNING ? "running" : "idle" }); }
    if (msg.type === "gmailCleanerStart") { startMain(); }
  });

  // ---- selectors & helpers ----
  const SELECTORS = {
    main: "div[role='main']",
    grid: "table[role='grid']",
    listContainer: "div[gh='tl']",
    masterCheckbox: [
      "div[aria-label='Select'] div[role='checkbox']",
      "div[aria-label^='Select'] div[role='checkbox']",
      "div[gh='tl'] div[role='checkbox']",
      "div[gh='mtb'] div[role='checkbox']",
      "div[role='checkbox']"
    ],
    deleteButton: [
      "div[gh='mtb'] div[aria-label='Delete']",
      "div[gh='mtb'] [aria-label^='Delete']",
      "[aria-label='Delete']"
    ]
  };

  async function waitFor(fn, { timeout = 15000, interval = 200 } = {}) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (CANCELLED) throw new Error("Cancelled");
      try {
        const v = await fn();
        if (v) return v;
      } catch {}
      await sleep(interval);
    }
    return null;
  }

  async function getRules(intensity) {
    const defaults = {
      light: [
        "larger:20M",
        "has:attachment larger:10M older_than:6m",
        "category:promotions older_than:1y",
        "category:social older_than:1y",
        "\"unsubscribe\" older_than:2y"
      ],
      normal: [
        "larger:20M",
        "has:attachment larger:10M older_than:6m",
        "has:attachment larger:5M older_than:2y",
        "category:promotions older_than:3m",
        "category:promotions older_than:1y",
        "category:social older_than:6m",
        "category:updates older_than:6m",
        "category:forums older_than:6m",
        "has:newsletter older_than:6m",
        "\"unsubscribe\" older_than:1y",
        "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:6m"
      ],
      deep: [
        "larger:20M",
        "has:attachment larger:10M older_than:3m",
        "has:attachment larger:5M older_than:1y",
        "category:promotions older_than:2m",
        "category:promotions older_than:6m",
        "category:social older_than:3m",
        "category:social older_than:6m",
        "category:updates older_than:3m",
        "category:forums older_than:3m",
        "has:newsletter older_than:3m",
        "\"unsubscribe\" older_than:6m",
        "from:(no-reply@ OR donotreply@ OR \"do-not-reply\") older_than:3m"
      ]
    };
    try {
      const { rules } = await chrome.storage.sync.get("rules");
      const all = rules || defaults;
      const set = all[intensity] || all.normal;
      return CONFIG.safeMode ? set.filter(q => !(q.includes("category:updates") || q.includes("category:forums"))) : set;
    } catch {
      const set = defaults[intensity] || defaults.normal;
      return CONFIG.safeMode ? set.filter(q => !(q.includes("category:updates") || q.includes("category:forums"))) : set;
    }
  }

  function labelQuery(q) {
    if (q.includes("larger:")) return "Big attachments";
    if (q.includes("category:promotions")) return "Promotions";
    if (q.includes("category:social")) return "Social";
    if (q.includes("category:updates")) return "Updates";
    if (q.includes("category:forums")) return "Forums";
    if (q.includes("newsletter") || q.includes("unsubscribe")) return "Newsletters";
    if (q.includes("no-reply") || q.includes("donotreply") || q.includes("do-not-reply")) return "No-reply";
    return "Other";
  }

  async function openSearch(query) {
    const uMatch = location.pathname.match(/\/mail\/u\/(\d+)\//);
    const userIdx = uMatch ? uMatch[1] : "0";
    const base = `${location.origin}/mail/u/${userIdx}/`;
    const hash = `#search/${encodeURIComponent(query)}`;
    if (!location.href.startsWith(base)) location.href = base + hash;
    else location.hash = hash;
    const ok = await waitFor(() => {
      const main = document.querySelector(SELECTORS.main);
      return main && (main.querySelector(SELECTORS.grid) || main.querySelector(SELECTORS.listContainer));
    }, { timeout: 20000 });
    if (!ok) throw new Error("Results grid not found");
    await sleep(300);
  }

  function clickMasterCheckbox() {
    for (const s of SELECTORS.masterCheckbox) {
      const el = document.querySelector(s);
      if (el) { el.click(); return true; }
    }
    return false;
  }

  function findDeleteButton(){
    const toolbar = document.querySelector("div[gh='mtb']") || document.querySelector("div[role='toolbar']") || document;
    const tokens = ["Delete","Trash","Bin","Move to trash","Eliminar","Papelera","Supprimer","Corbeille","Löschen","Papierkorb","Excluir","Lixeira","Elimina","Cestino","Verwijderen","Prullenbak","Ta bort","Slet","Slett","Usuń","Kosz","Sil","Удалить","حذف","削除","삭제","删除"];
    const btns = Array.from(toolbar.querySelectorAll("div[role='button'], button"));
    const scored = btns.map(el => {
      const lab = (el.getAttribute("aria-label") || el.getAttribute("data-tooltip") || el.getAttribute("title") || el.textContent || "").trim();
      let score = 0;
      for (const t of tokens){ if (lab.toLowerCase().includes(t.toLowerCase())) score += 2; }
      if (/delete|trash|bin/i.test(lab)) score += 3;
      const d = (el.querySelector("[aria-label],[data-tooltip],[title]") || {});
      const dl = (d.getAttribute && (d.getAttribute("aria-label") || d.getAttribute("data-tooltip") || d.getAttribute("title"))) || "";
      if (/delete|trash|bin/i.test(dl)) score += 1;
      return { el, score };
    }).filter(x => x.score > 0).sort((a,b)=>b.score-a.score);
    return scored.length ? scored[0].el : null;
  }

  async function tryDeleteAction(){
    const btn = findDeleteButton();
    if (btn) { btn.click(); return true; }
    try {
      const ev = new KeyboardEvent("keydown", { key: "#", code: "Digit3", shiftKey: true, bubbles: true });
      document.body.dispatchEvent(ev);
      await sleep(250);
      return true;
    } catch {}
    try {
      const ev2 = new KeyboardEvent("keydown", { key: "Delete", code: "Delete", bubbles: true });
      document.body.dispatchEvent(ev2);
      await sleep(250);
      return true;
    } catch {}
    return false;
  }

  function hasNoResults() {
    const grid = document.querySelector(SELECTORS.grid);
    if (grid) {
      const rows = grid.querySelectorAll("tr[role='row']");
      if (rows && rows.length === 0) return true;
    }
    const spans = Array.from(document.querySelectorAll("span"));
    return spans.some(el => {
      const t = el.innerText || "";
      return t.includes("No messages matched your search") ||
             t.includes("Your search did not match any conversations");
    });
  }

  function estimateTotalResults(){
    const nodes = Array.from(document.querySelectorAll("span, div"));
    for (const el of nodes){
      const t = (el.innerText || "").trim();
      if (!t) continue;
      const m = t.match(/\bof\s+([\d,\.]+)/i);
      if (m) {
        const n = Number((m[1] || "").replace(/[,\.\s]/g, ""));
        if (Number.isFinite(n) && n > 0) return n;
      }
      const m2 = t.match(/\babout\s+([\d,\.]+)\s+results/i);
      if (m2) {
        const n2 = Number((m2[1] || "").replace(/[,\.\s]/g, ""));
        if (Number.isFinite(n2) && n2 > 0) return n2;
      }
    }
    return null;
  }

  function extractSelectedCount() {
    const spans = Array.from(document.querySelectorAll("span"));
    const banner = spans.find(el => /selected/i.test(el.innerText || ""));
    if (!banner) return null;
    const m = (banner.innerText || "").match(/([\d,\.]+)/g);
    if (!m) return null;
    const n = Number(m[m.length - 1].replace(/[,\.\s]/g, ""));
    return Number.isFinite(n) ? n : null;
  }

  async function deleteCurrentPageIfAny() {
    if (hasNoResults()) return { deleted: false, count: 0, reason: "No results" };
    await waitFor(() => document.querySelector("div[gh='mtb']") || document.querySelector("div[role='toolbar']"), { timeout: 8000 });
    if (!clickMasterCheckbox()) return { deleted: false, count: 0, reason: "No master checkbox" };
    await sleep(150);
    const selectedCount = extractSelectedCount();
    if (CONFIG.dryRun) {
      return { deleted: false, count: (selectedCount ?? estimateTotalResults() ?? 0), reason: "dry-run" };
    }
    const est = selectedCount ?? estimateTotalResults();
    if (!CONFIG.dryRun && est && est > 5000 && !window.GCC_CONFIRMED_HUGE){
      const ok = confirm(`About to delete ~${est.toLocaleString()} conversations. Continue?`);
      if (!ok) return { deleted: false, count: 0, reason: "user-cancelled" };
      window.GCC_CONFIRMED_HUGE = true;
    }
    const okDelete = await tryDeleteAction();
    if (!okDelete) return { deleted: false, count: 0, reason: "No delete button" };
    await sleep(500);
    return { deleted: true, count: selectedCount ?? 0 };
  }

  // ----- stats -----
  const stats = { totalDeleted: 0, totalWouldDelete: 0, perQuery: [] };

  async function processQuery(query, idx, total) {
    const label = labelQuery(query);
    const start = Date.now();
    let pass = 0;

    while (pass < PASS_CAP) {
      if (CANCELLED) throw new Error("Cancelled");
      const percent = Math.round(((idx) / total) * 100);
      safeSend({ phase: "query", status: `Cleaning ${label} (${idx + 1}/${total})`, detail: `Pass ${pass + 1}`, percent });

      await openSearch(query);
      if (hasNoResults()) {
        const mode = CONFIG.dryRun ? "dry" : "live";
        const durationMs = Date.now() - start;
        safeSend({ detail: `No results for: ${query}` });
        stats.perQuery.push({ query, label, count: 0, mode, durationMs });
        safeSend({ phase: "query-done", query, label, count: 0, mode, durationMs });
        break;
      }

      const res = await deleteCurrentPageIfAny();

      if (CONFIG.dryRun) {
        const durationMs = Date.now() - start;
        const count = (res.count ?? estimateTotalResults() ?? 0);
        stats.totalWouldDelete += count;
        stats.perQuery.push({ query, label, count, mode: "dry", durationMs });
        safeSend({ detail: `Dry-Run: would delete ${count} for: ${query}` });
        safeSend({ phase: "query-done", query, label, count, mode: "dry", durationMs });
        break;
      }

      if (!res.deleted) {
        const durationMs = Date.now() - start;
        stats.perQuery.push({ query, label, count: 0, mode: "live", durationMs });
        safeSend({ detail: `Nothing to delete for: ${query} (${res.reason})` });
        safeSend({ phase: "query-done", query, label, count: 0, mode: "live", durationMs });
        break;
      }

      stats.totalDeleted += (res.count || 0);
      pass += 1;
      await sleep(650);
      if (hasNoResults()) {
        const durationMs = Date.now() - start;
        stats.perQuery.push({ query, label, count: (res.count || 0), mode: "live", durationMs });
        safeSend({ phase: "query-done", query, label, count: (res.count || 0), mode: "live", durationMs });
        break;
      }
    }
  }

  async function main() {
    if (RUNNING) return;
    RUNNING = true;
    try {
      if (!location.host.includes("mail.google.com")) {
        alert("Gmail Cleaner: run this from a Gmail tab.");
        return;
      }
      const rules = await getRules(CONFIG.intensity);
      const total = rules.length;

      safeSend({ phase: "starting", status: "Starting Gmail cleanup…", detail: `Level: ${CONFIG.intensity}. ${total} queries.`, percent: 0 });

      for (let i = 0; i < rules.length; i++) {
        if (CANCELLED) throw new Error("Cancelled");
        await processQuery(rules[i], i, total);
      }

      const doneStats = { mode: (CONFIG.dryRun ? "dry" : "live"), totalDeleted: stats.totalDeleted, totalWouldDelete: stats.totalWouldDelete, totalQueries: total };
      safeSend({ phase: "done", status: "Cleanup finished.", detail: "All queries processed.", percent: 100, done: true, stats: doneStats });
      if (!CONFIG.dryRun) alert("Gmail Cleaner finished. Check Trash to restore if needed.");
    } catch (e) {
      if (String(e).includes("Cancelled")) {
        safeSend({ phase: "cancelled", status: "Run cancelled.", detail: "Stopped by user.", done: true, percent: 100 });
      } else {
        console.error(e);
        safeSend({ phase: "error", status: "Error occurred.", detail: String(e) });
      }
    } finally {
      RUNNING = false;
    }
  }

  function startMain(){ if (!RUNNING) main(); }
  // auto-start once on injection
  startMain();
})();