// progress.js
(() => {
  "use strict";

  const qs = new URLSearchParams(location.search);
  const gmailTabIdRaw = qs.get("gmailTabId");
  const gmailTabId =
    gmailTabIdRaw != null &&
    gmailTabIdRaw !== "" &&
    !Number.isNaN(Number(gmailTabIdRaw))
      ? Number(gmailTabIdRaw)
      : null;

  const ui = {
    barInner: document.getElementById("barInner"),
    percentText: document.getElementById("percentText"),
    status: document.getElementById("status"),
    details: document.getElementById("details"),
    tags: document.getElementById("tags"),
    cancel: document.getElementById("cancelBtn"),
    reconnect: document.getElementById("reconnectBtn"),
    reinject: document.getElementById("reinjectBtn"),
    panel: document.querySelector(".panel"),
    summary: document.getElementById("summary"),
    table: document.getElementById("summaryTable"),
    tipPrompt: document.getElementById("tipPrompt"),
    toggleLogs: document.getElementById("toggleLogs"),
    progressBar: document.querySelector(".bar")
  };

  const tbody = ui.table ? ui.table.querySelector("tbody") : null;

  const state = {
    lastPhase: "starting",
    done: false,
    mode: "live",
    logsExpanded: false,
    rows: [],
    tipShown: false
  };

  function setStatus(message) {
    if (!ui.status) return;
    ui.status.textContent = message || "";
  }

  function setPhaseTag(phase) {
    if (!ui.tags) return;

    const text = (() => {
      switch (phase) {
        case "boot":
          return "boot";
        case "starting":
          return "starting";
        case "query":
          return "running queries";
        case "query-done":
          return "query finished";
        case "tag":
          return "tagging";
        case "done":
          return "done";
        case "cancelled":
          return "cancelled";
        case "error":
          return "error";
        default:
          return phase || "starting";
      }
    })();

    ui.tags.textContent = text;
  }

  function setPercent(p) {
    const percent = Math.max(0, Math.min(100, Number.isFinite(p) ? p : 0));

    if (ui.barInner) {
      ui.barInner.style.width = percent + "%";
    }
    if (ui.percentText) {
      ui.percentText.textContent = percent.toFixed(0) + "%";
    }
    if (ui.progressBar) {
      ui.progressBar.setAttribute("aria-valuenow", String(percent));
    }
  }

  function appendLog(line) {
    if (!ui.details) return;

    // Clear placeholder text on first real log
    if (ui.details.textContent.trim() === "Waiting for first signal…") {
      ui.details.textContent = "";
    }

    const div = document.createElement("div");
    const now = new Date();
    const ts = now.toLocaleTimeString(undefined, { hour12: false });
    div.textContent = "[" + ts + "] " + line;
    ui.details.appendChild(div);

    // Keep last ~300 lines
    const maxNodes = 300;
    while (ui.details.childNodes.length > maxNodes) {
      ui.details.removeChild(ui.details.firstChild);
    }
  }

  function renderStatsSummary(stats) {
    if (!ui.summary) return;
    ui.summary.innerHTML = "";

    if (!stats) return;

    const mode = stats.mode === "dry" ? "dry" : "live";
    state.mode = mode;

    const chips = [];

    if (mode === "dry") {
      chips.push(["Mode", "Dry-run"]);

      let wouldCleanTotal = 0;
      if (typeof stats.totalWouldDelete === "number") {
        wouldCleanTotal += stats.totalWouldDelete;
      }
      if (typeof stats.totalWouldArchive === "number") {
        wouldCleanTotal += stats.totalWouldArchive;
      }

      if (wouldCleanTotal) {
        chips.push(["Would clean", wouldCleanTotal.toLocaleString()]);
      }
    } else {
      chips.push(["Mode", "Live"]);

      let cleanedTotal = 0;
      if (typeof stats.totalDeleted === "number") {
        cleanedTotal += stats.totalDeleted;
      }
      if (typeof stats.totalArchived === "number") {
        cleanedTotal += stats.totalArchived;
      }

      if (cleanedTotal) {
        chips.push(["Cleaned", cleanedTotal.toLocaleString()]);
      }
    }

    if (typeof stats.totalQueries === "number") {
      chips.push(["Queries", stats.totalQueries.toLocaleString()]);
    }

    for (const [label, value] of chips) {
      const pill = document.createElement("span");
      pill.className = "pill";
      pill.textContent = label + ": " + value;
      ui.summary.appendChild(pill);
    }
  }

  function renderRowsTable() {
    if (!ui.table || !tbody) return;

    if (!state.rows.length) {
      ui.table.style.display = "none";
      tbody.innerHTML = "";
      return;
    }

    ui.table.style.display = "table";
    tbody.innerHTML = "";

    for (const row of state.rows) {
      const tr = document.createElement("tr");

      const tdQuery = document.createElement("td");
      tdQuery.textContent = row.label || row.query || "(unknown)";
      tr.appendChild(tdQuery);

      const tdMode = document.createElement("td");
      tdMode.textContent = row.mode === "dry" ? "Dry-run" : "Live";
      tr.appendChild(tdMode);

      const tdCount = document.createElement("td");
      tdCount.textContent = (row.count != null ? row.count : 0).toLocaleString();
      tr.appendChild(tdCount);

      const tdDuration = document.createElement("td");
      if (row.durationMs != null && row.durationMs >= 0) {
        const sec = row.durationMs / 1000;
        tdDuration.textContent = sec.toFixed(sec >= 10 ? 0 : 1) + "s";
      } else {
        tdDuration.textContent = "–";
      }
      tr.appendChild(tdDuration);

      tbody.appendChild(tr);
    }
  }

  function maybeShowTipPrompt(stats) {
    if (!ui.tipPrompt || state.tipShown) return;
    if (!stats) return;

    const mode = stats.mode === "dry" ? "dry" : "live";
    if (mode !== "live") return;

    let cleanedTotal = 0;
    if (typeof stats.totalDeleted === "number") {
      cleanedTotal += stats.totalDeleted;
    }
    if (typeof stats.totalArchived === "number") {
      cleanedTotal += stats.totalArchived;
    }

    if (!cleanedTotal || cleanedTotal < 50) return;

    ui.tipPrompt.style.display = "block";
    state.tipShown = true;
  }

  function handleDone(msg) {
    state.done = true;
    const phase = msg.phase || "done";

    setPhaseTag(phase);
    setPercent(msg.percent != null ? msg.percent : 100);

    if (ui.cancel) {
      ui.cancel.disabled = true;
      if (phase === "cancelled") {
        ui.cancel.textContent = "Run cancelled";
      } else if (phase === "error") {
        ui.cancel.textContent = "Run ended with error";
      } else {
        ui.cancel.textContent = "Run finished";
      }
    }
    if (ui.reconnect) ui.reconnect.disabled = true;
    if (ui.reinject) ui.reinject.disabled = true;

    if (msg.stats && phase === "done") {
      renderStatsSummary(msg.stats);
      maybeShowTipPrompt(msg.stats);
    } else if (msg.stats) {
      renderStatsSummary(msg.stats);
    }

    appendLog("Run finished: " + (msg.detail || "All queries processed."));
  }

  function handleProgressMessage(message) {
    if (!message || message.type !== "gmailCleanerProgress") return;

    const { phase, status, detail, percent, stats } = message;

    if (status) {
      setStatus(status);
      appendLog(status + (detail ? " — " + detail : ""));
    } else if (detail) {
      appendLog(detail);
    }

    if (typeof percent === "number") {
      setPercent(percent);
    }

    if (phase) {
      state.lastPhase = phase;
      setPhaseTag(phase);
    }

    if (message.phase === "query-done") {
      const row = {
        query: message.query || "",
        label: message.label || "",
        count: message.count || 0,
        mode: message.mode || (stats && stats.mode) || state.mode || "live",
        durationMs:
          message.durationMs != null ? message.durationMs : null
      };
      state.rows.push(row);
      renderRowsTable();
    }

    if (stats) {
      renderStatsSummary(stats);
    }

    if (message.done || phase === "done" || phase === "cancelled" || phase === "error") {
      handleDone(message);
    }

    if (phase === "error") {
      if (ui.cancel) ui.cancel.disabled = true;
      appendLog("Error details: " + (detail || "unknown error"));
    }

    if (phase === "cancelled") {
      appendLog("Run cancelled by user.");
    }
  }

  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      try {
        handleProgressMessage(msg);
      } catch (err) {
        console.error("[Gmail Cleaner] Error handling progress message:", err);
      }
    });
  }

  function wireButtons() {
    if (ui.cancel) {
      ui.cancel.addEventListener("click", async () => {
        if (!gmailTabId) {
          appendLog("Cannot cancel: Gmail tab id missing.");
          return;
        }
        try {
          ui.cancel.disabled = true;
          ui.cancel.textContent = "Cancelling…";
          await chrome.tabs.sendMessage(gmailTabId, {
            type: "gmailCleanerCancel"
          });
          appendLog("Cancel signal sent to Gmail tab " + gmailTabId + ".");
        } catch (err) {
          console.error("[Gmail Cleaner] Failed to send cancel message:", err);
          appendLog(
            "Failed to send cancel message: " +
              (err && err.message ? err.message : String(err))
          );
          ui.cancel.disabled = false;
          ui.cancel.textContent = "Cancel run";
        }
      });
    }

    if (ui.reconnect) {
      ui.reconnect.addEventListener("click", async () => {
        if (!gmailTabId) {
          appendLog("Cannot reconnect: Gmail tab id missing.");
          return;
        }
        appendLog("Pinging Gmail content script…");
        try {
          await chrome.tabs.sendMessage(
            gmailTabId,
            { type: "gmailCleanerPing" },
            (resp) => {
              const lastErr = chrome.runtime.lastError;
              if (lastErr) {
                appendLog("Reconnect failed: " + lastErr.message);
                setStatus("Reconnect failed. Try Re-inject.");
                return;
              }
              if (!resp || !resp.ok) {
                appendLog("Reconnect: script responded with non-ok.");
                setStatus("Reconnect: script responded but not ok.");
                return;
              }
              appendLog("Reconnect OK. Phase: " + (resp.phase || "unknown"));
              setStatus("Reconnected to Gmail tab.");
            }
          );
        } catch (err) {
          console.error("[Gmail Cleaner] Reconnect error:", err);
          appendLog(
            "Reconnect error: " +
              (err && err.message ? err.message : String(err))
          );
        }
      });
    }

    if (ui.reinject) {
      ui.reinject.addEventListener("click", async () => {
        if (!gmailTabId) {
          appendLog("Cannot re-inject: Gmail tab id missing.");
          return;
        }
        appendLog("Re-injecting cleaner into Gmail tab…");
        setStatus("Re-injecting cleaner into Gmail tab…");

        try {
          let cfg = null;
          try {
            const { lastConfig } = await chrome.storage.session.get("lastConfig");
            cfg = lastConfig || null;
          } catch {
            try {
              const { lastConfig } = await chrome.storage.local.get("lastConfig");
              cfg = lastConfig || null;
            } catch {
              // ignore
            }
          }

          if (cfg) {
            await chrome.scripting.executeScript({
              target: { tabId: gmailTabId },
              func: (config) => {
                window.GMAIL_CLEANER_CONFIG =
                  config || window.GMAIL_CLEANER_CONFIG || {};
              },
              args: [cfg]
            });
          }

          await chrome.scripting.executeScript({
            target: { tabId: gmailTabId },
            files: ["contentScript.js"]
          });

          appendLog("Re-injected content script into Gmail tab.");
          setStatus(
            "Cleaner re-injected. It should resume sending progress shortly."
          );
        } catch (err) {
          console.error("[Gmail Cleaner] Re-inject error:", err);
          appendLog(
            "Re-inject error: " +
              (err && err.message ? err.message : String(err))
          );
          setStatus(
            "Re-inject failed. You can close this and start a new run from the popup."
          );
        }
      });
    }

    if (ui.toggleLogs && ui.details) {
      ui.toggleLogs.addEventListener("click", () => {
        state.logsExpanded = !state.logsExpanded;
        if (state.logsExpanded) {
          ui.details.style.maxHeight = "none";
          ui.details.style.overflowY = "visible";
          ui.toggleLogs.textContent = "Hide logs";
        } else {
          ui.details.style.maxHeight = "220px";
          ui.details.style.overflowY = "auto";
          ui.toggleLogs.textContent = "Logs";
        }
      });
    }
  }

  function init() {
    if (!gmailTabId) {
      setStatus(
        "Could not read Gmail tab id from URL. You can close this and try again."
      );
      appendLog("Missing or invalid gmailTabId in query string.");
    } else {
      setStatus(
        "Waiting for cleaner in Gmail tab " +
          gmailTabId +
          " to send progress…"
      );
    }

    wireButtons();
  }

  if (document.readyState === "loading") {
    window.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
