# Gmail One-Click Cleaner (v2.10)

MV3 Chrome extension that bulk-cleans Gmail in one click. It runs a sequence of Gmail searches (promos, social, newsletters, large attachments, etc.), shows a live progress window, and supports Dry-Run, Cancel, tagging-before-delete, and options-based rules.

> Works best from a Gmail tab in Chrome (or Chromium-based browsers).  
> Store version: search **“Gmail One-Click Cleaner”** in the Chrome Web Store.

---

## Install (Developer Mode)

1. Download and unzip the project (or use the provided `.zip` and extract it).
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top-right).
4. Click **Load unpacked** and select the extension folder (the one containing `manifest.json`).
5. Pin the extension. Open Gmail, then click the extension icon and hit **Run cleanup**.

---

## How it works

- Injects a content script into the **Gmail tab you launched it from** (multi-account safe).
- Runs a sequence of Gmail searches, like:
  - Promotions / Social / Updates / Forums
  - Old newsletters and no-reply mail
  - Very large / old attachments
- For each search it:
  - Opens the search in your existing Gmail tab
  - Selects matching conversations (including “Select all that match this search” when available)
  - **Live mode:** tags matches, then deletes to Trash  
  - **Dry-Run:** counts matches only, no deletions
- A separate **Progress** page shows:
  - Current phase and percent complete
  - Per-query counts and durations
  - A live log of each step
  - **Reconnect** / **Re-inject** helpers if the connection to Gmail is lost

Internally it uses `chrome.scripting`, resilient selectors, and a capped number of passes per query to avoid infinite loops when Gmail behaves oddly.

---

## Features

### Core

- **Dry-Run mode**  
  See how many conversations *would* be deleted without touching your Trash.

- **Tag before Trash (live runs)**  
  In live mode, matching conversations are labeled (for example  
  `GmailCleaner - Promotions`, `GmailCleaner - Social`, etc.) **before** they’re moved to Trash, so you can search/audit them later in Trash.

- **Cancel mid-run**  
  Click **Cancel run** in the Progress window and the cleaner stops within a few seconds.

- **Reconnect & Re-inject**  
  If Gmail reloads or the content script disconnects:
  - **Reconnect** pings the running cleaner in the Gmail tab.
  - **Re-inject** re-injects the cleaner and last-used config into the same Gmail tab.

- **Custom rule sets**  
  Edit the **Light**, **Normal**, and **Deep** query lists in the Options page.  
  Rules are stored in `chrome.storage.sync`, so they follow you across Chrome where sync is enabled.

- **Safe by default**  
  Default rules focus on obvious low-value mail (old promos, social noise, large attachments).  
  There’s a **Safe Mode / Skip Updates & Forums** toggle that automatically skips any rules containing `category:updates` or `category:forums`, so receipts and order notifications are less likely to be touched.

- **Multi-account aware**  
  Targets the Gmail account in the tab you clicked the extension from, even if you’re signed into multiple Gmail accounts in the same browser.

---

## Options: rules & future Pro section

Open the **Options** page from the popup:

### Rule sets

- One Gmail search query per line.
- Sections:
  - **Light** – very safe: big attachments + older obvious junk
  - **Normal** – recommended everyday cleanup
  - **Deep** – more aggressive on older promos/newsletters

Examples (each on its own line):

- `category:promotions older_than:6m`
- `category:social older_than:1y`
- `has:attachment larger:10M older_than:6m`
- `"unsubscribe" older_than:1y`
- `from:(no-reply@ OR donotreply@ OR "do-not-reply") older_than:6m`

### “Pro” section (not live yet)

The Options page includes a **Pro** strip for future features (license input, lifetime stats, etc.), but:

- Pro activation is **not live yet**.
- The UI is a preview and may change.
- You should **ignore it for now and not purchase anything** until a future release explicitly says Pro is live in both the extension and docs.

If you experiment with the Pro input, only the license key you paste is sent to the backend. Your Gmail data is never sent.

---

## Diagnostics

There’s a small **Diagnostics** page (linked from the Options page) to help debug issues:

- Shows the browser, platform, extension version, and requested permissions.
- Lists all open Gmail tabs with:
  - Tab ID
  - Window ID
  - Active state
  - URL (truncated)
- Shows which Gmail tab the popup will choose for a run.
- Has a **Scan tabs** button to refresh the view.
- Has a **Test inject** button that tries to inject a tiny script into the chosen Gmail tab and logs whether it succeeds.

This is mainly for debugging multi-Gmail setups, Brave/Edge quirks, or “it says no Gmail tab” reports.

---

## Privacy

- All cleanup logic (searching, selecting, tagging, deleting) runs locally in your browser.
- The extension does **not** send your email content or Gmail metadata to any external server.
- If you manually try the future Pro activation, only the license key and basic license result are exchanged with the backend; your Gmail data is never transmitted.

Gmail itself keeps Trash for ~30 days, so you can restore messages if you delete something by mistake. Running **Dry-Run** first is recommended when changing rules or using the **Deep** set.
