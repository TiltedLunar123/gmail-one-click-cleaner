# Gmail One-Click Cleaner (v3.3.0)

A Chrome MV3 extension that bulk-cleans Gmail in one click. It runs a configurable sequence of Gmail searches (promos, social, newsletters, large attachments, etc.), opens a live **Progress** dashboard, and supports **Dry-Run**, **Safe Mode**, **Review Mode**, archiving, and custom rules.

> Works best from an open Gmail tab in Chrome (or Chromium browsers like Brave/Edge).  
> Chrome Web Store listing: search **“Gmail One-Click Cleaner”**.

---

## Install (Developer Mode)

1. Download and unzip the project (or extract the provided `.zip`).
2. Open `chrome://extensions` in Chrome.
3. Enable **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select the extension folder (the one containing `manifest.json`).
5. Pin the extension. Open Gmail, then click the extension icon to start.

---

## How It Works

- **Finds Gmail tab:** Detects an open Gmail tab (active tab first, then other Gmail tabs).
- **Injects config safely:** Sends your run config into the Gmail tab (`window.GMAIL_CLEANER_CONFIG`) and injects the content script.
- **Runs rule queries:** Cycles through your selected rule set (Promotions, Social, Attachments, etc.).
- **For each rule, it:**
  - Opens the Gmail search query.
  - Selects matching conversations.
  - **Live Mode:** Labels matches (example: `GmailCleaner - Promotions`) before moving to **Trash** or **All Mail** (Archive).
  - **Review Mode:** Pauses and asks you to approve or skip a batch.
  - **Dry-Run:** Counts matches only and does not modify mail.
- **Progress dashboard tab** shows:
  - Phase + percent progress bar
  - Per-rule results table (count + duration, and freed MB when available)
  - Activity log (copy/clear, toggle)
  - Run controls (Cancel, Reconnect, Re-inject)

---

## Features (v3.3.0)

### 1. Monthly Light Clean (Quick Preset)
- A “monthly” preset button that auto-configures a safer maintenance run.
- Sets **Safe Mode**, **Trash**, and a **3 month** minimum age limit.

### 2. Guardrails & Safety
- **Action Type:** Trash (delete) or Archive (All Mail).
- **Minimum Age:** Never touch anything newer than your chosen cutoff (3m, 6m, etc.).
- **Global Whitelist:** Emails/domains in Options are excluded from all rules.
- **Safety Toggles:**
  - Skip **Starred** and **Important**
  - **Safe Mode** skips riskier categories (example: receipts/updates)

### 3. Review & Dry-Run Modes
- **Review Mode:** Prompts you before acting on a batch, with a clear Proceed or Skip choice.
- **Dry-Run:** Simulates the full run, counting matches without moving anything.

### 4. Tagging Before Action
- In Live Mode, matches are labeled first so you can audit what was targeted even after the move.

### 5. Progress Dashboard + Recovery Tools
- Live progress bar + phase tags
- Per-query table + timestamps/durations
- Logs with Copy/Clear and a toggle view
- **Reconnect:** Ping the Gmail tab if the page stops receiving updates
- **Re-inject:** Re-inject the content script + last config if needed
- **Cancel run** button (best-effort)

### 6. Diagnostics
- A diagnostics page to help troubleshoot common issues (can’t find Gmail tab, injection, permissions).

---

## Jude’s Cheap Storage & Setup Picks

Cleaned your inbox but still running low on storage? These budget picks are shown in the Progress page:

- **Samsung T7 Portable SSD (1TB)**: https://amzn.to/3MrwsMz
- **Lexar 128GB USB-C Dual Drive**: https://amzn.to/3Mftfjl
- **Amazon Basics Laptop Stand**: https://amzn.to/4aBnKW6
- **Rii Ultra-Slim Compact Keyboard**: https://amzn.to/4pqDwYB
- **192pc Cable Management Kit**: https://amzn.to/48oWb0L

(As an Amazon Associate I earn from qualifying purchases.)

---

## Options & Rules

Open **Rules & Settings** from the popup or from the extension’s details page.

### Rule Sets
One Gmail search query per line.

- **Light:** Safer, older mail and large attachments
- **Normal:** Balanced cleanup (recommended)
- **Deep:** More aggressive (use Dry-Run first)

Example rules:
- `category:promotions older_than:6m`
- `category:social older_than:1y`
- `has:attachment larger:10M older_than:6m`
- `"unsubscribe" older_than:1y`

### Global Whitelist
Enter email addresses/domains (one per line) that should be ignored by all rules.  
The cleaner automatically appends `-from:...` style exclusions to every search query it runs.

---

## Privacy & Data

- **Local-only:** All searching/selecting/tagging/moving runs in your browser.
- **No data collection:** No external servers. No analytics SDKs. No email content sent anywhere.
- **Permissions used:** `activeTab`, `scripting`, `tabs`, `storage`.

Note: Gmail keeps Trash for ~30 days. If you delete something by mistake, you can restore it from Trash within that window.
